﻿# このファイルにはゲームのスクリプトを記述します。\n

# Ren'Py のスクリプトは、インデント（行頭の空白）によってブロック分けされています。\n
# インデントは Tab や Shift + Tab によって調整することができます。\n


# まず最初に、ゲームに使うキャラクター（台詞を表示するオブジェクト）を定義します。\n
# 一番目のパラメーターは、テキストウィンドウに表示されるキャラクターの名前です。\n
# color のパラメーターを追加すると、キャラクターの名前を色付けできます。\n
init python:
    d = Character("？？？", color="#56d5ff", image="detective")
    m = Character("？？？", color="#56d5ff", what_prefix='(', what_suffix=')', what_color=gui.highlight_color, image="detective")
    cps_tw = gui.dialogue_typewriter_cps
    tp = Character("", color="#c75743", what_color=gui.machine_color, what_textalign=0.5, what_xalign=0.5, what_slow_cps=cps_tw)
    chara_rb = Character("", what_textalign=1.0, what_xalign=0.7, what_yalign=0.7)
    cps_sm = gui.dialogue_slowmotion_cps
    scenario_prefix = "yuanyangcha"
# 各種イベントの達成状況のフラグ管理する辞書を定義
# keyはlabel名の文字列 call expressionで対象のlabelを呼び出し可能
# valueは達成状況の数値 0:非表示、1:進行中、2:完了
    label_stat_dict = {
        # 第1話イベントリスト
        "redbull_enter_your_name": 0,
        # 第1話手がかりリスト
        "yuanyangcha_character_d": 0,
        "yuanyangcha_character_a": 0,
        "yuanyangcha_character_coffee": 0,
        "yuanyangcha_character_yuzu": 0,
        "yuanyangcha_character_tea": 0,
        "yuanyangcha_character_chen": 0,
        "yuanyangcha_character_robusta": 0,
        "yuanyangcha_character_gal": 0,
        "yuanyangcha_character_matcha": 0,
        # 第2話登場人物リスト
        # 第2話イベントリスト
        "yuanyangcha_tea_encounter": 0,
        "yuanyangcha_chen_encounter": 0,
        "yuanyangcha_coffee_encounter": 0,
        "yuanyangcha_robusta_encounter": 0,
        "yuanyangcha_security_research_camera": 0,
        "yuanyangcha_security_research_poster": 0,
        "yuanyangcha_security_talk_poison_drink": 0,
        "yuanyangcha_security_talk_coffee_kind": 0,
        "yuanyangcha_security_talk_coffee_hairpin": 0,
        "yuanyangcha_kitchenette_research_shelf": 0,
        "yuanyangcha_kitchenette_research_colander_microwave": 0,
        "yuanyangcha_kitchenette_talk_yesterday": 0,
        "yuanyangcha_kitchenette_talk_teatime": 0,
        "yuanyangcha_kitchenette_talk_cup": 0,
        "yuanyangcha_kitchenette_talk_wash": 0,
        "yuanyangcha_kitchenette_talk_interview": 0,
        "yuanyangcha_labo_research_centrifuge": 0,
        "yuanyangcha_labo_research_chemical": 0,
        "yuanyangcha_labo_talk_yesterday": 0,
        "yuanyangcha_labo_talk_drink": 0,
        "yuanyangcha_labo_talk_yuanyangcha": 0,
        "yuanyangcha_labo_talk_cup": 0,
        "yuanyangcha_office_research_paper_tea": 0,
        "yuanyangcha_office_research_paper_chen": 0,
        "yuanyangcha_office_research_paper_robusta": 0,
        "yuanyangcha_office_research_professor_note": 0,
        "yuanyangcha_office_talk_yesterday": 0,
        "yuanyangcha_office_talk_drink": 0,
        "yuanyangcha_office_talk_cup": 0,
        # 第2話手がかりリスト
        "yuanyangcha_clue_yuzu_drink_when": 0,
        "yuanyangcha_clue_poison_official_mug": 0,
        "yuanyangcha_clue_tea_fingerprint_saliva": 0,
        "yuanyangcha_clue_time_table": 0,
        "yuanyangcha_clue_interview": 0,
        "yuanyangcha_clue_remind_mail": 0,
        "yuanyangcha_clue_professor_note": 0,
        "yuanyangcha_clue_professor_note_lost": 0,
        "yuanyangcha_clue_poison_tea_coffee": 0,
        "yuanyangcha_clue_poison_robusta": 0,
        "yuanyangcha_clue_poison_anyone": 0,
        "yuanyangcha_clue_shelf_hide": 0,
        "yuanyangcha_clue_yuzu_cup": 0,
        "yuanyangcha_clue_tea_habit": 0,
        "yuanyangcha_clue_kitchenette_dark": 0,
        "yuanyangcha_clue_tea_drink": 0,
        "yuanyangcha_clue_tea_cup": 0,
        "yuanyangcha_clue_tea_cup_200ml": 0,
        "yuanyangcha_clue_tea_bottle_100ml": 0,
        "yuanyangcha_clue_timer_shorten": 0,
        "yuanyangcha_clue_timer_log_edit": 0,
        "yuanyangcha_clue_chen_arabica": 0,
        "yuanyangcha_clue_chen_tea": 0,
        "yuanyangcha_clue_chen_cup": 0,
        "yuanyangcha_clue_robusta_smell": 0,
        "yuanyangcha_clue_tea_paper": 0,
        "yuanyangcha_clue_chen_paper": 0,
        "yuanyangcha_clue_robusta_paper": 0,
        "yuanyangcha_clue_robusta_arrival": 0,
        "yuanyangcha_clue_robusta_drink": 0,
        "yuanyangcha_clue_robusta_cup": 0,
        # 第3話イベントリスト
        # 第3話手がかりリスト
        # うんちくリスト
        "yuanyangcha_trivia_gabalongcha": 0,
        "yuanyangcha_trivia_oolong_tea": 0,
        "yuanyangcha_trivia_ferment_oxidation": 0,
        "yuanyangcha_trivia_cafeaulait_cafelatte": 0,
        "yuanyangcha_trivia_cafelatte_cappuccino": 0,
        "yuanyangcha_trivia_cappuccino": 0,
        "yuanyangcha_trivia_cappucino_cheap": 0,
        "yuanyangcha_trivia_ice_coffee_expensive": 0,
        "yuanyangcha_trivia_quality_season": 0,
        "yuanyangcha_trivia_grade": 0,
        "yuanyangcha_trivia_tea_species": 0,
        "yuanyangcha_trivia_darjeeling": 0,
        "yuanyangcha_trivia_champagne": 0,
        "yuanyangcha_trivia_earl_grey": 0,
        "yuanyangcha_trivia_flavour_blend": 0,
        "yuanyangcha_trivia_cha_tea": 0,
        "yuanyangcha_trivia_yuanyangcha": 0,
        "yuanyangcha_trivia_vietnam_coffee": 0,
        "yuanyangcha_trivia_coffee_species": 0,
        "yuanyangcha_trivia_angel's_share": 0,
        "yuanyangcha_trivia_devil's_cut": 0,
        "yuanyangcha_trivia_devil's_cut_liqueur": 0,
        "yuanyangcha_trivia_balzac": 0,
        "yuanyangcha_trivia_coffee_bean": 0,
        "yuanyangcha_trivia_ceylon_lipton": 0,
        "yuanyangcha_trivia_opium_war": 0,
        "yuanyangcha_trivia_american_war_of_independencee": 0,
        "yuanyangcha_trivia_kopi_luwak": 0,
        "yuanyangcha_trivia_kopi_luwak_altanative": 0,
        "yuanyangcha_trivia_coffee_kanji": 0,
        "yuanyangcha_trivia_cafe_mocha": 0,
    }
# 各種情報項目のメニューで表示する内容を管理する辞書を定義
# keyはlabel_stat_dictのkeyの文字列
# valueは内容の配列 要素の順番で内容の種類を定義する 1:見出し、2:本文、3:画像1のファイル名、4:画像2のファイル名、以下同様
    info_dict = {
        "yuanyangcha_trivia_gabalongcha": [_("ギャバロン茶"), _("【大森|おおもり】 【正司|まさし】教授が、まともな値段のつかなかった二番茶、三番茶を活用するために、生の茶葉を窒素ガスの中でしばらく保存したところ、γ-アミノ酪酸（英語名γ(gamma)-aminobutyric acid の頭文字をとった略称がGABA）が一般的な緑茶の20〜30倍になることを発見した。\nGABAの経口摂取は、高血圧患者の血圧を下げる作用や、肝臓のアルコール分解能を促進する作用、食後の急激な血糖値の上昇を抑制する作用があり、脳卒中の予防、認知症の予防にも効果がある。\n【大森|おおもり】 【正司|まさし】教授はGABAに烏龍茶の「ロン」を組み合わせて「ギャバロン茶」と命名して学会発表したものの、特許申請をしなかったことにより、複数の企業から「GABA」を冠した商品が出る「GABAブーム」が起きた。")],
        "yuanyangcha_trivia_oolong_tea": [_("「緑茶」「烏龍茶」「紅茶」の違い"), _("「緑茶」「烏龍茶」「紅茶」はすべて中国茶由来の言葉であり、中国茶では緑茶、白茶、黄茶、青茶、紅茶の順に発酵度合いが上がっていく。\n「烏龍茶」は中国茶の「青茶」の一種。")],
        "yuanyangcha_trivia_ferment_oxidation": [_("お茶の「発酵」は厳密には「付加反応」"), _("「烏龍茶」「紅茶」の製造過程で行われる「発酵」は「水と酸素による反応」であり、「有機物に対する微生物の反応」ではないため、厳密には「付加反応」。\nちなみに「有機物に対する微生物の反応」のうち、人間に有益なものが「発酵」、そうではないものが「腐敗」。\n製造過程で厳密な意味での「発酵」をさせるお茶は「黒茶」や「後発酵茶」と呼ばれる。\nちなみに、英語で「black tea」は紅茶を指し、黒茶や後発酵茶を指す場合は、発酵を意味するfermentから「fermented tea」や、黒茶の色の特性から「brown tea」と呼ぶ。")],
        "yuanyangcha_trivia_quality_season": [_("「クオリティーシーズン」は紅茶の収穫時期の違い"), _("香りや味が最も充実した良質な紅茶が期待できる季節のことを「クオリティーシーズン」と呼ぶ。\nダージリンの場合、ファーストフラッシュ（3月中旬～4月）、セカンドフラッシュ（5月～7月上旬）、オータムナル（10月～11月中旬）がクオリティーシーズンと呼ばれ、それぞれ異なる香りや味を楽しむことができる。\n緑茶でも同様の呼び分けがあり、5月に摘まれた「一番茶」を「煎茶」、それ以降に摘まれた「二番茶」以降を「番茶」と呼ぶ。")],
        "yuanyangcha_trivia_grade": [_("紅茶の「等級」は茶葉の形状と大きさ"), _("紅茶の等級とは、紅茶の製造過程で【篩|ふるい】のメッシュによって分けられた、葉の形状、大きさを表す言葉。\n茶葉の品質とは関係がない。\n紅茶の抽出時間（蒸らし時間）は、大きい葉なら長く、細かい葉なら短くなる。\n【篩|ふるい】にかけて同じ大きさの茶葉に揃えることで、抽出の時間も一定になり、バランスのよい味になる。\n「オレンジ・ペコー」が一番大きく、頭に「フラワリー」が付くと新芽の比率が高くなり、頭に「ブロークン」が付くとカットしたもの、末尾に「ファニングス」が付くとほとんど粉状になったもの、さらに細かくなると「ダスト」。\nほかに、機械で成型した「CTC」がある。")],
        "yuanyangcha_trivia_tea_species": [_("「中国種」と「アッサム種」"), _("「チャ」は「ツツジ目ツバキ科カメリア属の永年性常緑樹」のことで、飲用に使われるのは「中国種」と「アッサム種」の主に2種類。\n中国種は寒さに強く小葉で主に緑茶・烏龍茶向け、アッサム種は寒さに弱く大葉で紅茶（特にコクのあるタイプ）向け。")],
        "yuanyangcha_trivia_darjeeling": [_("「ダージリン」は紅茶の産地名"), _("「ダージリン」はチベット語で「雷の町」を意味し、1835年に在印イギリス軍の避暑地として発展した。\nそのフルーティな香りから「紅茶のシャンパン」と呼ばれることもある。")],
        "yuanyangcha_trivia_champagne": [_("「シャンパン」の語源も定義も地名"), _("「シャンパン」の語源はフランス北東部の「シャンパーニュ地方」。\n国際的な知的財産権として地理的表示に指定され、「シャンパーニュ地方で、定められた製法で作られた物」のみ「シャンパン」という名称を使うことができる。")],
        "yuanyangcha_trivia_earl_grey": [_("「アールグレイ」はベルガモットで香りをつけた紅茶"), _("「アールグレイ」は柑橘類の一種、ベルガモットで香りをつけたフレーバーティ。\n茶葉は主に中国種のキーマンが使われる。\n19世紀にイギリス首相を務めた政治家「チャールズ・グレイ伯爵」が紹介したことが名前の由来。")],
        "yuanyangcha_trivia_flavour_blend": [_("「フレーバーティー」と「ブレンドティー」の違い"), _("お茶以外のものを添加するのが「フレーバーティー」なのに対し、複数の茶葉を配合するのが「ブレンドティー」。\n各社が出している「ブレックファスト」「アフタヌーンティー」も「ブレンドティー」の一種。")],
        "yuanyangcha_trivia_cha_tea": [_("「チャ」と「ティー」の違い"), _("現在世界各国で使われている「茶」を意味する言葉は「チャ」か「ティー」の、いずれかに大別される。\nもとはどちらも中国で、広東語の「チャ」と福建語の「テー」が語源。\n「チャ」は陸路経由で、北は北京やモンゴルへ、西はチベット、インドを経て中近東各地、ロシアへと広まった。\n一方「テー」のほうは、福建の港・アモイで貿易を始めたオランダの影響が強く、イギリス、フランス、北欧各地など、海路で広まった。")],
        "yuanyangcha_trivia_yuanyangcha": [_("【鴛鴦茶|ユンヨンチャ】"), _("香港はかつてイギリスに占領されていたため、紅茶とコーヒーの消費量が多い。\nその香港で生まれたのが、紅茶とコーヒーを混ぜた飲み物「【鴛鴦茶|ユンヨンチャ】」。\n「【鴛鴦|ユンヨン】」は「オシドリのオスとメス」のこと。\n中国では男女同時に使うものや、二つが一つになったものの名前に「【鴛鴦|ユンヨン】」を付けることがある。")],
        "yuanyangcha_trivia_ceylon_lipton": [_("「セイロンティー」と「リプトン」はコーヒーさび病の産物"), _("スリランカは19世紀前半からコーヒーの産地だったが、1867年にコーヒーさび病が流行して壊滅した。\n放棄されたコーヒー農園を見たトーマス・リプトン卿が1890年に紅茶の栽培に転用したのが「セイロンティー」と「リプトン」の起源。")],
        "yuanyangcha_trivia_opium_war": [_("アヘン戦争の原因はイギリスの紅茶貿易"), _("茶を中国からの輸入にのみ頼っていたイギリスは、需要の増加によって、支払いにあてる銀貨が不足した。\nそこで、当時植民地だったインドのアヘンを、中国へ盛んに輸出するようになった。\nこの貿易による軋轢がアヘン戦争（1840-1842）を引き起こすことになった。")],
        "yuanyangcha_trivia_american_war_of_independencee": [_("アメリカ独立戦争の原因はイギリスの紅茶貿易"), _("18世紀後半、イギリスの植民地だったアメリカでは、本国同様に茶の消費が増加していた。\nしかし政府が課した茶税への反発から不買運動と密輸が広がり、茶の独占輸入権を持っていた東インド会社は大量の在庫を抱えてしまう。\n1773年、この在庫を安く販売するため東インド会社の関税を免除する「茶法（茶条例）」が制定されると、本国政府のでたらめな政策に反発した人々はボストンに入港した同社の船を襲い、積荷の茶を海に投げ捨ててしまうという事件を起こした。\nこれが「ボストン・ティーパーティー事件」であり、後にアメリカ独立戦争へと発展していった。")],
        "yuanyangcha_trivia_cafeaulait_cafelatte": [_("「カフェオレ」と「カフェラテ」の違い"), _("エスプレッソマシンが1902年のミラノ万博で発表されると、エスプレッソはイタリアを象徴する飲み物として、バール（立ち飲み可能なカフェ）で普及した。\nこれはコーヒーの飲み方の名前にも現れており、「カフェオレ」と「カフェラテ」はどちらも直訳すると「ミルク入りコーヒー」だが、フランス語の「カフェオレ」はベースがドリップコーヒーなのに対し、イタリア語の「カフェラテ」はベースがエスプレッソ。")],
        "yuanyangcha_trivia_cafelatte_cappuccino": [_("「カフェラテ」と「カプチーノ」の違い"), _("「カプチーノ」も「カフェラテ」と同じくイタリア語でエスプレッソがベース。\n「カプチーノ」と「カフェラテ」の違いは、「カプチーノ」は牛乳の泡の層が1cm以上あること。")],
        "yuanyangcha_trivia_cappuccino": [_("「カプチーノ」の語源"), _("「カプチーノ」はもとは「カトリック教会の一派であるカプチン会の修道士」のことを指す言葉で、その「カプチーノ」の語源は彼らが着るフードのついた修道服「カップッチョ（cappuccio、「頭巾、フード」の意）」。")],
        "yuanyangcha_trivia_cappucino_cheap": [_("「カプチーノ」が「カフェラテ」よりも安い理由"), _("「カプチーノ」が「カフェラテ」よりも安いことがあるのは、牛乳の泡の占める比率が高く、泡立てている分だけ原料の牛乳が少なくて済むから。")],
        "yuanyangcha_trivia_ice_coffee_expensive": [_("「アイスコーヒー」が「ホットコーヒー」よりも高い理由"), _("「アイスコーヒー」が「ホットコーヒー」よりも高いことがあるのは、飲み物の温度が低いと味覚が鈍るため、より多くコーヒー豆を使用しないと同じ濃さに感じられないから。")],
        "yuanyangcha_trivia_cafe_mocha": [_("「カフェモカ」の「モカ」はコーヒー豆の名前だが、そのコーヒー豆は使っていない"), _("「カフェモカ」はアメリカ生まれの飲み物で、イタリア風を意識したエスプレッソに牛乳とチョコレートソースを加えている。「カフェ」はコーヒーのことだが、「モカ」はチョコレートのことではない。\n「モカ」とは「イエメンの港『モカ』から出荷されるような、イエメンやエチオピア産のコーヒー豆」のこと。それを淹れた「モカコーヒー」は上品な味わいから「コーヒーの貴婦人」と呼ばれ、カカオ（チョコレート）に似た風味がある。\nつまり「カフェモカ」は、「モカ」ではないコーヒー豆にチョコレートを入れることで「モカコーヒー」に似せたもの。")],
        "yuanyangcha_trivia_vietnam_coffee": [_("ベトナムコーヒー"), _("ブラジルに次ぐコーヒーの産地であるベトナムでは、高温多湿でも育てられるロブスタ種が主に栽培されている。\nロブスタ種は臭みが強いため、現地では練乳を入れて飲むことが多く、そのような飲み方を「ベトナムコーヒー」と呼ぶことがある。")],
        "yuanyangcha_trivia_coffee_species": [_("「アラビカ種」と「ロブスタ種」"), _("「アラビカ種」は15世紀から数百年間「世界で唯一のコーヒー」であり、現在も世界の生産量の6,7割を占めているが、病害虫に弱く、高地でしか栽培できず、面積当たりの収穫量も少ないという欠点があった。\n19世紀末に東南アジアでコーヒーさび病が流行した際、すべての型のさび病に耐性を持つ唯一の種として見出されたのが「カネフォーラ種」であり、高い耐病性のほかにも、低地でも栽培可能、面積当たりの収穫量が多いことから、コーヒー業界では「頑強な」を意味する「ロブスタ」と名付けられた。\nロブスタ種の欠点は、出来上がったコーヒーの酸味と香りでアラビカ種に劣り、「ロブスタ臭」と呼ばれる独特の土臭さがあること。\nほかにも耐病性と美味しさの両立を目指した様々な種が存在するが、アラビカ種とロブスタ種だけで世界の生産量の9割以上を占めている。")],
        "yuanyangcha_trivia_balzac": [_("1日50杯コーヒーを飲んだ文豪"), _("『ゴリオ爺さん』を含む小説群『人間喜劇』で有名なオノレ・ド・バルザックは、毎日午前1時に起床し、1日に50杯のコーヒーを飲みながら小説を執筆、一段落すると社交界で暴食するか知人と遊ぶ生活を送っていた。\nそんな生活を送って健康でいられるはずがなく、晩年は失明し、腹膜炎が原因で51歳で亡くなった。")],
        "yuanyangcha_trivia_coffee_bean": [_("「コーヒー豆」は厳密には「豆」ではない"), _("コーヒーの原材料は「コーヒー豆」と呼ばれがちだが、「豆」は「マメ目マメ科」の植物の種子の総称。\n 「コーヒーノキ」は「リンドウ目アカネ科コーヒーノキ属」の植物なので、「コーヒー豆」は厳密には「コーヒーノキの種子」である。")],
        "yuanyangcha_trivia_kopi_luwak": [_("ネコの糞から採る「コピルアク」"), _("コーヒーの果実から生豆を取り出すには、生豆を覆っている果肉を取り除く「精製」を行う必要があり、インドネシアではコーヒーの果実を食べたジャコウネコの糞から、体内で消化されなかった生豆だけを集める「コピルアク」が生産されている。\n1995年にコピルアクを扱う会社の社長にイグノーベル賞が贈られたり、映画『かもめ食堂』(2006)や『最高の人生の見つけ方』(2007)ではキーアイテムになったりしたことで、知名度が上がっている。")],
        "yuanyangcha_trivia_kopi_luwak_altanative": [_("「コピルアク」以外の動物の糞から採るコーヒー"), _("動物の糞から採るコーヒーには他にも、インドでサルの糞から集める「モンキー・コーヒー」、ブラジルでジャクーという鳥の糞から集める「ジャクー・コーヒー」、タイでゾウの糞から集める「ブラック・アイボリー」が存在する。")],
        "yuanyangcha_trivia_coffee_kanji": [_("「珈琲」はコーヒーの実を髪飾りに見立てた当て字"), _("珈琲の「珈」は、当時の女性が髪をまとめるために使った「かみかざり」と読み、「花かんざし」を意味する漢字。\nそして「琲」の読み方は「つらぬく」。\nかんざしの飾り玉をつなぐ紐の意味で使われていた。\nつまり「珈琲」はもともと女性の髪を彩る「玉飾りのついた花かんざし」を意味する漢字だった\nコーヒーノキにたわわに実る赤い小さい実を、玉飾りのついた花かんざしに見立てて「珈琲」の字を当てたのが、江戸時代末期の蘭学者、【宇田川|うだがわ】 【榕菴|ようあん】。")],
        "yuanyangcha_trivia_angel's_share": [_("樽から蒸発した「【天使の取り分|エンジェルズ・シェア】」"), _("酒を熟成させるときに樽を使ったことで、樽から蒸発した水分やアルコール分を「【天使の取り分|エンジェルズ・シェア】」と呼ぶことがある。\n木製の樽で1年熟成すると、1〜3%程度が、「【天使の取り分|エンジェルズ・シェア】」として失われる。")],
        "yuanyangcha_trivia_devil's_cut": [_("樽に染み込んだ「【悪魔の取り分|デビルズ・カット】」"), _("酒を熟成させるときに樽を使ったことで、樽に染み込んで取り出せなかった酒を「【悪魔の取り分|デビルズ・カット】」と呼ぶことがある。\n「【悪魔の取り分|デビルズ・カット】」の量は、アルコール度数ではなく、樽の木の多孔性に影響を受ける。")],
        "yuanyangcha_trivia_devil's_cut_liqueur": [_("「【悪魔の取り分|デビルズ・カット】」という名前のお酒"), _("「デビルズカット」という、【悪魔の取り分|デビルズ・カット】そのままの名前のお酒をジム・ビームが製造しており、樽から抽出したバーボンをブレンドすることで、木材の香りをより強く楽しめる。")],
        "yuanyangcha_character_d": [_("【水神|みなかみ】 【南|みなみ】"), _("警視庁 捜査一課所属。\n水神財閥の一族の三女。\n無類の女好き。\nお茶派。")],
        "yuanyangcha_character_a": [_("【濁澤|にごりさわ】ニコル"), _("警視庁 捜査一課所属。\n【水神|みなかみ】 【南|みなみ】とは幼馴染。\nハッキングが得意。\nコーヒー派。")],
        "yuanyangcha_character_coffee": [_("【竜胆|りんどう】 【茜|あかね】"), _("警視庁 鑑識課所属。\n【躑躅|つつじ】 【椿|つばき】とルームシェアしている。\nコーヒー派。")],
        "yuanyangcha_character_yuzu": [_("【松風|まつかぜ】 【柚子|ゆず】"), _("桜月大学 薬学部 【松風|まつかぜ】研究室の室長。\n疲労研究の第一人者。\nコーヒー派。")],
        "yuanyangcha_character_tea": [_("【躑躅|つつじ】 【椿|つばき】"), _("桜月大学 薬学部 【松風|まつかぜ】研究室所属の博士研究員。\n【竜胆|りんどう】 【茜|あかね】とルームシェアしている。\nお茶派。")],
        "yuanyangcha_character_chen": [_("ジャシー・チェン"), _("桜月大学 薬学部 【松風|まつかぜ】研究室所属の博士研究員。\n故郷の香港への愛があふれている。\nコーヒー派。")],
        "yuanyangcha_character_robusta": [_("【菊苦菜|きくにがな】 ちこり"), _("桜月大学 薬学部 【松風|まつかぜ】研究室所属の博士研究員。\n誰よりも早くから、誰よりも遅くまで研究室にいる。\nコーヒー派。")],
        "yuanyangcha_character_gal": [_("【毛利|もうり】 【森子|もりこ】"), _("警視庁 捜査一課所属。\n最近はまつ毛の盛りにハマっている。\n映えれば何で飲むが、最近は紅茶派。")],
        "yuanyangcha_character_matcha": [_("【町矢|まちや】 【抹茶|まっちゃ】"), _("警視庁 捜査一課所属。\n茶道 裏千家の家系。\nお茶派。")],
        "yuanyangcha_clue_yuzu_drink_when": [_("服薬推定時刻は15時"), _("死亡時刻は19時。\n毒は無味無臭で、服薬して4時間で死に至るため、服薬推定時刻は15時。")],
        "yuanyangcha_clue_time_table": [_("実験室と執務室の入退室のタイムテーブル"), _("【松風|まつかぜ】 【柚子|ゆず】教授は13時から、意識不明で搬送された17時まで執務室にいる。\nそして、15時に【躑躅|つつじ】 【椿|つばき】、ジャシー・チェン、【菊苦菜|きくにがな】 ちこりの3人が入れ違いに執務室を訪れている。"), _("yuanyangcha_time_table.jpg")],
        "yuanyangcha_clue_poison_official_mug": [_("毒が検出されたカップは大学生協の公式マグカップ"), _("つまり、誰でも簡単に入手できる。")],
        "yuanyangcha_clue_tea_fingerprint_saliva": [_("毒が検出されたカップから【躑躅|つつじ】 【椿|つばき】の唾液と指紋を検出"), _("【躑躅|つつじ】 【椿|つばき】が第一容疑者となった原因。")],
        "yuanyangcha_clue_poison_tea_coffee": [_("毒を入れた飲み物は紅茶とコーヒー"), _("紅茶もコーヒーも残量の1/3以上を占めている。")],
        "yuanyangcha_clue_poison_robusta": [_("毒を入れたコーヒーは100％ロブスタ種"), _("日本でもロブスタ種は流通しているが、100％で飲むことは珍しい。")],
        "yuanyangcha_clue_professor_note": [_("【松風|まつかぜ】 【柚子|ゆず】の研究ノート"), _("自身の研究の実験結果だけでなく、面談の内容も記載されている。")],
        "yuanyangcha_clue_professor_note_lost": [_("【松風|まつかぜ】 【柚子|ゆず】の研究ノートの紛失"), _("バッグや執務室を探しても見つからなかった。\n事件当日の17時以降に犯人が隠した可能性が高い。")],
        "yuanyangcha_clue_yuzu_cup": [_("【松風|まつかぜ】 【柚子|ゆず】のカップは大学生協の公式マグカップ"), _("おそらくは愛校心から。")],
        "yuanyangcha_clue_tea_drink": [_("【躑躅|つつじ】 【椿|つばき】の飲み物は紅茶"), _("正確には、ベルガモット香料で香り付けした、ファーストフレッシュ、オレンジペコーのダージリンと、牛乳と砂糖。")],
        "yuanyangcha_clue_tea_cup": [_("【躑躅|つつじ】 【椿|つばき】のカップは大学生協の公式マグカップ"), _("アイディアを思いついた衝撃でマグカップを割り、その替えを大学生協で買って以来、そのまま。")],
        "yuanyangcha_clue_tea_habit": [_("【躑躅|つつじ】 【椿|つばき】の優雅なティータイム"), _("【躑躅|つつじ】 【椿|つばき】は毎日12時に実験室の遠心分離機を回し、タイマーが鳴るまでの15分間に、水筒を持って給湯室に移動し、携帯食料と紅茶を一服し、カップを洗う習慣がある。")],
        "yuanyangcha_clue_tea_cup_200ml": [_("【躑躅|つつじ】 【椿|つばき】の飲み残しは200ml"), _("かなり大量に飲み残している。")],
        "yuanyangcha_clue_tea_bottle_100ml": [_("【躑躅|つつじ】 【椿|つばき】の水筒が100mlから空に"), _("飲み残しの量の半分しかない。")],
        "yuanyangcha_clue_tea_paper": [_("【躑躅|つつじ】 【椿|つばき】の論文の過小評価疑惑"), _("【躑躅|つつじ】 【椿|つばき】の単著でもおかしくないが、【松風|まつかぜ】 【柚子|ゆず】教授との共著になっている。")],
        "yuanyangcha_clue_chen_arabica": [_("ジャシー・チェンの飲み物は100％アラビカ種のコーヒー"), _("とても上品な香りがする。")],
        "yuanyangcha_clue_chen_tea": [_("ジャシー・チェンはティーバッグを持っている"), _("いつコーヒーに紅茶を混ぜたくなっても大丈夫。")],
        "yuanyangcha_clue_chen_cup": [_("ジャシー・チェンのカップは「I♡香港」"), _("故郷の香港に対する愛情があふれている。")],
        "yuanyangcha_clue_chen_paper": [_("ジャシー・チェンの論文の横領疑惑"), _("謝辞に記載されていない助成金を受け取ったのは、ジャシー・チェンと【松風|まつかぜ】 【柚子|ゆず】教授のどちらだろうか？")],
        "yuanyangcha_clue_robusta_smell": [_("【菊苦菜|きくにがな】 ちこりは嗅覚に障害がある"), _("アロマオイルの匂いが充満していることにも気づかなかった。")],
        "yuanyangcha_clue_robusta_arrival": [_("【菊苦菜|きくにがな】 ちこりだけ1時間早く実験室に到着"), _("誰よりも早く始め、誰よりも遅くまで残っている。")],
        "yuanyangcha_clue_robusta_drink": [_("【菊苦菜|きくにがな】 ちこりの飲み物は100％ロブスタ種のコーヒー"), _("日本でもロブスタ種は流通しているが、100％で飲むことは珍しい。")],
        "yuanyangcha_clue_robusta_cup": [_("【菊苦菜|きくにがな】 ちこりのカップはタンブラー"), _("北海道のローカル番組か、ゆるいアニメの影響。")],
        "yuanyangcha_clue_robusta_paper": [_("【菊苦菜|きくにがな】 ちこりの論文の捏造疑惑"), _("データの数字の分布が人工的過ぎて、自然界の分布である「ベンフォードの法則」とはかけ離れている。")],
        "yuanyangcha_clue_poison_anyone": [_("毒はだれでも入手できた"), _("殺鼠剤は危険なので、厳重に管理しましょう。")],
        "yuanyangcha_clue_interview": [_("月次の個人面談"), _("【松風|まつかぜ】研究室の研究員は、毎月第4火曜日に教授と個人面談をすることになっている。")],
        "yuanyangcha_clue_remind_mail": [_("月次の個人面談のリマインドメール"), _("「皆さんの論文を読み返して気づいたことがあったので、お話ししましょう。」とある。")],
        "yuanyangcha_clue_shelf_hide": [_("給湯室の棚には誰でも隠れられる"), _("大柄なニコルが1人入っても、大丈夫。")],
        "yuanyangcha_clue_kitchenette_dark": [_("給湯室は暗い"), _("カップや水筒の中身の色を確認することはできない。")],
        "yuanyangcha_clue_timer_shorten": [_("誰かが遠心分離機のタイマーを5分に変更した"), _("ログで確認。\n【躑躅|つつじ】 【椿|つばき】が給湯室にカップと水筒を放置する原因となった。")],
        "yuanyangcha_clue_timer_log_edit": [_("誰かが「タイマーを5分に変更」の操作日時を「11時45分」に書き換えた"), _("「11時45分」にアリバイがある人物の犯行だと思われる。")],
    }

define a = Character("【濁澤|にごりさわ】ニコル", color="#fdaf56")
define coffee = Character("【竜胆|りんどう】 【茜|あかね】", color="#ca3c37")
define tea = Character("【躑躅|つつじ】 【椿|つばき】", color="#ce643b")
define robusta = Character("【菊苦菜|きくにがな】 ちこり", color="#b38962")
define chen = Character("ジャシー・チェン", color="#cf4d4d")
define yuzu = Character("【松風|まつかぜ】 【柚子|ゆず】", color="#cfbf2d")
define gal = Character("【毛利|もうり】 【森子|もりこ】", color="#db6ab9")
define matcha = Character("【町矢|まちや】 【抹茶|まっちゃ】", color="#9e40d4")

image detective = "detective.png"
image side detective = "side_detective.png"
image side detective normal = "side_detective.png"
image side detective desired = "side_detective_desired.png"
image side detective happy = "side_detective_happy.png"
image side detective angry = "side_detective_angry.png"
image side detective surprised = "side_detective_surprised.png"
image side detective concerned = "side_detective_concerned.png"

image assistant = "assistant.png"
image coffee = "coffee.png"
image tea = "tea.png"
image robusta = "robusta.png"
image chen = "chen.png"
image gal = "gal.png"
image matcha = "matcha.png"

transform r:
    xpos 0.2

transform l:
    xpos -0.2

default clue_adj = ui.adjustment()
default chara_adj = ui.adjustment()
default trivia_adj = ui.adjustment()

# label ステートメント（文）はゲームの処理をまとめてラベル付けします。\n
# ラベル間の移動は jump ステートメントか call ステートメントを使います。\n
# ゲームは start ラベルからスタートします。\n
label start:

    # 背景を表示します。\nデフォルトではプレースホルダー（仮画像）を使用しますが、
    # images ディレクトリーにファイル（ファイル名は "bg room.png" や "bg room.jpg"）
    # を追加することで表示できます。\n

    scene bg sample

    # スプライト（立ち絵）を表示します。\nここではプレースホルダーを使用していますが、
    # images ディレクトリーに "eileen happy.png" などと命名したファイルを追加すると
    # 表示することができます。\n

    # at ステートメントは画像の表示する位置を調整します。\n
    # at center は中央に下揃えで表示します。\nこれは省略しても同じ結果になります。\n
    # その他に at r、at left などがデフォルトで定義されています。\n

    # show eileen happy at center

    # トランジション（画面遷移効果）を使って表示を画面に反映させます。\n
    # 台詞を表示するか with None を使うと、トランジション無しで直ちに表示します。\n

    # with dissolve

    # 音楽を再生します。\n
    # game ディレクトリーに "music.ogg" などのファイルを追加すると再生できます。\n

    # play music "music.ogg"

    # 以下は台詞を表示します。\n
    # call input(_("あなたの名前を入力してください。"), _("ああああ"))

    # $ d = Character("[_return]", kind=d)
    # $ m = Character("[_return]", kind=m)
    $ d = Character("【水神|みなかみ】 【南|みなみ】", kind=d)
    $ m = Character("【水神|みなかみ】 【南|みなみ】", kind=m)

    # トリビア以外のすべての状態を未完了にする
    python:
        i = 0
        key_list = list(label_stat_dict.keys())
        while i < len(key_list):
            key = key_list[i]
            if "_trivia_" in key:
                i = i + 1
            else:
                label_stat_dict[key] = 0
                i = i + 1


    jump yuanyangcha_trailer
    # return でゲームを終了します。\n

label input(text, default):
    python:
        input_str = renpy.input(text)

        input_str = input_str.strip() or __(default)

    call screen confirm(_("「[input_str]」でよろしいでしょうか？"), Return(input_str), Call("input", text, default))
    return _return

label yuanyangcha_trailer:
    show yuanyangcha trailer:
        xpos 0.0 ypos -1.2
        linear 5.0 xpos 0.0 ypos 0.0
    "桜月大学の研究室で毒殺事件が発生"
    "毒殺に使われた飲み物は【鴛鴦茶|ユンヨンチャ】？！"
    "なぜ犯人は紅茶とコーヒーを混ぜてから毒を盛ったのか？"
    jump yuanyangcha_hangout

label yuanyangcha_hangout:
    scene bg police office
    tp "8月25日（火） 11:00\n警視庁 捜査一課 執務室"
    "捜査一課の警察官は複数の事件を同時に担当しているため、現場に出ない日も、裁判に必要な書類の作成に忙殺されることになる。"
    "デスクに書類を広げていると、鑑識課の【竜胆|りんどう】 【茜|あかね】からメールが来た。"
    "送り先には【濁澤|にごりさわ】ニコルも入っている。"
    show coffee at center with dissolve:
        matrixcolor SepiaMatrix()
    tea "{color=[gui.machine_color]}「お二人に相談したいことがあるので、第四取調室に来ていただけますでしょうか？」{/color}"
    hide coffee
    "会議室を抑えるほどではない打ち合わせで、取調室を使うことは珍しくない。"
    "隣席の【濁澤|にごりさわ】ニコルが声をかけてきた。"
    show assistant at center with dissolve
    a "せっかくだし、【竜胆|りんどう】 【茜|あかね】に飲み物でも持っていくか？"
    d happy "ええ、こんなときは「ギャバロン茶」ですね。"
    a "「ギャバロン茶」？"
    d normal "生の茶葉を窒素ガスの中でしばらく保存することで、「GABA」の含有量が数十倍になったお茶のことです。"
    a "「GABA」の含有量を【謳|うた】った商品、いろんな企業からが出てるな。"
    d happy "「ギャバロン茶」の発明者があえて特許申請しなかったことがGABAブームのきっかけですよ。"
    d normal "ちなみに、「ギャバロン茶」の「ロン」は「烏龍茶」のことですね。"
    a "そういえば、「烏龍茶」って「緑茶」や「紅茶」と何が違うんだ？"
    d "「緑茶」「烏龍茶」「紅茶」の違いは発酵度合いだけです。"
    d "中国茶では「緑茶」「白茶」「黄茶」「青茶」「紅茶」の順に発酵度合いが上がっていき、「烏龍茶」は「青茶」の一種ですね。"
    d concerned "もっとも、お茶の「発酵」は厳密には「発酵」ではなく「付加反応」なのですが……。"
    a "でもさ、せっかくエスプレッソ・マシンがあるんだから、アイスカフェラテだろ。"
    d concerned "そもそも「カフェオレ」と「カフェラテ」ってどちらも「コーヒーと牛乳」ではありませんか？"
    a "いい質問だ。\nまず、コーヒーの抽出法には主にドリップとエスプレッソの2種類ある。"
    a "そして、1902年のミラノ万博でエスプレッソ・マシンが発表されたことで、エスプレッソはイタリアを代表する飲み物になった。"
    a "つまり、フランス語の「カフェオレ」はドリップ、イタリア語の「カフェラテ」はエスプレッソがそれぞれベースなんだ。"
    a "同様に、「カプチーノ」もイタリア語だからエスプレッソがベースで、「カフェラテ」との違いは牛乳の泡の層が1cm以上あることだ。"
    a "ちなみに、「カプチーノ」はもとは「カプチン会の修道士」のことで、その語源はフードのついた修道服「カップッチョ」だ。"
    d normal "そういえば、喫茶店ですと「カプチーノ」が「カフェラテ」よりも安価なことがありますね。"
    a "「カプチーノ」は牛乳の泡の占める比率が高くて、泡立てている分だけ原料の牛乳が少なくて済むからな。"
    a "「アイスコーヒー」が「ホットコーヒー」よりも高いことがあるのも、原材料の量の違いだ。"
    a "飲み物が冷たいと味覚が鈍るから、より大量のコーヒー豆を使わないと、同じ濃さに感じられないんだよ。"
    d surprised "そういえば、【竜胆|りんどう】 【茜|あかね】を待たせたままではありませんか？"
    a "しゃあねえ、じゃんけんで決めるぞ！"
    d happy "受けて立ちますよ！"
    $ label_stat_dict["yuanyangcha_character_d"] = 2
    $ label_stat_dict["yuanyangcha_character_a"] = 2
    $ label_stat_dict["yuanyangcha_trivia_gabalongcha"] = 2
    $ label_stat_dict["yuanyangcha_trivia_oolong_tea"] = 2
    $ label_stat_dict["yuanyangcha_trivia_ferment_oxidation"] = 2
    $ label_stat_dict["yuanyangcha_trivia_cafeaulait_cafelatte"] = 2
    $ label_stat_dict["yuanyangcha_trivia_cafelatte_cappuccino"] = 2
    $ label_stat_dict["yuanyangcha_trivia_cappuccino"] = 2
    $ label_stat_dict["yuanyangcha_trivia_cappucino_cheap"] = 2
    $ label_stat_dict["yuanyangcha_trivia_ice_coffee_expensive"] = 2
    show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_coffee_arrival

label yuanyangcha_coffee_arrival:
    scene bg interrogation room
    tp "同日 11:10\n警視庁 第四取調室"
    show coffee as coffee at r
    show assistant as a at l
    with dissolve
    "第四取調室にいたのは【竜胆|りんどう】 【茜|あかね】だけだった。\nやはり非公式な打ち合わせのようだ。"
    menu:
        "じゃんけんの結果、【竜胆|りんどう】 【茜|あかね】に振る舞うことになったのは？"
        "紅茶":
            jump yuanyangcha_coffee_tea
        "コーヒー":
            jump yuanyangcha_coffee_coffee

label yuanyangcha_coffee_tea:
    d happy "アイスティーをどうぞ。"
    coffee "「お茶出し」というように、普通はお茶ですよね。\nコーヒーが飲めない人も多いでしょうし。"
    "【竜胆|りんどう】 【茜|あかね】は苦々しい顔をしながら一気飲みした。"
    jump yuanyangcha_coffee_request

label yuanyangcha_coffee_coffee:
    a "ほら、アイスカフェラテだ。"
    coffee "ありがとうございます。\nコーヒーには目がないもので。"
    "【竜胆|りんどう】 【茜|あかね】は味わいながら飲んだ。"
    jump yuanyangcha_coffee_request

label yuanyangcha_coffee_request:
    coffee "単刀直入に申し上げますと、お二人には「【松風|まつかぜ】 【柚子|ゆず】教授毒殺事件」の調査に協力してほしいのです。"
    coffee "本来なら私も捜査に参加していたはずでしたが、第一容疑者が私のルームシェア相手の【躑躅|つつじ】 【椿|つばき】でして……。"
    coffee "犯罪捜査規範14条の定めるところにより、私は捜査本部から外されてしまいました。"
    coffee "あの人は常識が欠如していますが、「コーヒーを飲むこと」と「人殺し」だけは絶対にしません。\n何かの間違いです。"
    coffee "どうか、彼女への疑いを晴らしていただけないでしょうか？"
    coffee "私にできることなら、なんでもしますので。"
    d desired "「なんでも」というと、たとえばデートからの休憩からの……"
    a "こいつの妄想は無視してくれ。\nあとで書類作成を手伝ってくれればいいから。"
    d happy "【竜胆|りんどう】 【茜|あかね】さんには常日頃からお世話になっておりますからね。\n夜のネタとしても。"
    a "息を吸うようにセクハラすんな！"
    coffee "とにかく、ありがとうございます！"

label yuanyangcha_coffee_drive:
    scene bg car
    with None

    show assistant at l
    show coffee at r
    with dissolve
    "【竜胆|りんどう】 【茜|あかね】はボクたちを警察車両に乗せると、運転しながら事件の概要を話しだした。"
    coffee "被害者は桜月大学で【松風|まつかぜ】研究室の室長をしている【松風|まつかぜ】 【柚子|ゆず】教授です。\n専門は薬学です。"
    coffee "毒殺に使われた薬品はマウスの殺処分に使うもので、無味無臭、人間が摂取した場合は4時間で死に至ります。"
    coffee "死亡時刻は19時なので、服薬推定時刻は15時です。"
    coffee "その薬品は{color=[gui.keyword_color]}大学生協の公式マグカップ{/color}から検出されたので、おそらく犯人はなんらかの飲み物に毒を混ぜて飲ませたのでしょう。"
    coffee "【躑躅|つつじ】 【椿|つばき】が第一容疑者になったのは、そのマグカップから彼女の唾液と指紋も検出されたからです。"
    d concerned "1つのカップから2人の唾液、つまりはそういう関係ということでしょうか？"
    a "たとえ恋仲でも、2人で同じカップは使い回さねぇだろ。"
    "ニコルにツッコまれると、車は事件現場の桜月大学に到着した。"
    $ label_stat_dict["yuanyangcha_coffee_encounter"] = 1
    $ label_stat_dict["yuanyangcha_character_coffee"] = 2
    $ label_stat_dict["yuanyangcha_character_yuzu"] = 2
    $ label_stat_dict["yuanyangcha_clue_yuzu_drink_when"] = 2
    $ label_stat_dict["yuanyangcha_clue_poison_official_mug"] = 2
    $ label_stat_dict["yuanyangcha_clue_tea_fingerprint_saliva"] = 2
    $ tempClue1 = info_dict["yuanyangcha_clue_yuzu_drink_when"][0]
    $ tempClue2 = info_dict["yuanyangcha_clue_poison_official_mug"][0]
    $ tempClue3 = info_dict["yuanyangcha_clue_tea_fingerprint_saliva"][0]
    show screen clue_notify(["[tempClue1]", "[tempClue2]", "[tempClue3]"])
    show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_reserch

label yuanyangcha_reserch:
    scene bg corridor
    call yuanyangcha_show_todo_list
    menu:
        "行きたい場所を選んでください。"
        "警備室":
            jump yuanyangcha_security
        "給湯室" if label_stat_dict["yuanyangcha_tea_encounter"] >= 1:
            jump yuanyangcha_kitchenette
        "実験室" if label_stat_dict["yuanyangcha_chen_encounter"] >= 1:
            jump yuanyangcha_laboratory
        "執務室" if label_stat_dict["yuanyangcha_robusta_encounter"] >= 1:
            jump yuanyangcha_office

label yuanyangcha_security:
    scene bg security room
    with None

    if label_stat_dict["yuanyangcha_coffee_encounter"] == 1:
        jump yuanyangcha_coffee_encounter

    menu:
        "調べる":
            jump yuanyangcha_security_research
        "話す":
            jump yuanyangcha_security_talk
        "戻る":
            jump yuanyangcha_reserch

label yuanyangcha_coffee_encounter:
    scene bg security room
    with None

    tp "同日 12:00\n桜月大学 警備室"
    
    "【竜胆|りんどう】 【茜|あかね】の案内は、桜月大学の警備室までだった。"
    show coffee at center
    with dissolve
    coffee "私が容疑者と接触したり、ましてや研究室の監視カメラに写ってしまうと【躑躅|つつじ】 【椿|つばき】の不利になるので、私が同行できるはここまでです。"
    coffee "私はここで待機しているので、捜査本部で押収済みの証拠品について確認したくなったら、こちらにいらしてください。"
    coffee "微力ながら、草葉の陰から応援させていただきます。"
    m concerned "勝手にお亡くなりにならないでください"
    $ label_stat_dict["yuanyangcha_security_research_camera"] = 1
    $ label_stat_dict["yuanyangcha_coffee_encounter"] = 2
    jump yuanyangcha_security

label yuanyangcha_security_research:
    scene bg security room
    with None

    menu:
        "調べたい場所を選んでください。"
        "監視カメラの映像":
            jump yuanyangcha_security_research_camera
        "映画のポスター":
            jump yuanyangcha_security_research_poster
        "戻る":
            jump yuanyangcha_security

label yuanyangcha_security_research_camera:
    scene bg security room
    with None

    d normal "やはり、監視カメラの映像は気になりますね。"
    show coffee at r
    coffee "危険な薬品や貴重な資料を保管している部屋、今回ですと、実験室と執務室の入口には監視カメラがあります。"
    coffee "事件当日の実験室と執務室の入退室のタイムテーブルがあるので、お見せしますね。"
    # タイムテーブルの画像を作成して表示する
    show assistant at l
    a "被害者の【松風|まつかぜ】 【柚子|ゆず】は13時から、意識不明で搬送された17時まで執務室にいるな。"
    a "そして、15時に【躑躅|つつじ】 【椿|つばき】、ジャシー・チェン、【菊苦菜|きくにがな】 ちこりの3人が入れ違いに執務室を訪れている。"
    m normal "服薬推定時刻に被害者と接触したのはこの3人ですか"
    if label_stat_dict["yuanyangcha_security_research_camera"] <= 1:
        $ label_stat_dict["yuanyangcha_security_research_camera"] = 2
        $ label_stat_dict["yuanyangcha_clue_time_table"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_time_table"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_security_research

label yuanyangcha_security_research_poster:
    scene bg security room
    with None

    d normal "映画のポスターが貼ってありますね。"
    show assistant at center
    a "『最高の人生の見つけ方』か。\n日本でリメイクされたこともある名作だ。"
    a "余命わずかの自動車整備士と大富豪が死ぬまでにやりたいことリストを作って思い出づくりする話なんだが、キーアイテムとして「コピルアク」というコーヒーが出てくる。"
    d concerned "「コピルアク」？"
    a "コーヒーの果実を食べたジャコウネコの糞から、消化されなかった生豆を集めた、インドネシアのコーヒーだ。\n「世界一高いコーヒー」としてイグノーベル抹茶養学賞をとったこともある。"
    a "動物の糞から採るコーヒーには他にも、インドでサルの糞から集める「モンキー・コーヒー」、ブラジルでジャクーという鳥の糞から集める「ジャクー・コーヒー」、タイでゾウの糞から集める「ブラック・アイボリー」が存在するな。"
    d surprised "動物性愛と糞便性愛の複合でしょうか？"
    a "珍味への探求心を性欲扱いすんな！\nあと、生豆はパウチで覆われているし、ちゃんと洗ったあとに焙煎するから衛生的だ！"
    m concerned "怒られてしまいました"
    if label_stat_dict["yuanyangcha_security_research_poster"] <= 1:
        $ label_stat_dict["yuanyangcha_security_research_poster"] = 2
        $ label_stat_dict["yuanyangcha_trivia_kopi_luwak"] = 2
        $ label_stat_dict["yuanyangcha_trivia_kopi_luwak_altanative"] = 2
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_security_research

label yuanyangcha_security_talk:
    scene bg security room
    with None

    menu:
        "聞きたいことを選んでください。"
        "毒を入れた飲み物":
            jump yuanyangcha_security_talk_poison_drink
        "毒を入れたコーヒーの種類" if label_stat_dict["yuanyangcha_security_talk_coffee_kind"] >= 1:
            jump yuanyangcha_security_talk_coffee_kind
        "髪飾り":
            jump yuanyangcha_security_talk_coffee_hairpin
        "戻る":
            jump yuanyangcha_security

label yuanyangcha_security_talk_poison_drink:
    scene bg security room
    with None

    d normal "毒が検出されたマグカップの中身について、詳しくお聞かせ願えますか？"
    show coffee at r
    coffee "はい。\n【松風|まつかぜ】 【柚子|ゆず】と【躑躅|つつじ】 【椿|つばき】の唾液と指紋のほかに、牛乳と砂糖、{color=[gui.keyword_color]}紅茶{/color}と{color=[gui.keyword_color]}コーヒー{/color}が検出されました。"
    show assistant at l
    a "{color=[gui.keyword_color]}紅茶{/color}と{color=[gui.keyword_color]}コーヒー{/color}？\nどちらか片方は洗い残しとかじゃなねえよな？"
    coffee "いえ、どちらも残量の1/3以上を占めています。"
    a "は？\nわけがわからん。"
    d concerned "イギリスからの重税に苦しんでいたのでしょうか？"
    a "コーヒーカップはボストン港じゃねぇんだよ。"
    m normal "いずれにせよ、この事件の大きな手がかりになりそうですね"
    if label_stat_dict["yuanyangcha_security_talk_poison_drink"] <= 1:
        $ label_stat_dict["yuanyangcha_security_talk_poison_drink"] = 2
        if label_stat_dict["yuanyangcha_tea_encounter"] == 0:
            $ label_stat_dict["yuanyangcha_tea_encounter"] = 1
        $ label_stat_dict["yuanyangcha_clue_poison_tea_coffee"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_poison_tea_coffee"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_security_talk

label yuanyangcha_security_talk_coffee_kind:
    scene bg security room
    with None


    d normal"匂いの成分から、毒を入れたコーヒーの種類を絞り込めるのではありませんか？"
    show coffee at r
    coffee "なるほど。\n捜査資料の共有フォルダにアクセスしますね。"
    coffee "マグカップに残された飲み物の匂い成分を鑑識が解析した結果がありますね"
    coffee "紅茶については『【躑躅|つつじ】 【椿|つばき】の水筒の中のアールグレイと同じ』という照合がされていますが、コーヒーについては手つかずです。"
    coffee "以前趣味で調べたのですが、{color=[gui.keyword_color]}アラビカ種{/color}はグリーンな香調の成分とキャッティーな香調の成分が多く、{color=[gui.keyword_color]}ロブスタ種{/color}はナッティーな香調の成分とスモーキーな香調の成分が多いそうです"
    coffee "せめて{color=[gui.keyword_color]}アラビカ種{/color}と{color=[gui.keyword_color]}ロブスタ種{/color}の比率だけでもわかると嬉しいのですが……。"
    d desired "{color=[gui.keyword_color]}アラビカ種{/color}の「キャッティー」な香りというのは、「ネコ」みたいな香りということでしょうか？\nボクは「タチ」も「ネコ」もイケますが。"
    show assistant at l
    a "お前の夜のポジションは聞いてねぇよ。"
    coffee "出ました。\nナッティーな香調の成分とスモーキーな香調の成分が圧倒的に多いです。"
    coffee "これだけ{color=[gui.keyword_color]}ロブスタ種{/color}の比率が高いコーヒーは日本では珍しいですね。"
    m normal "事件解決に大きく近づきましたね"
    if label_stat_dict["yuanyangcha_security_talk_coffee_kind"] <= 1:
        $ label_stat_dict["yuanyangcha_security_talk_coffee_kind"] = 2
        $ label_stat_dict["yuanyangcha_clue_poison_robusta"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_poison_robusta"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_security_talk

label yuanyangcha_security_talk_coffee_hairpin:
    scene bg security room
    with None

    d normal "【竜胆|りんどう】 【茜|あかね】さんはいつも特徴的なかんざしを着けていますね。"
    show coffee at r
    coffee "「珈琲」という当て字は、コーヒーノキにたわわに実る赤い小さい実を、玉飾りのついた花かんざしに見立てたものなんです。"
    coffee "それを知った【椿|つばき】は、私がコーヒーを飲めないときも頑張れるように、このかんざしをプレゼントしてくれました。"
    coffee "私の大事な宝物です。"
    d desired "ボクは「たわわ」な胸も「たおやか」な胸も好きです。"
    show assistant at l
    a "割って入ろうとすんな。"
    m normal "【竜胆|りんどう】 【茜|あかね】さんのためにも、この事件を解決しないといけませんね"
    if label_stat_dict["yuanyangcha_security_talk_coffee_hairpin"] <= 1:
        $ label_stat_dict["yuanyangcha_security_talk_coffee_hairpin"] = 2
        $ label_stat_dict["yuanyangcha_trivia_coffee_kanji"] = 2
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_security_talk

label yuanyangcha_kitchenette:
    scene bg kitchenette
    with None

    if label_stat_dict["yuanyangcha_tea_encounter"] == 1:
        jump yuanyangcha_tea_encounter

    menu:
        "調べる":
            jump yuanyangcha_kitchenette_research
        "話す":
            jump yuanyangcha_kitchenette_talk
        "戻る":
            $ update_todo = True
            jump yuanyangcha_reserch

label yuanyangcha_tea_encounter:
    scene bg kitchenette
    with None

    tp "同日 12:10\n桜月大学 給湯室"

    "警備員室を出ると、黒いセーラー服風の女性が給湯室の前で待ち構えていた。"
    show tea at center
    with dissolve
    tea "私は【躑躅|つつじ】 【椿|つばき】。\nそして、君たちは私に用があるのだろう。"
    tea "給湯室で優雅なティータイムを過ごしていたら、【茜|あかね】君の声がしてね。"
    tea "しかし、私のルームメイトである【茜|あかね】君は本来ここにいてはならない。"
    tea "つまり、君たちは警察関係者で、教授が死亡した事件の調査を【茜|あかね】君に依頼された。\nそうだろう？"
    m normal "【竜胆|りんどう】 【茜|あかね】さん、個性的な方と同棲されているのですね"
    $ label_stat_dict["yuanyangcha_tea_encounter"] = 2
    $ label_stat_dict["yuanyangcha_character_tea"] = 2
    $ label_stat_dict["yuanyangcha_kitchenette_talk_yesterday"] = 1
    call yuanyangcha_show_todo_list
    show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_kitchenette

label yuanyangcha_kitchenette_research:
    scene bg kitchenette
    with None

    menu:
        "調べたい場所を選んでください。"
        "棚":
            jump yuanyangcha_kitchenette_research_shelf
        "流し台":
            jump yuanyangcha_kitchenette_research_colander_microwave
        "戻る":
            jump yuanyangcha_kitchenette

label yuanyangcha_kitchenette_research_shelf:
    scene bg kitchenette
    with None

    "給湯室の流し台の下に、大きな棚がある。"
    "扉は木製で、外から中を見ることはできない。"
    "開けてみると、中身は少なく、仕切りがないため、人が隠れられそうだ。"
    d normal "ニコル、このなかに入っていただいてもよろしいですか？"
    show assistant at center
    a "はぁ？\n小柄なお前のほうがお似合いだろ。"
    d normal "ボクが入れたとしても、ボクより大柄な容疑者が入れるかどうかはわからないでしょう？"
    d normal "それを確認するためには、ニコルにも入っていただく必要があります。"
    d normal "そして、ニコルが入れたら、ボクは入る必要がない。"
    d normal "効率の問題ですよ。"
    a "しゃあねぇな。"
    m normal "もしもニコルが入れなかったらボクも入る必要がありますが、黙っておきましょう"
    a "かなり狭いが、入れなくはねぇな。"
    m desired "シャッターチャンスです！"
    "フラッシュを焚きながら激写した。"
    a "おい、やめろ！\n消せ！"
    d normal "貴重な証拠ですからね。\n削除できかねます。"
    a "はめられた……。"
    m happy "あとで待ち受け画面に設定しましょう"
    if label_stat_dict["yuanyangcha_kitchenette_research_shelf"] <= 1:
        $ label_stat_dict["yuanyangcha_kitchenette_research_shelf"] = 2
        $ label_stat_dict["yuanyangcha_clue_shelf_hide"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_shelf_hide"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_kitchenette_research

label yuanyangcha_kitchenette_research_colander_microwave:
    scene bg kitchenette
    with None

    "流し台の横には水切りかごと電子レンジがある。"
    "水切りかごには、研究所のメンバーが使っているのであろうカップがならんでいた。"
    "お土産であろう「I♡香港」と書かれたものや、キャンプ用品の大型タンブラーもある。"
    m normal "皆さん、個性的なカップを使われているのですね"
    if label_stat_dict["yuanyangcha_kitchenette_research_colander_microwave"] <= 1:
        $ label_stat_dict["yuanyangcha_kitchenette_research_colander_microwave"] = 2
    jump yuanyangcha_kitchenette_research

label yuanyangcha_kitchenette_talk:
    scene bg kitchenette
    with None

    menu:
        "聞きたいことを選んでください。"
        "昨日の行動":
            jump yuanyangcha_kitchenette_talk_yesterday
        "優雅なティータイム" if label_stat_dict["yuanyangcha_kitchenette_talk_teatime"] >= 1:
            jump yuanyangcha_kitchenette_talk_teatime
        "カップ" if label_stat_dict["yuanyangcha_kitchenette_talk_cup"] >= 1:
            jump yuanyangcha_kitchenette_talk_cup
        "マグカップを洗うまでの時間" if label_stat_dict["yuanyangcha_kitchenette_talk_wash"] >= 1:
            jump yuanyangcha_kitchenette_talk_wash
        "個人面談" if label_stat_dict["yuanyangcha_kitchenette_talk_interview"] >= 1:
            jump yuanyangcha_kitchenette_talk_interview
        "戻る":
            jump yuanyangcha_kitchenette

label yuanyangcha_kitchenette_talk_yesterday:
    scene bg kitchenette
    with None

    show tea at r
    tea "まずは昨日のアリバイに関心がある。\nそうだろう？"
    show assistant at l
    a "勝手に進めてきたな。"
    tea "昨日は9時に研究室に到着してからはずっと実験室にいたよ。\n例外は、12時の{color=[gui.keyword_color]}優雅なティータイム{/color}と、15時の{color=[gui.keyword_color]}個人面談{/color}だね。"
    if label_stat_dict["yuanyangcha_kitchenette_talk_yesterday"] <= 1:
        $ label_stat_dict["yuanyangcha_kitchenette_talk_yesterday"] = 2
        if label_stat_dict["yuanyangcha_kitchenette_talk_teatime"] == 0:
            $ label_stat_dict["yuanyangcha_kitchenette_talk_teatime"] = 1
        if label_stat_dict["yuanyangcha_kitchenette_talk_interview"] == 0:
            $ label_stat_dict["yuanyangcha_kitchenette_talk_interview"] = 1
    jump yuanyangcha_kitchenette_talk

label yuanyangcha_kitchenette_talk_teatime:
    scene bg kitchenette
    with None

    d normal "{color=[gui.keyword_color]}優雅なティータイム{/color}とは？"
    show tea at r
    tea "実験室にある{color=[gui.keyword_color]}遠心分離機{/color}を私は毎日12時に使っている。"
    tea "そして、あれは検体をセットしてから分離が完了するまで{color=[gui.keyword_color]}15分{/color}かかるんだよ。"
    tea "給湯室に移動して、携帯食料と紅茶を一服し、カップを洗うにはちょうどよい時間だ。"
    tea "マウスは強い匂いに反応してしまうからね。\n教授が執務室を開けていないときは、水以外の飲み物は給湯室で飲む決まりになっているのさ。"
    tea "暗くて色はまったくわからないが、ファーストフラッシュでオレンジペコーなダージリンとベルガモット、そして牛乳の香りに集中するにはもってこいの場所さ。"
    "たしかに、上質な紅茶と柑橘系の果物の香りが漂っている。"
    show assistant at l
    a "ファーストフラッシュ？　オレンジペコー？　ダージリン？　ベルガモット？"
    d happy "「ファーストフラッシュ」は「クオリティシーズン」、「オレンジペコー」は「等級」、「ダージリン」は「産地」、「ベルガモット」は「香料」の一種です。"
    a "呪文であることはわかったから、1つずつ説明してくれ。"
    d normal "「クオリティシーズン」は紅茶の収穫時期の違いです。"
    d normal "ダージリンの場合、ファーストフラッシュ（3月中旬～4月）、セカンドフラッシュ（5月～7月上旬）、オータムナル（10月～11月中旬）でそれぞれ異なる香りや味を楽しむことができますよ。"
    d normal "5月に摘まれた「一番茶」を「煎茶」、それ以降に摘まれた「二番茶」以降を「番茶」と呼ぶ緑茶と似ていますね。"
    a "茶葉は1年に何度も収穫できるから、いつ収穫したかで呼び分けているのか。"
    d normal "紅茶の「等級」は茶葉の形状と大きさです。"
    d normal "紅茶の抽出時間は、大きい葉なら長く、細かい葉なら短くなるでしょう。"
    d normal "製造過程で【篩|ふるい】にかけて同じ大きさの茶葉に揃えることで、抽出の時間も一定になり、バランスのよい味にしているのです。"
    a "「等級」って名前だけど、品質とは関係がないのか。"
    d normal "「チャ」は「ツツジ目ツバキ科カメリア属の永年性常緑樹」のことで、飲用に使われるのは「中国種」と「アッサム種」の主に2種類しかないのです。"
    a "「コーヒーノキ」の「アラビカ種」と「ロブスタ種」みたいなもんか。"
    d normal "それ以上の細かい茶葉の分類は産地の違いですね。"
    d normal "「ダージリン」はインドの北東部の地名で、チベット語で「雷の町」を意味し、イギリス軍の避暑地として発展しました。"
    d normal "その茶葉はフルーティな香りから「紅茶のシャンパン」と呼ばれることもありますよ。"
    a "それこそ「シャンパン」も「シャンパーニュ地方のスパークリングワイン」という意味だもんな。"
    d normal "ベルガモットは柑橘類の一種で、その香りをつけた紅茶はすべて「アールグレイ」と呼ばれます。"
    a "「アールグレイ」は聞いたことがあったけど、茶葉の品種や産地は関係ないのか。"
    d normal "19世紀にイギリス首相を務めた政治家「チャールズ・グレイ伯爵」が紹介したことが名前の由来です。"
    d normal "「アールグレイ」のように、お茶以外のものを添加するのが「フレーバーティー」なのに対し、複数の茶葉を配合するのが「ブレンドティー」。"
    d normal "各社が出している「ブレックファスト」「アフタヌーンティー」も「ブレンドティー」の一種ですね。"
    tea "ふむ、君もなかなかの紅茶党だね。"
    m normal "【躑躅|つつじ】 【椿|つばき】さんは相当の紅茶好きですね"
    if label_stat_dict["yuanyangcha_kitchenette_talk_teatime"] <= 1:
        $ label_stat_dict["yuanyangcha_kitchenette_talk_teatime"] = 2
        if label_stat_dict["yuanyangcha_kitchenette_talk_cup"] == 0:
            $ label_stat_dict["yuanyangcha_kitchenette_talk_cup"] = 1
        $ label_stat_dict["yuanyangcha_clue_tea_habit"] = 2
        $ label_stat_dict["yuanyangcha_clue_kitchenette_dark"] = 2
        $ label_stat_dict["yuanyangcha_clue_tea_drink"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_tea_habit"][0]
        $ tempClue2 = info_dict["yuanyangcha_clue_kitchenette_dark"][0]
        $ tempClue3 = info_dict["yuanyangcha_clue_tea_drink"][0]
        show screen clue_notify(["[tempClue1]", "[tempClue2]", "[tempClue3]"])
        call yuanyangcha_show_todo_list
        $ label_stat_dict["yuanyangcha_trivia_quality_season"] = 2
        $ label_stat_dict["yuanyangcha_trivia_grade"] = 2
        $ label_stat_dict["yuanyangcha_trivia_tea_species"] = 2
        $ label_stat_dict["yuanyangcha_trivia_darjeeling"] = 2
        $ label_stat_dict["yuanyangcha_trivia_champagne"] = 2
        $ label_stat_dict["yuanyangcha_trivia_earl_grey"] = 2
        $ label_stat_dict["yuanyangcha_trivia_flavour_blend"] = 2
        $ label_stat_dict["yuanyangcha_trivia_cha_tea"] = 2
        $ label_stat_dict["yuanyangcha_trivia_yuanyangcha"] = 2
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_kitchenette_talk

label yuanyangcha_kitchenette_talk_cup:
    scene bg kitchenette
    with None

    d normal "どのようなカップを使ってますか？"
    show tea at r
    tea "配属当初は【茜|あかね】君からプレゼントされたマグカップを使っていたんだが、優雅なティータイムを過ごしているときに、革新的なアイディアを思いついたのさ。"
    d desired "「エウレカ」と叫びながら、全裸で走り回ったのですね。"
    tea "ふむ、アルキメデスか。"
    tea "そこまでではないが、衝撃のあまり、マグカップを落として割ってしまってね。"
    tea "替えとして{color=[gui.keyword_color]}大学生協の公式マグカップ{/color}を買って、そのままさ。"
    m surprised "【竜胆|りんどう】 【茜|あかね】さんが聞いたら、ショックを受けそうそうですね。"
    tea "【松風|まつかぜ】 【柚子|ゆず】教授も同じものを使っていることに後で気づいたが、水切りかごで干す位置が違うから、取り違えることはないさ。"
    "助手がボクに耳打ちをする。"
    show assistant at l
    a "【躑躅|つつじ】 【椿|つばき】が12時に水切りラックに置いたマグカップが、15時に犯行に使われたんじゃないか。"
    m concerned "洗ったあとのマグカップに、はたして十分な量の唾液が含まれているでしょうか？"
    if label_stat_dict["yuanyangcha_kitchenette_talk_cup"] <= 1:
        $ label_stat_dict["yuanyangcha_kitchenette_talk_cup"] = 2
        if label_stat_dict["yuanyangcha_kitchenette_talk_wash"] == 0:
            $ label_stat_dict["yuanyangcha_kitchenette_talk_wash"] = 1
        $ label_stat_dict["yuanyangcha_clue_tea_cup"] = 2
        $ label_stat_dict["yuanyangcha_clue_yuzu_cup"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_tea_cup"][0]
        $ tempClue2 = info_dict["yuanyangcha_clue_yuzu_cup"][0]
        show screen clue_notify(["[tempClue1]", "[tempClue2]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_kitchenette_talk

label yuanyangcha_kitchenette_talk_wash:
    scene bg kitchenette
    with None

    d normal "昨日、マグカップに口をつけてから洗うまでの間に、なにか不自然なことはありませんでしたか？"
    show tea at r
    tea "それがね、飲み始めたばかりなのに、遠心分離機のタイマーが鳴ったんだよ。"
    tea "結果が気になってね。\n{color=[gui.keyword_color]}200ml{/color}ほど飲み残したマグカップを給湯室に置いて、実験室に向かったんだ。"
    tea "前に使った人がタイマーを{color=[gui.keyword_color]}5分{/color}に早めていたようでね。\n15分に戻して、給湯室に戻ったよ。"
    d normal "マグカップに変化はありましたか？"
    tea "マグカップはそのままさ。\nただ、{color=[gui.keyword_color]}100ml{/color}ほど残っていた水筒が空になっていたね。"
    m concerned "水筒の中身には【躑躅|つつじ】 【椿|つばき】さんの唾液は含まれていないはずですが……"
    show assistant at l
    a "天使の取り分だとしたら、その天使は相当せっかちだな。"
    d concerned "天使の取り分？"
    a "酒を熟成させるときに樽を使ったことで、樽から蒸発した水分やアルコール分を「【天使の取り分|エンジェルズ・シェア】」と呼ぶんだ。"
    a "ほかにも、樽に染み込んで取り出せなかった酒を「【悪魔の取り分|デビルズ・カット】」と呼んだりもするな。"
    a "「デビルズカット」という、そのままの名前のお酒もあって、樽から抽出したバーボンをブレンドすることで、木材の香りをより強く楽しめる。"
    m normal "水筒の中身は、はたしてどこに行ったのでしょうか？"
    if label_stat_dict["yuanyangcha_kitchenette_talk_wash"] <= 1:
        $ label_stat_dict["yuanyangcha_kitchenette_talk_wash"] = 2
        if label_stat_dict["yuanyangcha_chen_encounter"] == 0:
            $ label_stat_dict["yuanyangcha_chen_encounter"] = 1
        if label_stat_dict["yuanyangcha_clue_shelf_hide"] == 0:
            $ label_stat_dict["yuanyangcha_clue_shelf_hide"] = 1
        if label_stat_dict["yuanyangcha_clue_timer_shorten"] == 0:
            $ label_stat_dict["yuanyangcha_clue_timer_shorten"] = 1
        $ label_stat_dict["yuanyangcha_trivia_angel's_share"] = 2
        $ label_stat_dict["yuanyangcha_trivia_devil's_cut"] = 2
        $ label_stat_dict["yuanyangcha_trivia_devil's_cut_liqueur"] = 2
        $ label_stat_dict["yuanyangcha_clue_tea_cup_200ml"] = 2
        $ label_stat_dict["yuanyangcha_clue_tea_bottle_100ml"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_tea_cup_200ml"][0]
        $ tempClue2 = info_dict["yuanyangcha_clue_tea_bottle_100ml"][0]
        show screen clue_notify(["[tempClue1]", "[tempClue2]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_kitchenette_talk

label yuanyangcha_kitchenette_talk_interview:
    scene bg kitchenette
    with None

    d normal "{color=[gui.keyword_color]}個人面談{/color}とは？"
    show tea at r
    tea "【松風|まつかぜ】研究室の研究員は、毎月第4火曜日に教授と個人面談をすることになっている。"
    tea "ちょうど昨日がその日だったわけさ。\n一昨日にはリマインドメールも受け取ったよ。"
    d normal "そのメールを拝見してもいいですか？"
    tea "もちろんだ。\n宛先を見るに、ジャシー・チェンと【菊苦菜|きくにがな】 ちこりも同じメールを受け取っている。"
    "【躑躅|つつじ】 【椿|つばき】にメールを転送してもらった。"
    d normal "{color=[gui.machine_color]}「皆さんの論文を読み返して気づいたことがあったので、お話ししましょう。」{/color}とありますね。"
    tea "「研究指導をとおして、教育者としても学ぶところがあった」ということだと私は解釈した。"
    m concerned "はたして、それだけでしょうか？"
    tea "【松風|まつかぜ】 【柚子|ゆず】教授は実験結果だけでなく、個人面談の内容も自身の{color=[gui.keyword_color]}研究ノート{/color}に記録している。"
    tea "常にカバンに入れて持ち歩いていたから、執務室で調べるといい。"
    m concerned "個人面談で何が話されたか、気になりますね"
    if label_stat_dict["yuanyangcha_kitchenette_talk_interview"] <= 1:
        $ label_stat_dict["yuanyangcha_kitchenette_talk_interview"] = 2
        $ label_stat_dict["yuanyangcha_clue_interview"] = 2
        $ label_stat_dict["yuanyangcha_clue_remind_mail"] = 2
        $ label_stat_dict["yuanyangcha_clue_professor_note"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_interview"][0]
        $ tempClue2 = info_dict["yuanyangcha_clue_remind_mail"][0]
        $ tempClue3 = info_dict["yuanyangcha_clue_professor_note"][0]
        if label_stat_dict["yuanyangcha_clue_tea_paper"] == 0:
            $ label_stat_dict["yuanyangcha_clue_tea_paper"] = 1
        if label_stat_dict["yuanyangcha_clue_chen_paper"] == 0:
            $ label_stat_dict["yuanyangcha_clue_chen_paper"] = 1
        if label_stat_dict["yuanyangcha_clue_robusta_paper"] == 0:
            $ label_stat_dict["yuanyangcha_clue_robusta_paper"] = 1
        if label_stat_dict["yuanyangcha_clue_professor_note_lost"] == 0:
            $ label_stat_dict["yuanyangcha_clue_professor_note_lost"] = 1
        show screen clue_notify(["[tempClue1]", "[tempClue2]", "[tempClue3]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_kitchenette_talk


label yuanyangcha_laboratory:
    scene bg laboratory

    if label_stat_dict["yuanyangcha_chen_encounter"] == 1:
        jump yuanyangcha_chen_encounter

    menu:
        "調べる":
            jump yuanyangcha_labo_research
        "話す":
            jump yuanyangcha_labo_talk
        "戻る":
            $ update_todo = True
            jump yuanyangcha_reserch

label yuanyangcha_chen_encounter:
    scene bg laboratory

    tp "同日 12:30\n桜月大学 【松風|まつかぜ】研究室 実験室"

    "実験室の扉を開けると、動物的な臭いと科学的な臭い、小動物の鳴き声と滑車を回す音が、渾然一体となって襲ってきた。"
    "それらの臭気と騒音の原因は、マウスの飼育ケースと薬品棚のようだ。"
    "黄色いジャージの女性がピペットを手にしながら、マウスに話しかけていた。"
    show chen at center
    with dissolve
    chen "こんな日もエサやり当番なんて、かわいそうですよね、ネズ太郎"
    chen "【躑躅|つつじ】 【椿|つばき】さんも【菊苦菜|きくにがな】 ちこりさんもケロリとした顔で、薄情だと思いませんか、ネズ子"
    chen "研究室が解散になったら、私もあなたも路頭に迷ってしまいますね、ネズッキー"
    "これ以上放置しても愚痴を聞かされるだけなので、警察手帳を見せながら話しかける。"
    d normal "少々お話をうかがってもよろしいですか？"
    chen "アイヤ！\nお見苦しいところを見せてしまいました。\n私、ジャシー・チェンと申します。"
    m normal "アクション映画俳優を彷彿とさせる服装ですね"
    $ label_stat_dict["yuanyangcha_chen_encounter"] = 2
    $ label_stat_dict["yuanyangcha_character_chen"] = 2
    $ label_stat_dict["yuanyangcha_labo_talk_yesterday"] = 1
    call yuanyangcha_show_todo_list
    show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_laboratory

label yuanyangcha_labo_research:
    menu:
        "調べたい場所を選んでください。"
        "遠心分離機":
            jump yuanyangcha_labo_research_centrifuge
        "薬品棚":
            jump yuanyangcha_labo_research_chemical
        "戻る":
            jump yuanyangcha_laboratory

label yuanyangcha_labo_research_centrifuge:
    scene bg laboratory

    "遠心分離機の横にノートパソコンがある。"
    show assistant at center
    a "パソコンに接続することで、操作のログを見られるな。"
    a "昨日は、11時45分に「{color=[gui.keyword_color]}タイマーを5分に変更{/color}」、12時に「実行」、12時10分に「タイマーを15分に変更」「実行」だけだな。"
    d normal "【躑躅|つつじ】 【椿|つばき】さんの証言通りですね。"
    d normal "「タイマーを5分に変更」したのは誰か、わかりますか？"
    a "ユーザー名の記録はないが、「タイマーを5分に変更」だけ操作日時を書き換えた痕跡ならあるぞ。"
    a "誰がいつ書き換えたかはわかんねぇな。"
    d concerned "人は誰だって、書き換えたい過去があるものです。"
    a "お前との長い付き合いとかな。"
    d normal "なぜ書き換えたのかを考えれば、十分大きな手がかりですね。"
    if label_stat_dict["yuanyangcha_labo_research_centrifuge"] <= 1:
        $ label_stat_dict["yuanyangcha_labo_research_centrifuge"] = 2
        $ label_stat_dict["yuanyangcha_clue_timer_shorten"] = 2
        $ label_stat_dict["yuanyangcha_clue_timer_log_edit"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_timer_shorten"][0]
        $ tempClue2 = info_dict["yuanyangcha_clue_timer_log_edit"][0]
        show screen clue_notify(["[tempClue1]", "[tempClue2]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_labo_research

label yuanyangcha_labo_research_chemical:
    scene bg laboratory

    "薬品棚は簡素で、鍵はついていなかった。"
    "犯行に使われた薬品も、ガラス戸をスライドさせるだけで手に入れることができる。"
    d concerned "もしかして、これらの薬品は……"
    show chen at r
    chen "マウスの殺処分は日常茶飯事ですからね。\n研究員ならだれでも扱えますよ。"
    show assistant at l
    a "セキュリティに穴がありすぎる……。"
    d desired "人間にも穴はたくさんありますからね。"
    a "お前と同じ穴の狢とは思われなくねぇな。"
    m concerned "毒の入手経路から犯人を絞り込むのは難しそうですね"
    if label_stat_dict["yuanyangcha_labo_research_chemical"] <= 1:
        $ label_stat_dict["yuanyangcha_labo_research_chemical"] = 2
        $ label_stat_dict["yuanyangcha_clue_poison_anyone"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_poison_anyone"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_labo_research

label yuanyangcha_labo_talk:
    scene bg laboratory

    menu:
        "聞きたいことを選んでください。"
        "昨日の行動":
            jump yuanyangcha_labo_talk_yesterday
        "飲み物" if label_stat_dict["yuanyangcha_labo_talk_drink"] >= 1:
            jump yuanyangcha_labo_talk_drink
        "【鴛鴦茶|ユンヨンチャ】" if label_stat_dict["yuanyangcha_labo_talk_yuanyangcha"] >= 1:
            jump yuanyangcha_labo_talk_yuanyangcha
        "カップ" if label_stat_dict["yuanyangcha_labo_talk_cup"] >= 1:
            jump yuanyangcha_labo_talk_cup
        "戻る":
            jump yuanyangcha_laboratory

label yuanyangcha_labo_talk_yesterday:
    scene bg laboratory

    d normal "昨日、教授が倒れるまでに何をなさっていましたか？"
    show chen at r
    chen "昨日は9時に研究室に着いて、12時に食堂に行ったり、15時10分に教授との個人面談で執務室に行ったりした以外は、ずっと実験室にいました。"
    if label_stat_dict["yuanyangcha_labo_talk_yesterday"] <= 1:
        $ label_stat_dict["yuanyangcha_labo_talk_yesterday"] = 2
        if label_stat_dict["yuanyangcha_labo_talk_drink"] == 0:
            $ label_stat_dict["yuanyangcha_labo_talk_drink"] = 1
    jump yuanyangcha_labo_talk

label yuanyangcha_labo_talk_drink:
    scene bg laboratory

    d normal "研究室ではどのような飲み物をたしなまれていますか？"
    show chen at r
    chen "コーヒーには一家言ありましてね、100％{color=[gui.keyword_color]}アラビカ種{/color}の上質な豆を毎日ドリップして持ってきています。"
    d concerned "アラビカ種？"
    show assistant at l
    a "「コーヒーノキ」は「リンドウ目アカネ科コーヒーノキ属」の植物だが、主に栽培されているのは「{color=[gui.keyword_color]}アラビカ種{/color}」と「{color=[gui.keyword_color]}ロブスタ種{/color}」の2種類だ。"
    a "「アラビカ種」は15世紀から数百年間「世界で唯一のコーヒー」であり、現在も世界の生産量の6割を占めている。"
    a "ただし、病害虫に弱く、高地でしか栽培できず、面積当たりの収穫量も少ないという欠点がある。"
    a "そこで、19世紀末に東南アジアでコーヒーさび病が流行したときに発見されたのが、すべての型のさび病に耐性を持つ唯一の種である「ロブスタ種」だ。"
    a "「頑強な」を意味する「ロブスタ」と名付けられたのは、高い耐病性のほかにも、低地でも栽培可能で、面積当たりの収穫量が多いからだな。"
    a "ただし、酸味と香りでアラビカ種に劣り、「ロブスタ臭」と呼ばれる独特の土臭さがあるという欠点がある。"
    a "ちなみに、「豆」は「マメ目マメ科」の植物の種子の総称だから、「コーヒー豆」は厳密には「コーヒーノキの種子」だ。"
    d surprised "「コーヒーさび病」は紅茶の歴史にも無関係ではありませんよ。"
    d normal "コーヒーさび病で壊滅したスリランカのコーヒー農園を、トーマス・リプトン卿が紅茶の栽培に転用したのが「セイロンティー」と「リプトン」の始まりです。"
    chen "紅茶と言えば、たまに{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}も楽しめるように、ティーバッグも持ってますよ。"
    d desired "「Tバック」？"
    a "紅茶の話をしたのはお前だろ。"
    m concerned "{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}……初めて聞くお茶ですね"
    if label_stat_dict["yuanyangcha_labo_talk_drink"] <= 1:
        $ label_stat_dict["yuanyangcha_labo_talk_drink"] = 2
        if label_stat_dict["yuanyangcha_labo_talk_yuanyangcha"] == 0:
            $ label_stat_dict["yuanyangcha_labo_talk_yuanyangcha"] = 1
        if label_stat_dict["yuanyangcha_security_talk_coffee_kind"] == 0:
            $ label_stat_dict["yuanyangcha_security_talk_coffee_kind"] = 1
        if label_stat_dict["yuanyangcha_clue_poison_robusta"] == 0:
            $ label_stat_dict["yuanyangcha_clue_poison_robusta"] = 1
        $ label_stat_dict["yuanyangcha_trivia_coffee_species"] = 2
        $ label_stat_dict["yuanyangcha_trivia_coffee_bean"] = 2
        $ label_stat_dict["yuanyangcha_trivia_ceylon_lipton"] = 2
        $ label_stat_dict["yuanyangcha_clue_chen_arabica"] = 2
        $ label_stat_dict["yuanyangcha_clue_chen_tea"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_chen_arabica"][0]
        $ tempClue2 = info_dict["yuanyangcha_clue_chen_tea"][0]
        show screen clue_notify(["[tempClue1]", "[tempClue2]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_labo_talk

label yuanyangcha_labo_talk_yuanyangcha:
    scene bg laboratory

    d normal "{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}とはどのような飲み物ですか？"
    show chen at r
    chen "私の故郷の香港はかつてイギリスに占領されていたので、紅茶もコーヒーもたくさん飲みます。"
    chen "紅茶貿易が原因で、アメリカ独立戦争とアヘン戦争を起こしたイギリスほどではないですが。"
    m concerned "今のはイギリス由来のブラックジョークでしょうか"
    chen "その香港で生まれたのが、紅茶とコーヒーを混ぜた{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}です。"
    chen "「【鴛鴦|ユンヨン】」は「オシドリのオスとメス」のことです。"
    d angry "実際のオシドリは実際は冬になるたびにパートナーを変え、【抱卵|ほうらん】も【育雛|いくすう】もメスのみが行うようですが。"
    show assistant at l
    a "今はイメージの話をしてんだよ。"
    chen "中国では男女同時に使うものや、二つが一つになったものの名前に「【鴛鴦|ユンヨン】」を付けることがあります。"
    chen "「2人用の長い枕」は「【鴛鴦枕|ユンヨンチェン】」、「男女二人での入浴」は「【鴛鴦浴|ユンヨンユー】」、"
    chen "「2つに仕切られた鍋」は「【鴛鴦火鍋|ユンヨンフオグオ】」、「2色のあんかけ炒飯」は「【鴛鴦炒飯|ユンヨンチャーハン】」といった感じです。"
    d normal "現在世界各国で使われている「茶」を意味する言葉は「チャ」か「ティー」の、いずれかに大別されます。"
    d normal "もとはどちらも中国で、広東語の「チャ」と福建語の「テー」が語源ですね。"
    d normal "広東語の「チャ」は陸路経由でユーラシア大陸の東側に広まり、福建語の「テー」はオランダと貿易していた福建の港から海路でヨーロッパに広まりました。"
    a "「{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}」の「チャ」は広東語由来ってことか。"
    m concerned "なぜ犯人は{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}に毒を盛ったのでしょうか？"
    if label_stat_dict["yuanyangcha_labo_talk_yuanyangcha"] <= 1:
        $ label_stat_dict["yuanyangcha_labo_talk_yuanyangcha"] = 2
        if label_stat_dict["yuanyangcha_labo_talk_cup"] == 0:
            $ label_stat_dict["yuanyangcha_labo_talk_cup"] = 1
        $ label_stat_dict["yuanyangcha_trivia_opium_war"] = 2
        $ label_stat_dict["yuanyangcha_trivia_american_war_of_independencee"] = 2
        $ label_stat_dict["yuanyangcha_trivia_yuanyangcha"] = 2
        $ label_stat_dict["yuanyangcha_trivia_cha_tea"] = 2
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_labo_talk

label yuanyangcha_labo_talk_cup:
    scene bg laboratory

    d surprised "故郷が香港とのことでしたが、もしかして「I♡香港」というマグカップは……"
    show chen at r
    chen "はい、私のですよ。"
    m normal "ほかの【方|かた】のカップと間違えることはなさそうですね"
    if label_stat_dict["yuanyangcha_labo_talk_cup"] <= 1:
        $ label_stat_dict["yuanyangcha_labo_talk_cup"] = 2
        if label_stat_dict["yuanyangcha_robusta_encounter"] == 0:
            $ label_stat_dict["yuanyangcha_robusta_encounter"] = 1
        $ label_stat_dict["yuanyangcha_clue_chen_cup"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_chen_cup"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_labo_talk

label yuanyangcha_office:
    scene bg reception room

    if label_stat_dict["yuanyangcha_robusta_encounter"] == 1:
        jump yuanyangcha_robusta_encounter

    menu:
        "調べる":
            jump yuanyangcha_office_research
        "話す":
            jump yuanyangcha_office_talk
        "戻る":
            $ update_todo = True
            jump yuanyangcha_reserch

label yuanyangcha_robusta_encounter:
    scene bg reception room

    tp "同日 13:00\n桜月大学 【松風|まつかぜ】研究室 執務室"
    "執務室の壁は本で埋まっており、質素な机の上にも積み重なっていた。"
    "机の横にはオフィスチェアがいくつかあり、そのうちのひとつに座っているスーツ姿の女性が、書類に目を通している。"
    "なぜ、この女性は平然としていられるのだろうか。"
    "刺激的なほど強いラベンダーの香りが充満している部屋で。"
    show assistant at l
    a "もはや悪臭だろ。"
    show robusta at r
    with dissolve
    robusta "え？\n私、臭いますか？"
    d concerned "おそらく香水かなにかだと思われますが。"
    "3人で調べると、横になったディフューザーからアロマオイルが漏れていたことがわかった。"
    "ディフューザーをもとに戻し、アロマオイルをふき取りつつ、窓を開ける。"
    robusta "おそらく【松風|まつかぜ】 【柚子|ゆず】教授を搬送するときに倒れてしまったのだと思われます。"
    d concerned "もしかして、{color=[gui.keyword_color]}嗅覚が不自由{/color}なお方ですか？"
    robusta "ええ。\n寝不足で実験をしていたときに、劇薬を直接嗅いで以来、匂いが分からなくなってしまって……。"
    d concerned "腋の下の芳醇な匂いをかげないなんて、かわいそうに。"
    a "植物や飲食物でたとえろよ。"
    d normal "気を取り直して、捜査に協力していただけますでしょうか？"
    robusta "ええ。\n【菊苦菜|きくにがな】 ちこりと申します。"
    m normal "几帳面そうな方ですね"
    $ label_stat_dict["yuanyangcha_robusta_encounter"] = 2
    $ label_stat_dict["yuanyangcha_character_robusta"] = 2
    $ label_stat_dict["yuanyangcha_clue_robusta_smell"] = 2
    $ tempClue1 = info_dict["yuanyangcha_clue_robusta_smell"][0]
    show screen clue_notify(["[tempClue1]"])
    call yuanyangcha_show_todo_list
    show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_office

label yuanyangcha_office_research:
    scene bg reception room

    menu:
        "調べたい場所を選んでください。"
        "【躑躅|つつじ】 【椿|つばき】の論文":
            jump yuanyangcha_office_research_paper_tea
        "ジャシー・チェンの論文":
            jump yuanyangcha_office_research_paper_chen
        "【菊苦菜|きくにがな】 ちこりの論文":
            jump yuanyangcha_office_research_paper_robusta
        "【松風|まつかぜ】 【柚子|ゆず】の研究ノート":
            jump yuanyangcha_office_research_professor_note
        "戻る":
            jump yuanyangcha_office

label yuanyangcha_office_research_paper_tea:
    scene bg reception room

    "【躑躅|つつじ】 【椿|つばき】の最新の論文を取り出した。"
    "タイトルは「GABAの疲労回復効果」。"
    "【松風|まつかぜ】 【柚子|ゆず】教授との共著論文だ。"
    "しかしながら、謝辞を見ると【躑躅|つつじ】 【椿|つばき】が着想から作業まですべてこなしたようだ"
    d concerned "この貢献度なら単著でもおかしくなさそうですが。"
    show assistant at center
    a "業界ごとに慣習が違ったりするから、断言できねぇな。"
    if label_stat_dict["yuanyangcha_office_research_paper_tea"] <= 1:
        $ label_stat_dict["yuanyangcha_office_research_paper_tea"] = 2
        $ label_stat_dict["yuanyangcha_clue_tea_paper"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_tea_paper"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_office_research

label yuanyangcha_office_research_paper_chen:
    scene bg reception room

    "ジャシー・チェンの最新の論文を取り出した。"
    "タイトルは「漢方の疲労回復効果」。"
    "謝辞には複数の助成金が名を連ねている。"
    show assistant at center
    a "論文名で検索してみたが、謝辞にない助成金もヒットするぞ。"
    d concerned "ジャシー・チェンさんの知らない助成金も、【松風|まつかぜ】 【柚子|ゆず】教授が受け取っていたのでしょうか。"
    if label_stat_dict["yuanyangcha_office_research_paper_chen"] <= 1:
        $ label_stat_dict["yuanyangcha_office_research_paper_chen"] = 2
        $ label_stat_dict["yuanyangcha_clue_chen_paper"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_chen_paper"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_office_research

label yuanyangcha_office_research_paper_robusta:
    scene bg reception room

    "【菊苦菜|きくにがな】 ちこりの最新の論文を取り出した。"
    "タイトルは「代用コーヒーの疲労回復効果」。"
    show assistant at center
    a "専門外だが、形式的にはおかしなところはねぇな。"
    m concerned "たしかにおかしくない……むしろ、おかしくなさすぎる……"
    d normal "数値の1番最初の数字、1から9までどれも出現頻度が約11％な気がしませんか？"
    a "そりゃ100％を9で割ったら約11％だろ。"
    d normal "「{color=[gui.keyword_color]}ベンフォードの法則{/color}」では、数値の1番最初の数字が「1」である確率は約30％、「9」である確率は約5％ですよ。"
    a "「2.0」は「1.0」の2倍だけど、「9.0」は「8.0」の1.125倍みたいなもんか。"
    d normal "「ベンフォードの法則」は2番目以降の数字でも適用できますから、さらに詳細な解析をお願いします。"
    a "しゃーねぇな。"
    if label_stat_dict["yuanyangcha_office_research_paper_robusta"] <= 1:
        $ label_stat_dict["yuanyangcha_office_research_paper_robusta"] = 2
        $ label_stat_dict["yuanyangcha_clue_robusta_paper"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_robusta_paper"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_office_research

label yuanyangcha_office_research_professor_note:
    scene bg reception room

    "【松風|まつかぜ】 【柚子|ゆず】教授のカバンの中身を確認したが、研究ノートは見つけられなかった。"
    "執務室をくまなく調べたが、状況は変わらない。"
    show assistant at center
    a "研究ノートの中身、気になりすぎるな。"
    d normal "個人面談の内容を知られないよう、犯人が隠したのかもしれません。"
    a "なら、容疑者の持ち物を検査すれば……"
    d concerned "昨日の17時以降に盗み出し、自宅などに持ち帰った可能性が高いですし、それだけで家宅捜索の令状を発行するのは難しいですね。"
    m normal "個人面談は犯人にとって何を意味したのでしょうか？"
    if label_stat_dict["yuanyangcha_office_research_professor_note"] <= 1:
        $ label_stat_dict["yuanyangcha_office_research_professor_note"] = 2
        $ label_stat_dict["yuanyangcha_clue_professor_note_lost"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_professor_note_lost"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_office_research

label yuanyangcha_office_talk:
    scene bg reception room

    menu:
        "聞きたいことを選んでください。"
        "昨日の行動":
            jump yuanyangcha_office_talk_yesterday
        "飲み物" if label_stat_dict["yuanyangcha_office_talk_drink"] >= 1:
            jump yuanyangcha_office_talk_drink
        "カップ" if label_stat_dict["yuanyangcha_office_talk_cup"] >= 1:
            jump yuanyangcha_office_talk_cup
        "戻る":
            jump yuanyangcha_office

label yuanyangcha_office_talk_yesterday:
    scene bg reception room

    d normal "昨日、教授が倒れるまでに何をなさっていたか、教えてくださいますか？"
    show robusta at center
    robusta "昨日は8時に実験室に到着し、11時30分から12時30分までは食堂、15時20分から15時30分までは執務室で教授と個人面談をしていました。"
    d surprised "朝、お早いのですね。"
    robusta "ええ。\n私は他のかたと違って天才ではありませんから、せめて稼働時間を増やすことで貢献できればと思いまして。"
    if label_stat_dict["yuanyangcha_office_talk_yesterday"] <= 1:
        $ label_stat_dict["yuanyangcha_office_talk_yesterday"] = 2
        if label_stat_dict["yuanyangcha_office_talk_drink"] == 0:
            $ label_stat_dict["yuanyangcha_office_talk_drink"] = 1
        $ label_stat_dict["yuanyangcha_clue_robusta_arrival"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_robusta_arrival"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_office_talk

label yuanyangcha_office_talk_drink:
    scene bg reception room

    d normal "研究室ではどのような飲み物をたしなまれていますか？"
    show robusta at r
    robusta "研究は眠気との戦いですからね。\nコーヒーを多めに淹れて持ってきています。"
    show assistant at l
    a "毎日午前1時に起きて、コーヒーを50杯飲み、執筆と社交に励んだ小説家、オノレ・ド・バルザックみたいなもんか。"
    robusta "よくわかりませんが、褒め言葉として受け取っておきます。"
    d normal "どのようなコーヒーか、詳細を教えていただいてよろしいですか？"
    robusta "あまり詳しくないもので。\n現物ならこちらですが。"
    "【菊苦菜|きくにがな】 ちこりが差し出した大型の水筒を助手が受け取り、黒々とした中身の匂いをかいだ。"
    a "……もしかして原材料名に「100％ベトナム産」とか書いてなかったか？"
    robusta "ええ、そうだった気がします。"
    "助手がボクに耳打ちをする。"
    a "ブラジルに次ぐコーヒーの産地であるベトナムで栽培されているのは、高温多湿でも育てられる{color=[gui.keyword_color]}ロブスタ種{/color}だ。"
    a "ただ、{color=[gui.keyword_color]}ロブスタ種{/color}は臭みが強いから、現地では練乳を入れて飲むことが多く、そのような飲み方を「ベトナムコーヒー」と呼んだりする。"
    a "100％{color=[gui.keyword_color]}ロブスタ種{/color}をブラックで飲む人間を初めて見たぜ。"
    d surprised "【菊苦菜|きくにがな】 ちこりさんだからこそできる芸当ですね。"
    if label_stat_dict["yuanyangcha_office_talk_drink"] <= 1:
        $ label_stat_dict["yuanyangcha_office_talk_drink"] = 2
        if label_stat_dict["yuanyangcha_office_talk_cup"] == 0:
            $ label_stat_dict["yuanyangcha_office_talk_cup"] = 1
        $ label_stat_dict["yuanyangcha_trivia_balzac"] = 2
        $ label_stat_dict["yuanyangcha_trivia_vietnam_coffee"] = 2
        $ label_stat_dict["yuanyangcha_clue_robusta_drink"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_robusta_drink"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_office_talk

label yuanyangcha_office_talk_cup:
    scene bg reception room

    "ちなみに、どのようなカップを使ってますか？"
    show robusta at center
    robusta "実用性の観点から、キャンプ用品の大型タンブラーを使っています。"
    m normal "こちらも、ほかの【方|かた】のカップと間違えることはなさそうですね"
    if label_stat_dict["yuanyangcha_office_talk_cup"] <= 1:
        $ label_stat_dict["yuanyangcha_office_talk_cup"] = 2
        $ label_stat_dict["yuanyangcha_clue_robusta_cup"] = 2
        $ tempClue1 = info_dict["yuanyangcha_clue_robusta_cup"][0]
        show screen clue_notify(["[tempClue1]"])
        call yuanyangcha_show_todo_list
        show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_office_talk

label yuanyangcha_show_todo_list:
    $ renpy.hide_screen("todo")
    $ renpy.hide_screen("todo_action")
    $ todo_list = []
    $ done_int = 0
    $ total_int = 0
    $ i = 0
    $ key_list = list(label_stat_dict.keys())
    while i < len(key_list):
        $ key = key_list[i]
        if "yuanyangcha_clue_" in key:
            $ total_int = total_int + 1
            if label_stat_dict[key] == 2:
                $ done_int = done_int + 1
        
        if label_stat_dict[key] == 1:
            if key == "yuanyangcha_clue_shelf_hide":
                $ todo_list.append(["給湯室で隠れられる場所を探す"])
            elif key == "yuanyangcha_clue_timer_shorten":
                $ todo_list.append(["実験室の遠心分離機を調べる"])
            elif key == "yuanyangcha_clue_poison_robusta":
                $ todo_list.append(["【竜胆|りんどう】 【茜|あかね】に毒入りコーヒーの種類を確認する"])
            elif key == "yuanyangcha_tea_encounter":
                $ todo_list.append(["給湯室を調べる"])
            elif key == "yuanyangcha_chen_encounter":
                $ todo_list.append(["実験室を調べる"])
            elif key == "yuanyangcha_robusta_encounter":
                $ todo_list.append(["執務室を調べる"])
            elif key == "yuanyangcha_clue_tea_paper":
                $ todo_list.append(["執務室で【躑躅|つつじ】 【椿|つばき】の論文を調べる"])
            elif key == "yuanyangcha_clue_chen_paper":
                $ todo_list.append(["執務室でジャシー・チェンの論文を調べる"])
            elif key == "yuanyangcha_clue_robusta_paper":
                $ todo_list.append(["執務室で【菊苦菜|きくにがな】 ちこりの論文を調べる"])
            elif key == "yuanyangcha_clue_professor_note":
                $ todo_list.append(["執務室で【松風|まつかぜ】 【柚子|ゆず】の研究ノートを調べる"])

        $ i = i + 1

    if done_int == total_int:
        # このシナリオのすべてのトリビアを完了にする
        $ i = 0
        while i < len(key_list):
            $ key = key_list[i]
            if "yuanyangcha_trivia_" in key:
                $ label_stat_dict[key] = 2
            $ i = i + 1
        # returnでゲームを終了できるよう、callスタックを空にする
        $ renpy.set_return_stack([])
        jump yuanyangcha_deduction
    else:
        show screen todo(done_int, total_int, todo_list)
        return

label yuanyangcha_deduction:
    scene bg corridor

    tp "同日 13:30\n桜月大学 【松風|まつかぜ】研究室 廊下"
    "ひととおり捜査を終えて廊下に出ると、2人の刑事と鉢合わせた。"
    show gal at l
    show matcha at r
    with dissolve

    "同じ警視庁捜査一課の【毛利|もうり】 【森子|もりこ】と【町矢|まちや】 【抹茶|まっちゃ】だ。"
    gal "あーしのヤマで抜け駆けしようとは、いい根性してんじゃねーの。"
    matcha "お二方は本当に現場がお好きなんですね。\n警視庁ではなく所轄のほうがお似合いですわ。"
    scene bg security room
    show coffee at center
    "2人の背後の警備室では【竜胆|りんどう】 【茜|あかね】がカウンターの後ろに身を隠しながら、こちらの様子をうかがっている。"
    m concerned "【竜胆|りんどう】 【茜|あかね】さんが撤退するまで、時間を稼がなくては……"
    scene bg corridor
    show gal at l
    show matcha at r
    d normal "このような場所で立ち話すると館内に響きますから、執務室に移動しませんか？\n合わせて、関係者も集めましょう。"
    matcha "それもそうですわね。"
    scene bg security room
    show coffee at center
    "【竜胆|りんどう】 【茜|あかね】にこっそり目くばせすると、こちらの意図を察してくれたようだ。"
    m normal "【竜胆|りんどう】 【茜|あかね】さんが2人に見つかったら、ボクたちも始末書を書くはめになりますからね"
    $ label_stat_dict["yuanyangcha_character_gal"] = 2
    $ label_stat_dict["yuanyangcha_character_matcha"] = 2
    show screen open_info(label_stat_dict, info_dict, scenario_prefix, clue_adj, chara_adj, trivia_adj)
    jump yuanyangcha_deduction_introduction

label yuanyangcha_deduction_introduction:
    scene bg reception room
    show assistant:
        xpos -0.35
    show tea:
        xpos -0.2
    show chen:
        xpos -0.05
    show robusta:
        xpos 0.05
    show gal:
        xpos 0.2
    show matcha:
        xpos 0.35
    tp "同日 13:40\n桜月大学 【松風|まつかぜ】研究室 執務室"
    "執務室は、ボクとニコル、3人の容疑者、2人の同僚で、すし詰めになっていた。"
    "幸い、ラベンダーの香りはかなり薄らいでいる。"
    d normal "このたびはお集まりいただきありがとうございます。"
    d normal "今から【松風|まつかぜ】 【柚子|ゆず】教授毒殺事件の犯人を論証しますので、しばしのご傾聴をお願いします。"
    scene bg reception room
    show gal at l
    gal "は？\n今来たとこなんだけど！"
    show matcha at r
    matcha "どのような世迷言を聞かせていただけるか、楽しみですわ。"
    scene bg reception room
    d normal "まずは事件の概要を整理しましょう。"
    d normal "服薬推定時刻に【松風|まつかぜ】 【柚子|ゆず】教授と会った人物は【躑躅|つつじ】 【椿|つばき】、ジャシー・チェン、【菊苦菜|きくにがな】 ちこりの3名。"
    d normal "また、【松風|まつかぜ】 【柚子|ゆず】教授の指紋と唾液、そして毒が検出されたカップからは、【躑躅|つつじ】 【椿|つばき】の指紋と唾液も検出されました。"
    show tea at center
    tea "ほう、それは不可解だね。"
    d normal "「1つのカップから、2名の指紋だけでなく、唾液も検出される」という一見不可解な状況ですが、この事件ではそこまで不自然ではありません。"
    jump yuanyangcha_deduction_professor_cup

label yuanyangcha_deduction_professor_cup:
    scene bg reception room
    d normal "【躑躅|つつじ】 【椿|つばき】の飲み残しのカップさえあれば、それに毒を入れて、【松風|まつかぜ】 【柚子|ゆず】教授に飲ませることは容易でした。\nなぜなら……"
    menu:
        "【躑躅|つつじ】 【椿|つばき】も【松風|まつかぜ】 【柚子|ゆず】教授も、大学生協の公式マグカップを使っていたから":
            jump yuanyangcha_deduction_professor_cup_same
        "執務室は暗かったから":
            jump yuanyangcha_deduction_professor_cup_dark

label yuanyangcha_deduction_professor_cup_dark:
    scene bg reception room
    d normal "執務室は暗かったからです。"
    show assistant at center
    a "暗かったのは給湯室のほうだろ。"
    m surprised "執務室が明るくても成立する証拠があったはずですね"
    jump yuanyangcha_deduction_professor_cup

label yuanyangcha_deduction_professor_cup_same:
    scene bg reception room
    d normal "【躑躅|つつじ】 【椿|つばき】さんも【松風|まつかぜ】 【柚子|ゆず】教授も、大学生協の公式マグカップを使っていたからです。"
    d normal "「給湯室の水切りラックのどこで干すか」以外に違いがなく、執務室に持ち込んでしまえば本人にも区別ができない状況だったのです。"
    show matcha at center
    matcha "では、【躑躅|つつじ】 【椿|つばき】が犯人で決まりではありませんこと？"
    d concerned "しかしながら、【躑躅|つつじ】 【椿|つばき】さんの飲み残しのカップを手に入れることができたのは、【躑躅|つつじ】 【椿|つばき】さんだけではなかったのです。"
    d normal "【躑躅|つつじ】 【椿|つばき】さんは毎日12時に実験室の遠心分離機を回し、タイマーが鳴る15分の間に、給湯室でカップと水筒を使う習慣がありました。"
    d normal "つまり、大学生協の公式マグカップを購入し、午前中にタイマーの時間を5分に早める。"
    d normal "そして、12時に【躑躅|つつじ】 【椿|つばき】さんに飲み残しのカップと水筒を放置させたあと、水筒の中身を自前のカップに注ぐことで、すり替えることができたのです。"
    matcha "しかし、【躑躅|つつじ】 【椿|つばき】に見つからずにそんなことが可能でして？"
    jump yuanyangcha_deduction_place_hide

label yuanyangcha_deduction_place_hide:
    scene bg reception room
    d normal "【躑躅|つつじ】 【椿|つばき】さんに見つからない方法、それは給湯室の中で隠れることです。"
    menu:
        "隠れられる場所は……"
        "電子レンジの中":
            jump yuanyangcha_deduction_place_hide_microwave
        "棚の中":
            jump yuanyangcha_deduction_place_hide_shelf

label yuanyangcha_deduction_place_hide_microwave:
    scene bg reception room
    d normal "隠れられる場所は電子レンジの中です。"
    show assistant at center
    a "人間もマグカップも穴が1つでトポロジー的に同じだから、とかいうジョークじゃねえよな？"
    m concerned "穴があったら入りたいですね"
    jump yuanyangcha_deduction_place_hide

label yuanyangcha_deduction_place_hide_shelf:
    scene bg reception room
    d normal "隠れられる場所は棚の中です。"
    d normal"【躑躅|つつじ】 【椿|つばき】さんより先に給湯室に到着し、棚の中に隠れ、すり替えたカップを棚の中に隠して、給湯室を出る。"
    d normal "あとは、【松風|まつかぜ】 【柚子|ゆず】教授との個人面談がある15時の前に給湯室に行き、すり替えたカップを取り出し、電子レンジで温め、毒を盛るだけです。"
    d normal "そして、当日午前中にタイマーを5分に早められたことは、遠心分離機のログに残っています。"
    show matcha at center
    matcha "その人物がわかれば、犯人もわかったようなものではありませんこと？"
    d concerned "残念ながら、それが誰かはわかりませんでした。"
    d normal "しかし、ある別の証拠から、タイマーを早めた人物を絞り込むことができます。"
    d normal"鑑識も見逃しておりましたが、「タイマーを5分に早めた日時」についてだけ、ログが書き換えらえていました。"
    d normal "書き換えたあとの日時は「{color=[gui.keyword_color]}11時45分{/color}」。"
    jump yuanyangcha_deduction_log_rewrite

label yuanyangcha_deduction_log_rewrite:
    scene bg reception room
    d normal "「タイマーを5分に早めた日時」を「{color=[gui.keyword_color]}11時45分{/color}」と書き換える動機があった人物は1人だけです。"
    menu:
        "「{color=[gui.keyword_color]}11時45分{/color}」と書き換えたのは……"
        "【躑躅|つつじ】 【椿|つばき】":
            jump yuanyangcha_deduction_log_rewrite_tea
        "ジャシー・チェン":
            jump yuanyangcha_deduction_log_rewrite_chen
        "【菊苦菜|きくにがな】 ちこり":
            jump yuanyangcha_deduction_log_rewrite_robusta

label yuanyangcha_deduction_log_rewrite_tea:
    scene bg reception room
    show tea at center
    d normal "「{color=[gui.keyword_color]}11時45分{/color}」と書き換えたのは【躑躅|つつじ】 【椿|つばき】さんです。"
    tea "ふむ、「私の自作自演だった」とは面白い考えだね。"
    tea "しかし、私が書き換えるならもっとふさわしい時間があったのではないか。"
    tea "たとえば、【菊苦菜|きくにがな】 ちこりだけが実験室にいた「8時過ぎ」……とかね。"
    m concerned "【躑躅|つつじ】 【椿|つばき】さんの言い分も、もっともですね"
    jump yuanyangcha_deduction_log_rewrite

label yuanyangcha_deduction_log_rewrite_chen:
    scene bg reception room
    show chen at center
    d normal "「{color=[gui.keyword_color]}11時45分{/color}」と書き換えたのはジャシー・チェンさんです。"
    chen "アイヤ！\n私、「{color=[gui.keyword_color]}11時45分{/color}」はまだ実験室にいましたよ。"
    chen "もしも私が犯人だったら、【菊苦菜|きくにがな】 ちこりさんだけが実験室にいる「8時過ぎ」にします。"
    m concerned "もっとほかに怪しい人がいますね"
    jump yuanyangcha_deduction_log_rewrite

label yuanyangcha_deduction_log_rewrite_robusta:
    scene bg reception room
    show robusta at center
    d normal "「{color=[gui.keyword_color]}11時45分{/color}」と書き換えたのは【菊苦菜|きくにがな】 ちこりさんです。"
    d normal "【菊苦菜|きくにがな】 ちこりさんは毎日、ほかの方よりも1時間早く実験室に到着するようですね。"
    d normal "【菊苦菜|きくにがな】 ちこりさんだけが実験室にいる8時過ぎなら、誰にも見られずにタイマーを早め、ログを書き換えることができた。"
    d normal "また、【菊苦菜|きくにがな】 ちこりさんには「11時30分から12時30分まで実験室にいなかった」というアリバイがあった。"
    d normal "よって、「{color=[gui.keyword_color]}11時45分{/color}」と書き換える動機がある。"
    d normal "しかし、【躑躅|つつじ】 【椿|つばき】さんやジャシー・チェンさんなら「8時過ぎ」と書き換えたはずです。"
    "犯人扱いされて、【菊苦菜|きくにがな】 ちこりは怒りに肩を震わせた。"
    robusta "そんなもの、状況証拠にすぎません！"
    d "もっと決定的な証拠があります。"
    d "それは、毒が盛られた飲み物です。"
    jump yuanyangcha_deduction_poison_coffee

label yuanyangcha_deduction_poison_coffee:
    scene bg reception room
    d normal "毒が検出されたカップにはコーヒーが入っていました。"
    menu:
        "毒が盛られたコーヒーは……"
        "アラビカ種":
            jump yuanyangcha_deduction_poison_coffee_arabica
        "ロブスタ種":
            jump yuanyangcha_deduction_poison_coffee_robusta

label yuanyangcha_deduction_poison_coffee_arabica:
    scene bg reception room
    d normal "毒が盛られたコーヒーは{color=[gui.keyword_color]}アラビカ種{/color}です。"
    show assistant at center
    a "【竜|りん】……アイツに香りの成分を調べてもらっただろーが。"
    m concerned "【竜胆|りんどう】 【茜|あかね】さんとの会話を思い出しましょう"
    jump yuanyangcha_deduction_poison_coffee

label yuanyangcha_deduction_poison_coffee_robusta:
    scene bg reception room
    d normal "毒が盛られたコーヒーは{color=[gui.keyword_color]}ロブスタ種{/color}です。"
    jump yuanyangcha_deduction_robusta_drink

label yuanyangcha_deduction_robusta_drink:
    scene bg reception room
    show robusta at center
    d normal "そして、【菊苦菜|きくにがな】 ちこりさんも飲み物を持参していました。"
    menu:
        "【菊苦菜|きくにがな】 ちこりの飲み物は……"
        "アラビカ種のコーヒー":
            jump yuanyangcha_deduction_robusta_drink_arabica
        "ロブスタ種のコーヒー":
            jump yuanyangcha_deduction_robusta_drink_robusta
        "紅茶":
            jump yuanyangcha_deduction_robusta_drink_tea

label yuanyangcha_deduction_robusta_drink_arabica:
    scene bg reception room
    d normal "【菊苦菜|きくにがな】 ちこりさんの飲み物は{color=[gui.keyword_color]}アラビカ種{/color}のコーヒーです。"
    show assistant at center
    a "たしかにコーヒーだったが、香りが決定的に違うな。"
    m concerned "アラビカ種ではないコーヒーだったはずです"
    jump yuanyangcha_deduction_robusta_drink

label yuanyangcha_deduction_robusta_drink_tea:
    scene bg reception room
    d normal "【菊苦菜|きくにがな】 ちこりさんの飲み物は{color=[gui.keyword_color]}紅茶{/color}です。"
    show assistant at center
    a "お前もあの色が紅茶でないことぐらいは見ただろ。"
    m surprised "たしかにあの黒々とした色ははコーヒーでしたね"
    jump yuanyangcha_deduction_robusta_drink

label yuanyangcha_deduction_robusta_drink_robusta:
    scene bg reception room
    d normal "【菊苦菜|きくにがな】 ちこりさんの飲み物は{color=[gui.keyword_color]}ロブスタ種{/color}のコーヒーです。"
    d normal "毒が盛られたコーヒーと一致しているのですよ。"
    show robusta at r
    robusta "なぜ犯人が、毒を盛るカップに自分の飲み物を入れる必要があるのですか？"
    d normal "【躑躅|つつじ】 【椿|つばき】さんの飲み残しは{color=[gui.keyword_color]}200ml{/color}でしたが、水筒の残りは{color=[gui.keyword_color]}100ml{/color}しかありませんでした。"
    d normal "そこで、自前のカップに水筒の100mlと飲み残しの100mlを注ぎ、200mlを確保した。"
    d normal "しかし、【松風|まつかぜ】 【柚子|ゆず】教授にふるまうには、飲み残しのさらに残りの100mlは少なすぎる。"
    d normal "そこで、あなたは自前の飲み物を注ぎ足したのです。"
    robusta "【躑躅|つつじ】 【椿|つばき】さんやジャシー・チェンさんの飲み物の可能性は？"
    show tea at l
    tea "私は{color=[gui.keyword_color]}紅茶{/color}だ。"
    hide tea
    show chen at l
    chen "私は100％{color=[gui.keyword_color]}アラビカ種{/color}ですよ。"
    hide chen
    robusta "えぇ！\nそんなものを飲んでいたんですか！？"
    robusta "でも、【躑躅|つつじ】 【椿|つばき】さんの飲み残しのように、私のコーヒーを盗んで入れた可能性だったあるでしょう？"
    d normal "まず、【躑躅|つつじ】 【椿|つばき】さんなら、【菊苦菜|きくにがな】 ちこりさんに罪を着せるときに自分の飲み物を混ぜたり、自分で口をつける理由がない。"
    robusta "ええ、それは認めましょう。"
    d normal "そして、ジャシーチェンさんなら、紅茶にコーヒーを混ぜたりしないんですよ。"
    jump yuanyangcha_deduction_chen_home

label yuanyangcha_deduction_chen_home:
    scene bg reception room
    d "紅茶にコーヒーを混ぜると、容疑がジャシーチェンさんに向くことになります。\nなぜなら……"
    menu:
        "ジャシーチェンの故郷では……"
        "紅茶にコーヒーを入れることがあるから":
            jump yuanyangcha_deduction_chen_home_hong_kong
        "コーヒーをブラックで飲まないから":
            jump yuanyangcha_deduction_chen_home_vietnam

label yuanyangcha_deduction_chen_home_vietnam:
    scene bg reception room
    d normal "ジャシーチェンさんの故郷では、コーヒーをブラックで飲まないからです。"
    show assistant at center
    a "ロブスタ種のコーヒーに練乳を入れるのはベトナムだろ。"
    m surprised "ジャシーチェンさんの故郷は香港で、コーヒーはアラビカ種でしたね"
    jump yuanyangcha_deduction_chen_home

label yuanyangcha_deduction_chen_home_hong_kong:
    scene bg reception room
    d normal "ジャシーチェンさんの故郷では、{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}として、紅茶にコーヒーを入れることがあるからです。"
    d normal "さらに、ジャシーチェンさんは紅茶を注ぎ足すことができました。"
    show chen at r
    chen "ティーバッグを持ち歩いてますからね。"
    show assistant at l
    a "で、【菊苦菜|きくにがな】 ちこりはなんで紅茶にコーヒーを注いんだんだ？"
    d normal "それは、紅茶をコーヒーと誤認したからです。"

label yuanyangcha_deduction_robusta_miss:
    scene bg reception room
    d normal "【菊苦菜|きくにがな】 ちこりが紅茶をコーヒーと誤認した原因は2つ。"
    d normal "1つは「給湯室が暗かったから」。\nもう1つの原因は……"
    menu:
        "【菊苦菜|きくにがな】 ちこりの……"
        "睡眠不足":
            jump yuanyangcha_deduction_robusta_miss_sleep
        "嗅覚障害":
            jump yuanyangcha_deduction_robusta_miss_smell

label yuanyangcha_deduction_robusta_miss_sleep:
    scene bg reception room
    d normal "【菊苦菜|きくにがな】 ちこりさんの睡眠不足です。"
    show assistant at center
    a "いくら判断力が低下しても、紅茶とコーヒーの香りを間違えるか？"
    m concerned "香りがわからなかった理由があるはずです"
    jump yuanyangcha_deduction_robusta_miss

label yuanyangcha_deduction_robusta_miss_smell:
    scene bg reception room
    d normal "【菊苦菜|きくにがな】 ちこりさんの{color=[gui.keyword_color]}嗅覚障害{/color}です。"
    d normal "色も香りも確認できなかった【菊苦菜|きくにがな】 ちこりさんは、{color=[gui.keyword_color]}紅茶{/color}を{color=[gui.keyword_color]}コーヒー{/color}と誤認したのです。"
    "コンプレックスを暴露された【菊苦菜|きくにがな】 ちこりは、不快感をあらわにした。"
    show robusta at center
    robusta "仮に私が犯人だったとして、【松風|まつかぜ】 【柚子|ゆず】教授を毒殺する動機がありませんよ？"
    jump yuanyangcha_deduction_motive

label yuanyangcha_deduction_motive:
    scene bg reception room
    d normal "事件の前日に【松風|まつかぜ】 【柚子|ゆず】教授からメールを受け取ったあなたは、自身の論文の問題点に気づきました。"
    menu:
        "【菊苦菜|きくにがな】 ちこりの論文の問題点は……"
        "功績の横取り":
            jump yuanyangcha_deduction_motive_tea
        "助成金の横領":
            jump yuanyangcha_deduction_motive_chen
        "データの捏造":
            jump yuanyangcha_deduction_motive_robusta

label yuanyangcha_deduction_motive_tea:
    scene bg reception room
    d normal "【松風|まつかぜ】 【柚子|ゆず】教授が功績を{color=[gui.keyword_color]}横取り{/color}していたことです。"
    show assistant at center
    a "それはどっちかというと、【躑躅|つつじ】 【椿|つばき】の動機じゃねぇか？"
    m concerned "もっと研究者生命にかかわる動機でしたね"
    jump yuanyangcha_deduction_motive

label yuanyangcha_deduction_motive_chen:
    scene bg reception room
    d normal "【松風|まつかぜ】 【柚子|ゆず】教授が助成金を{color=[gui.keyword_color]}横領{/color}していたことです。"
    show assistant at center
    a "それはどっちかというと、ジャシー・チェンの動機じゃねぇか？"
    m concerned "金銭的な問題ではありませんでしたね"
    jump yuanyangcha_deduction_motive

label yuanyangcha_deduction_motive_robusta:
    scene bg reception room
    d normal "【松風|まつかぜ】 【柚子|ゆず】教授が{color=[gui.keyword_color]}データの捏造{/color}に気づいたことです。"
    d normal "データの捏造が公表されれば研究者生命が終わりますから、動機としては十分ですよね。"
    "そのとき、【濁澤|にごりさわ】ニコルの端末から通知音が鳴り響いた。"
    show assistant at l
    a "解析完了。\n【菊苦菜|きくにがな】 ちこり、あんたの論文は100％クロだ。"
    show robusta at r
    "研究者としての死を宣告された【菊苦菜|きくにがな】 ちこりは膝から崩れ落ちた。"
    hide assistant
    show chen at l
    chen "アイヤ！\n誰よりも実験していたのに、有意差が出なかったんですか？！"
    hide chen
    show tea at l
    tea "ふむ、興味深い研究だと思っていたのだがね。"
    hide tea
    d normal "【菊苦菜|きくにがな】 ちこりさんの行動をおさらいしましょう。"
    d normal "【松風|まつかぜ】 【柚子|ゆず】教授からのメールをみたあなたは、一連の犯行を計画し、実行しました。"
    d normal "大学生協で公式マグカップを買い、8時に実験室に到着、毒を入手し、タイマーを5分に早め、ログの操作日時を「11時45分」に書き換える。"
    d normal "11時30分、食堂に行くと見せかけて、給湯室の棚に隠れる。"
    d normal "12時、【躑躅|つつじ】 【椿|つばき】さんが放置した水筒の中身を購入したマグカップに注ぎ、【躑躅|つつじ】 【椿|つばき】のマグカップを給湯室の棚に隠す。"
    d normal "このとき、水筒の中身だけでは飲み残しの量に満たなかったため、飲み残しの一部も購入したマグカップに注いだ。"
    d normal "15時20分、給湯室で【躑躅|つつじ】 【椿|つばき】さんのマグカップを棚から取り出し、電子レンジで温めなおしてから毒を加える。"
    d normal "このとき、視覚と嗅覚が制限されていたあなたは、飲み残しの紅茶をコーヒーと誤認し、カップに自前のコーヒーを注ぎたすことで満たした。"
    d normal "さらに、水切りラックから【松風|まつかぜ】 【柚子|ゆず】教授のカップを回収する。"
    d normal "個人面談で【松風|まつかぜ】 【柚子|ゆず】教授がデータの捏造に気づいていることを確認し、公表までに猶予をもらってから、毒入りのカップを渡した。"
    d normal "【松風|まつかぜ】 【柚子|ゆず】教授も【躑躅|つつじ】 【椿|つばき】さんも大学生協の公式マグカップを使っているため、自身のカップと勘違いした【松風|まつかぜ】 【柚子|ゆず】教授は疑うことなく口にする。"
    d normal "17時、亡くなった【松風|まつかぜ】 【柚子|ゆず】教授を搬送する混乱に乗じて、面談の内容が記載されている【松風|まつかぜ】 【柚子|ゆず】教授の研究ノートを回収した。"
    d normal "【菊苦菜|きくにがな】 ちこりさん、間違いないですね？"
    robusta "【躑躅|つつじ】 【椿|つばき】があんな小さな水筒に紅茶なんて入れていなければ……"
    d angry "いいえ、あなたが論文のデータを捏造したあげく、その告発者を口封じしようとしなければ、そもそも【松風|まつかぜ】 【柚子|ゆず】教授は亡くなっていませんでしたよ。"
    robusta "ええ。成果を急ぐあまり、私は嗅覚だけでなく倫理観も失っていたようです。"
    scene bg reception room
    show robusta at r
    show matcha behind robusta:
        xpos 0.35
    "ボクからの目線を受けて、【町矢|まちや】 【抹茶|まっちゃ】は【菊苦菜|きくにがな】 ちこりの両手に手錠をかけた。"
    matcha "刑法199条違反の明白な疑いがあり、逃亡、および、証拠隠滅の恐れがあるため、緊急逮捕しますわ。"
    "さて、【竜胆|りんどう】 【茜|あかね】からの依頼は事件を解決することであって、事件を担当することではない。"
    "大量の書類を警視庁に放置してきたのだ。\nこれ以上増やされてはかなわない。"
    d happy "それでは、逮捕状の請求と裁判書類の作成はおまかせしますね。"
    show assistant at l
    a "オレたちが集めた証拠も送ってやるから、感謝しろよ。"
    hide assistant
    with dissolve
    show gal behind robusta:
        xpos 0
    gal "あいつら、面倒なとこだけ押しつけてきたんだけど！"
    "【毛利|もうり】 【森子|もりこ】からの非難を尻目に、ボクとニコルは現場から一目散に逃げ出した。"
    jump yuanyangcha_epilogue_coffee

label yuanyangcha_epilogue_coffee:
    scene bg interrogation room
    tp "8月28日（金） 10:00\n警視庁 第四取調室"
    "【竜胆|りんどう】 【茜|あかね】の助けを借りたことで、なんとか書類を片付け、一段落ついたころ。"
    "【竜胆|りんどう】 【茜|あかね】からのメールで取調室に呼び出されると、今度は【躑躅|つつじ】 【椿|つばき】も在席していた。"
    show coffee at center
    show tea at r
    with dissolve
    coffee "【菊苦菜|きくにがな】 ちこりの家宅を捜索したところ、すり替えたマグカップと、【松風|まつかぜ】 【柚子|ゆず】教授の研究ノートが見つかりました。"
    d normal "【躑躅|つつじ】 【椿|つばき】さんの潔白が証明されたようで、なによりです。"
    coffee "あやうく、新しいルームシェア相手を探すところでした。"
    tea "【茜|あかね】君、冗談がきつすぎるよ。"
    coffee "私が何を作っても、「おいしい」としか言わないじゃないですか。"
    tea "【茜|あかね】君が作った料理を【茜|あかね】君と食べれば、何でもおいしいのさ。"
    coffee "【椿|つばき】……。"
    show assistant at l
    a "オレたちは何を見せられてんだ？"
    d normal "それで、研究室のほうは？"
    tea "ふむ。【松風|まつかぜ】 【柚子|ゆず】教授の研究室と研究は、私とジャシー君が共同で引き継ぐことにしたよ。"
    tea "お蔵入りさせるのは人類の損失だからね。"
    tea "君たちがいなければ、科学の進歩が5年は遅れるところだったよ。\n深く感謝する。"
    a "推理とお茶の知識は全部こいつに任せきりだったがな。"
    d happy "ニコルの情報解析とコーヒー知識も不可欠でしたよ。"
    coffee "【鴛鴦茶|ユンヨンチャ】には紅茶とコーヒーの両方が必要なように、今回の事件の解決にも【水神|みなかみ】 【南|みなみ】さんと【濁澤|にごりさわ】ニコルさんの両方が必要だった、ということですね。"
    m concerned "飲み物にちなんだ、おかしな事件が重なっていますね"
    m concerned "偶然だといいのですが……"
    chara_rb "つづく"
    # return でゲームを終了します。\n
    return
