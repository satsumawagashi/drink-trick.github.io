﻿# TODO: Translation updated at 2026-08-15 08:20

translate english strings:

    # game/options.rpy:16
    old "DRINK TRICK"
    new "DRINK TRICK"

