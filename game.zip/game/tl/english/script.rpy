﻿# game/script.rpy:327
translate english yuanyangcha_trailer_c139b695:

    # "桜月大学の研究室で毒殺事件が発生"
    "A poisoning incident has occurred in a laboratory at Sakura Moon University."

# game/script.rpy:328
translate english yuanyangcha_trailer_ae5761b1:

    # "毒殺に使われた飲み物は【鴛鴦茶|ユンヨンチャ】？！"
    "The drink used in the poisoning was Yuen Yeung Cha?!"

# game/script.rpy:329
translate english yuanyangcha_trailer_d5cccd92:

    # "なぜ犯人は紅茶とコーヒーを混ぜてから毒を盛ったのか？"
    "Why did the culprit mix black tea and coffee before adding the poison?"

# game/script.rpy:334
translate english yuanyangcha_hangout_cc1e2c46:

    # tp "8月25日（火） 11:00\n警視庁 捜査一課 執務室"
    tp "Tuesday, August 25, 11:00\nTokyo Metropolitan Police Department, First Investigation Division Office"

# game/script.rpy:335
translate english yuanyangcha_hangout_c9ab1b07:

    # "捜査一課の警察官は複数の事件を同時に担当しているため、現場に出ない日も、裁判に必要な書類の作成に忙殺されることになる。"
    "Since investigators in the First Investigation Division handle multiple cases at the same time, even on days when they do not go out into the field, they are kept busy preparing documents required for court proceedings."

# game/script.rpy:336
translate english yuanyangcha_hangout_83bd32e1:

    # "デスクに書類を広げていると、鑑識課の【竜胆|りんどう】 【茜|あかね】からメールが来た。"
    "As I spread documents across my desk, I received an email from Akane Rindo of the Forensic Science Division."

# game/script.rpy:337
translate english yuanyangcha_hangout_42ae36d8:

    # "送り先には【濁澤|にごりさわ】ニコルも入っている。"
    "Nicole Nigorisawa was also included among the recipients."

# game/script.rpy:340
translate english yuanyangcha_hangout_f821a743:

    # tea "{color=[gui.machine_color]}「お二人に相談したいことがあるので、第四取調室に来ていただけますでしょうか？」{/color}"
    tea "{color=[gui.machine_color]}\“There is something I would like to discuss with you both. Could you please come to Interrogation Room Four?\”{/color}"

# game/script.rpy:342
translate english yuanyangcha_hangout_ada7d8c9:

    # "会議室を抑えるほどではない打ち合わせで、取調室を使うことは珍しくない。"
    "It is not unusual to use an interrogation room for a meeting that is not important enough to reserve a conference room."

# game/script.rpy:343
translate english yuanyangcha_hangout_c62befcd:

    # "隣席の【濁澤|にごりさわ】ニコルが声をかけてきた。"
    "Nicole Nigorisawa, who sat next to me, spoke up."

# game/script.rpy:345
translate english yuanyangcha_hangout_b2546b78:

    # a "せっかくだし、【竜胆|りんどう】 【茜|あかね】に飲み物でも持っていくか？"
    a "Since we are going anyway, should we bring Akane Rindo something to drink?"

# game/script.rpy:346
translate english yuanyangcha_hangout_6ff49a17:

    # d happy "ええ、こんなときは「ギャバロン茶」ですね。"
    d happy "Yes. At times like this, Gabalong tea is the way to go."

# game/script.rpy:347
translate english yuanyangcha_hangout_0ea15aaf:

    # a "「ギャバロン茶」？"
    a "“Gabalong tea”?"

# game/script.rpy:348
translate english yuanyangcha_hangout_c7f29483:

    # d normal "生の茶葉を窒素ガスの中でしばらく保存することで、「GABA」の含有量が数十倍になったお茶のことです。"
    d normal "It is tea made by storing fresh tea leaves in nitrogen gas for a while, which increases their GABA content several dozenfold."

# game/script.rpy:349
translate english yuanyangcha_hangout_2bea432c:

    # a "「GABA」の含有量を【謳|うた】った商品、いろんな企業からが出てるな。"
    a "There are products from all kinds of companies that tout their GABA content."

# game/script.rpy:350
translate english yuanyangcha_hangout_442b38f2:

    # d happy "「ギャバロン茶」の発明者があえて特許申請しなかったことがGABAブームのきっかけですよ。"
    d happy "The GABA boom was sparked by the inventor of Gabalong tea deliberately choosing not to apply for a patent."

# game/script.rpy:351
translate english yuanyangcha_hangout_ff71afe4:

    # d normal "ちなみに、「ギャバロン茶」の「ロン」は「烏龍茶」のことですね。"
    d normal "Incidentally, the “long” in “Gabalong tea” refers to oolong tea."

# game/script.rpy:352
translate english yuanyangcha_hangout_65f588d1:

    # a "そういえば、「烏龍茶」って「緑茶」や「紅茶」と何が違うんだ？"
    a "Come to think of it, what is the difference between oolong tea and green tea or black tea?"

# game/script.rpy:353
translate english yuanyangcha_hangout_3b388ce8:

    # d "「緑茶」「烏龍茶」「紅茶」の違いは発酵度合いだけです。"
    d "The only difference between green tea, oolong tea, and black tea is the degree of fermentation."

# game/script.rpy:354
translate english yuanyangcha_hangout_da1fd86c:

    # d "中国茶では「緑茶」「白茶」「黄茶」「青茶」「紅茶」の順に発酵度合いが上がっていき、「烏龍茶」は「青茶」の一種ですね。"
    d "In Chinese tea, the degree of fermentation increases in the order of green tea, white tea, yellow tea, blue tea, and black tea, and oolong tea is a type of blue tea."

# game/script.rpy:355
translate english yuanyangcha_hangout_1305f73e:

    # d concerned "もっとも、お茶の「発酵」は厳密には「発酵」ではなく「付加反応」なのですが……。"
    d concerned "Strictly speaking, however, the “fermentation” of tea is not actually fermentation, but an addition reaction…"

# game/script.rpy:356
translate english yuanyangcha_hangout_8c098bf1:

    # a "でもさ、せっかくエスプレッソ・マシンがあるんだから、アイスカフェラテだろ。"
    a "But since we have an espresso machine, it has to be an iced caffe latte."

# game/script.rpy:357
translate english yuanyangcha_hangout_87755a27:

    # d concerned "そもそも「カフェオレ」と「カフェラテ」ってどちらも「コーヒーと牛乳」ではありませんか？"
    d concerned "Aren’t “café au lait” and “caffè latte” both just “coffee and milk” in the first place?"

# game/script.rpy:358
translate english yuanyangcha_hangout_5911811d:

    # a "いい質問だ。\nまず、コーヒーの抽出法には主にドリップとエスプレッソの2種類ある。"
    a "Good question.\nFirst, there are two main methods of brewing coffee: drip and espresso."

# game/script.rpy:359
translate english yuanyangcha_hangout_f6b93eb7:

    # a "そして、1902年のミラノ万博でエスプレッソ・マシンが発表されたことで、エスプレッソはイタリアを代表する飲み物になった。"
    a "Then, when the espresso machine was unveiled at the 1902 Milan International Exposition, espresso became a drink representative of Italy."

# game/script.rpy:360
translate english yuanyangcha_hangout_34383cf8:

    # a "つまり、フランス語の「カフェオレ」はドリップ、イタリア語の「カフェラテ」はエスプレッソがそれぞれベースなんだ。"
    a "In other words, the French “café au lait” is based on drip coffee, while the Italian “caffè latte” is based on espresso."

# game/script.rpy:361
translate english yuanyangcha_hangout_d1b8deb9:

    # a "同様に、「カプチーノ」もイタリア語だからエスプレッソがベースで、「カフェラテ」との違いは牛乳の泡の層が1cm以上あることだ。"
    a "Likewise, “cappuccino” is Italian, so it is based on espresso, and the difference from a caffè latte is that the layer of milk foam is at least one centimeter thick."

# game/script.rpy:362
translate english yuanyangcha_hangout_76c78ef9:

    # a "ちなみに、「カプチーノ」はもとは「カプチン会の修道士」のことで、その語源はフードのついた修道服「カップッチョ」だ。"
    a "Incidentally, “cappuccino” originally referred to a Capuchin friar, and its name comes from “cappuccio,” a hooded monastic robe."

# game/script.rpy:363
translate english yuanyangcha_hangout_d2eb8b89:

    # d normal "そういえば、喫茶店ですと「カプチーノ」が「カフェラテ」よりも安価なことがありますね。"
    d normal "Come to think of it, coffee shops sometimes charge less for a cappuccino than for a caffè latte."

# game/script.rpy:364
translate english yuanyangcha_hangout_82285a9a:

    # a "「カプチーノ」は牛乳の泡の占める比率が高くて、泡立てている分だけ原料の牛乳が少なくて済むからな。"
    a "Cappuccino has a higher proportion of milk foam, so because the milk is frothed, less milk is needed as an ingredient."

# game/script.rpy:365
translate english yuanyangcha_hangout_deefe5ea:

    # a "「アイスコーヒー」が「ホットコーヒー」よりも高いことがあるのも、原材料の量の違いだ。"
    a "The reason iced coffee can also cost more than hot coffee is the difference in the amount of ingredients."

# game/script.rpy:366
translate english yuanyangcha_hangout_f2025295:

    # a "飲み物が冷たいと味覚が鈍るから、より大量のコーヒー豆を使わないと、同じ濃さに感じられないんだよ。"
    a "When a drink is cold, your sense of taste becomes duller, so you need to use more coffee beans to make it taste equally strong."

# game/script.rpy:367
translate english yuanyangcha_hangout_605e3990:

    # d surprised "そういえば、【竜胆|りんどう】 【茜|あかね】を待たせたままではありませんか？"
    d surprised "Come to think of it, aren’t we keeping Akane Rindo waiting?"

# game/script.rpy:368
translate english yuanyangcha_hangout_0285e8f3:

    # a "しゃあねえ、じゃんけんで決めるぞ！"
    a "All right, then. We will decide with rock-paper-scissors!"

# game/script.rpy:369
translate english yuanyangcha_hangout_9b586fb2:

    # d happy "受けて立ちますよ！"
    d happy "Bring it on!"

# game/script.rpy:385
translate english yuanyangcha_coffee_arrival_9ef14620:

    # tp "同日 11:10\n警視庁 第四取調室"
    tp "Same day, 11:10\nTokyo Metropolitan Police Department, Interrogation Room Four"

# game/script.rpy:389
translate english yuanyangcha_coffee_arrival_8006e41e:

    # "第四取調室にいたのは【竜胆|りんどう】 【茜|あかね】だけだった。\nやはり非公式な打ち合わせのようだ。"
    "Only Akane Rindo was in Interrogation Room Four.\nAs expected, it seemed to be an unofficial meeting."

# game/script.rpy:398
translate english yuanyangcha_coffee_tea_7e444b1b:

    # d happy "アイスティーをどうぞ。"
    d happy "Here is some iced tea."

# game/script.rpy:399
translate english yuanyangcha_coffee_tea_b18b46d3:

    # coffee "「お茶出し」というように、普通はお茶ですよね。\nコーヒーが飲めない人も多いでしょうし。"
    coffee "As the phrase “serving tea” suggests, tea is the usual choice.\nBesides, many people cannot drink coffee."

# game/script.rpy:400
translate english yuanyangcha_coffee_tea_8a437fdc:

    # "【竜胆|りんどう】 【茜|あかね】は苦々しい顔をしながら一気飲みした。"
    "Akane Rindo drank it all in one go, making a bitter face."

# game/script.rpy:404
translate english yuanyangcha_coffee_coffee_73fe8a45:

    # a "ほら、アイスカフェラテだ。"
    a "Here you go, an iced caffè latte."

# game/script.rpy:405
translate english yuanyangcha_coffee_coffee_d246b238:

    # coffee "ありがとうございます。\nコーヒーには目がないもので。"
    coffee "Thank you.\nI am very fond of coffee."

# game/script.rpy:406
translate english yuanyangcha_coffee_coffee_f39c0e7c:

    # "【竜胆|りんどう】 【茜|あかね】は味わいながら飲んだ。"
    "Akane Rindo drank it slowly, savoring the flavor."

# game/script.rpy:410
translate english yuanyangcha_coffee_request_b1c95786:

    # coffee "単刀直入に申し上げますと、お二人には「【松風|まつかぜ】 【柚子|ゆず】教授毒殺事件」の調査に協力してほしいのです。"
    coffee "To get straight to the point, I would like the two of you to help investigate the poisoning of Professor Yuzu Matsukaze."

# game/script.rpy:411
translate english yuanyangcha_coffee_request_5938f5ad:

    # coffee "本来なら私も捜査に参加していたはずでしたが、第一容疑者が私のルームシェア相手の【躑躅|つつじ】 【椿|つばき】でして……。"
    coffee "I should have been part of the investigation myself, but the prime suspect is Tsubaki Tsutsuji, my roommate, so…"

# game/script.rpy:412
translate english yuanyangcha_coffee_request_3187369f:

    # coffee "犯罪捜査規範14条の定めるところにより、私は捜査本部から外されてしまいました。"
    coffee "Under Article 14 of the Criminal Investigation Rules, I was removed from the investigation headquarters."

# game/script.rpy:413
translate english yuanyangcha_coffee_request_8437395c:

    # coffee "あの人は常識が欠如していますが、「コーヒーを飲むこと」と「人殺し」だけは絶対にしません。\n何かの間違いです。"
    coffee "She may lack common sense, but she would never, ever drink coffee or kill someone.\nThis must be some kind of mistake."

# game/script.rpy:414
translate english yuanyangcha_coffee_request_9839f2c4:

    # coffee "どうか、彼女への疑いを晴らしていただけないでしょうか？"
    coffee "Could you please clear her of suspicion?"

# game/script.rpy:415
translate english yuanyangcha_coffee_request_c1bf1258:

    # coffee "私にできることなら、なんでもしますので。"
    coffee "I will do anything I can to help."

# game/script.rpy:416
translate english yuanyangcha_coffee_request_54f862c6:

    # d desired "「なんでも」というと、たとえばデートからの休憩からの……"
    d desired "“Anything,” you say? For example, a date, followed by a break, followed by…"

# game/script.rpy:417
translate english yuanyangcha_coffee_request_7c3eb1a3:

    # a "こいつの妄想は無視してくれ。\nあとで書類作成を手伝ってくれればいいから。"
    a "Ignore his fantasies.\nIt is enough if you help me prepare the paperwork later."

# game/script.rpy:418
translate english yuanyangcha_coffee_request_6d1fcac6:

    # d happy "【竜胆|りんどう】 【茜|あかね】さんには常日頃からお世話になっておりますからね。\n夜のネタとしても。"
    d happy "Akane Rindo is always taking good care of us, after all.\nEven as material for nighttime entertainment."

# game/script.rpy:419
translate english yuanyangcha_coffee_request_67010926:

    # a "息を吸うようにセクハラすんな！"
    a "Stop sexually harassing her as naturally as you breathe!"

# game/script.rpy:420
translate english yuanyangcha_coffee_request_f7a5e84d:

    # coffee "とにかく、ありがとうございます！"
    coffee "In any case, thank you very much!"

# game/script.rpy:429
translate english yuanyangcha_coffee_drive_c60ca668:

    # "【竜胆|りんどう】 【茜|あかね】はボクたちを警察車両に乗せると、運転しながら事件の概要を話しだした。"
    "Akane Rindo put us in a police vehicle and began explaining the outline of the case while driving."

# game/script.rpy:430
translate english yuanyangcha_coffee_drive_38b88ec5:

    # coffee "被害者は桜月大学で【松風|まつかぜ】研究室の室長をしている【松風|まつかぜ】 【柚子|ゆず】教授です。\n専門は薬学です。"
    coffee "The victim is Professor Yuzu Matsukaze, head of the Matsukaze Laboratory at Sakura Moon University.\nHer specialty is pharmacology."

# game/script.rpy:431
translate english yuanyangcha_coffee_drive_587ed72c:

    # coffee "毒殺に使われた薬品はマウスの殺処分に使うもので、無味無臭、人間が摂取した場合は4時間で死に至ります。"
    coffee "The chemical used in the poisoning is used to euthanize mice. It is tasteless and odorless, and if ingested by a human, it causes death within four hours."

# game/script.rpy:432
translate english yuanyangcha_coffee_drive_538b9494:

    # coffee "死亡時刻は19時なので、服薬推定時刻は15時です。"
    coffee "The time of death was 19:00, so the estimated time of ingestion was 15:00."

# game/script.rpy:433
translate english yuanyangcha_coffee_drive_976ff894:

    # coffee "その薬品は{color=[gui.keyword_color]}大学生協の公式マグカップ{/color}から検出されたので、おそらく犯人はなんらかの飲み物に毒を混ぜて飲ませたのでしょう。"
    coffee "The chemical was detected in the {color=[gui.keyword_color]}official university co-op mug{/color}, so the culprit probably mixed the poison into some kind of drink and had the victim drink it."

# game/script.rpy:434
translate english yuanyangcha_coffee_drive_8962d103:

    # coffee "【躑躅|つつじ】 【椿|つばき】が第一容疑者になったのは、そのマグカップから彼女の唾液と指紋も検出されたからです。"
    coffee "Tsubaki Tsutsuji became the prime suspect because her saliva and fingerprints were also detected on that mug."

# game/script.rpy:435
translate english yuanyangcha_coffee_drive_437467f5:

    # d concerned "1つのカップから2人の唾液、つまりはそういう関係ということでしょうか？"
    d concerned "Two people’s saliva on a single cup? Does that mean they were in that kind of relationship?"

# game/script.rpy:436
translate english yuanyangcha_coffee_drive_b976bb3f:

    # a "たとえ恋仲でも、2人で同じカップは使い回さねぇだろ。"
    a "Even if they were romantically involved, they would not share the same cup."

# game/script.rpy:437
translate english yuanyangcha_coffee_drive_d7e34a03:

    # "ニコルにツッコまれると、車は事件現場の桜月大学に到着した。"
    "After Nicole shot back at me, the car arrived at Sakura Moon University, the scene of the crime."

# game/script.rpy:484
translate english yuanyangcha_coffee_encounter_6a9e1bf9:

    # tp "同日 12:00\n桜月大学 警備室"
    tp "Same day, 12:00\nSakura Moon University, Security Office"

# game/script.rpy:486
translate english yuanyangcha_coffee_encounter_8c988bef:

    # "【竜胆|りんどう】 【茜|あかね】の案内は、桜月大学の警備室までだった。"
    "Akane Rindo’s escort ended at the security office of Sakura Moon University."

# game/script.rpy:489
translate english yuanyangcha_coffee_encounter_a349cf60:

    # coffee "私が容疑者と接触したり、ましてや研究室の監視カメラに写ってしまうと【躑躅|つつじ】 【椿|つばき】の不利になるので、私が同行できるはここまでです。"
    coffee "If I come into contact with the suspect, or worse, appear on the surveillance cameras in the laboratory, it would put Tsubaki Tsutsuji at a disadvantage, so this is as far as I can accompany you."

# game/script.rpy:490
translate english yuanyangcha_coffee_encounter_891d93d6:

    # coffee "私はここで待機しているので、捜査本部で押収済みの証拠品について確認したくなったら、こちらにいらしてください。"
    coffee "I will wait here, so if you want to check any evidence already seized by the investigation headquarters, please come back here."

# game/script.rpy:491
translate english yuanyangcha_coffee_encounter_1871c266:

    # coffee "微力ながら、草葉の陰から応援させていただきます。"
    coffee "I will be rooting for you from the shadows, however little I can do to help."

# game/script.rpy:492
translate english yuanyangcha_coffee_encounter_d3a7cb7a:

    # m concerned "勝手にお亡くなりにならないでください"
    m concerned "Please do not die on your own."

# game/script.rpy:514
translate english yuanyangcha_security_research_camera_eeb70d15:

    # d normal "やはり、監視カメラの映像は気になりますね。"
    d normal "As expected, the surveillance camera footage is concerning."

# game/script.rpy:516
translate english yuanyangcha_security_research_camera_72cfe3c6:

    # coffee "危険な薬品や貴重な資料を保管している部屋、今回ですと、実験室と執務室の入口には監視カメラがあります。"
    coffee "There are surveillance cameras at the entrances to rooms where dangerous chemicals and valuable materials are stored—in this case, the laboratory and office."

# game/script.rpy:517
translate english yuanyangcha_security_research_camera_bbb13fde:

    # coffee "事件当日の実験室と執務室の入退室のタイムテーブルがあるので、お見せしますね。"
    coffee "I have a timetable of who entered and left the laboratory and office on the day of the incident, so I will show it to you."

# game/script.rpy:520
translate english yuanyangcha_security_research_camera_695ca09d:

    # a "被害者の【松風|まつかぜ】 【柚子|ゆず】は13時から、意識不明で搬送された17時まで執務室にいるな。"
    a "The victim, Professor Yuzu Matsukaze, was in the office from 13:00 until 17:00, when she was transported to the hospital unconscious."

# game/script.rpy:521
translate english yuanyangcha_security_research_camera_33d18a32:

    # a "そして、15時に【躑躅|つつじ】 【椿|つばき】、ジャシー・チェン、【菊苦菜|きくにがな】 ちこりの3人が入れ違いに執務室を訪れている。"
    a "And at 15:00, Tsubaki Tsutsuji, Jassie Chen, and Chikori Kikugana visited the office one after another."

# game/script.rpy:522
translate english yuanyangcha_security_research_camera_c5e249a4:

    # m normal "服薬推定時刻に被害者と接触したのはこの3人ですか"
    m normal "These three are the people who came into contact with the victim around the estimated time of ingestion?"

# game/script.rpy:536
translate english yuanyangcha_security_research_poster_18c7d4f9:

    # d normal "映画のポスターが貼ってありますね。"
    d normal "There is a movie poster here."

# game/script.rpy:538
translate english yuanyangcha_security_research_poster_af3b8b8d:

    # a "『最高の人生の見つけ方』か。\n日本でリメイクされたこともある名作だ。"
    a "“The Bucket List.”\nIt is a classic that was also remade in Japan."

# game/script.rpy:539
translate english yuanyangcha_security_research_poster_098c583f:

    # a "余命わずかの自動車整備士と大富豪が死ぬまでにやりたいことリストを作って思い出づくりする話なんだが、キーアイテムとして「コピルアク」というコーヒーが出てくる。"
    a "It is a story about a terminally ill auto mechanic and a billionaire who make a list of things they want to do before they die and create memories together, and a coffee called “Kopi Luwak” appears as a key item."

# game/script.rpy:540
translate english yuanyangcha_security_research_poster_68852893:

    # d concerned "「コピルアク」？"
    d concerned "“Kopi Luwak”?"

# game/script.rpy:541
translate english yuanyangcha_security_research_poster_05d4b3b4:

    # a "コーヒーの果実を食べたジャコウネコの糞から、消化されなかった生豆を集めた、インドネシアのコーヒーだ。\n「世界一高いコーヒー」としてイグノーベル抹茶養学賞をとったこともある。"
    a "It is an Indonesian coffee made by collecting undigested green coffee beans from the feces of civets that have eaten coffee cherries.\nIt has even won an Ig Nobel Matcha Nutrition Award as “the world’s most expensive coffee.”"

# game/script.rpy:542
translate english yuanyangcha_security_research_poster_3c0fa7ad:

    # a "動物の糞から採るコーヒーには他にも、インドでサルの糞から集める「モンキー・コーヒー」、ブラジルでジャクーという鳥の糞から集める「ジャクー・コーヒー」、タイでゾウの糞から集める「ブラック・アイボリー」が存在するな。"
    a "There are other coffees made from animal feces, too: “Monkey Coffee,” made from monkey droppings in India; “Jacu Coffee,” collected from the droppings of a bird called the jacu in Brazil; and “Black Ivory,” made from elephant dung in Thailand."

# game/script.rpy:543
translate english yuanyangcha_security_research_poster_92396918:

    # d surprised "動物性愛と糞便性愛の複合でしょうか？"
    d surprised "Is that a combination of zoophilia and coprophilia?"

# game/script.rpy:544
translate english yuanyangcha_security_research_poster_7084007e:

    # a "珍味への探求心を性欲扱いすんな！\nあと、生豆はパウチで覆われているし、ちゃんと洗ったあとに焙煎するから衛生的だ！"
    a "Do not treat the pursuit of delicacies as sexual desire!\nBesides, the green beans are covered by a pouch, and they are properly washed before roasting, so they are hygienic!"

# game/script.rpy:545
translate english yuanyangcha_security_research_poster_154eb4c7:

    # m concerned "怒られてしまいました"
    m concerned "I got scolded."

# game/script.rpy:572
translate english yuanyangcha_security_talk_poison_drink_342e34f1:

    # d normal "毒が検出されたマグカップの中身について、詳しくお聞かせ願えますか？"
    d normal "Could you tell us more about the contents of the mug in which the poison was detected?"

# game/script.rpy:574
translate english yuanyangcha_security_talk_poison_drink_45d90f4f:

    # coffee "はい。\n【松風|まつかぜ】 【柚子|ゆず】と【躑躅|つつじ】 【椿|つばき】の唾液と指紋のほかに、牛乳と砂糖、{color=[gui.keyword_color]}紅茶{/color}と{color=[gui.keyword_color]}コーヒー{/color}が検出されました。"
    coffee "Yes.\nIn addition to the saliva and fingerprints of Yuzu Matsukaze and Tsubaki Tsutsuji, milk, sugar, {color=[gui.keyword_color]}tea{/color}, and {color=[gui.keyword_color]}coffee{/color} were detected."

# game/script.rpy:576
translate english yuanyangcha_security_talk_poison_drink_74d3575b:

    # a "{color=[gui.keyword_color]}紅茶{/color}と{color=[gui.keyword_color]}コーヒー{/color}？\nどちらか片方は洗い残しとかじゃなねえよな？"
    a "{color=[gui.keyword_color]}Tea{/color} and {color=[gui.keyword_color]}coffee{/color}?\nOne of them isn't just residue that wasn't washed out, is it?"

# game/script.rpy:577
translate english yuanyangcha_security_talk_poison_drink_88260e0e:

    # coffee "いえ、どちらも残量の1/3以上を占めています。"
    coffee "No, each of them accounts for more than one-third of the remaining contents."

# game/script.rpy:578
translate english yuanyangcha_security_talk_poison_drink_c3e33484:

    # a "は？\nわけがわからん。"
    a "Huh?\nI don't get it."

# game/script.rpy:579
translate english yuanyangcha_security_talk_poison_drink_d4b1283b:

    # d concerned "イギリスからの重税に苦しんでいたのでしょうか？"
    d concerned "Were they suffering under heavy taxes imposed by Britain?"

# game/script.rpy:580
translate english yuanyangcha_security_talk_poison_drink_3bcb611b:

    # a "コーヒーカップはボストン港じゃねぇんだよ。"
    a "A coffee cup isn't Boston Harbor."

# game/script.rpy:581
translate english yuanyangcha_security_talk_poison_drink_6d9c2d88:

    # m normal "いずれにせよ、この事件の大きな手がかりになりそうですね"
    m normal "In any case, this looks like it could be a major clue in the case."

# game/script.rpy:598
translate english yuanyangcha_security_talk_coffee_kind_6c8cdcbf:

    # d normal "匂いの成分から、毒を入れたコーヒーの種類を絞り込めるのではありませんか？"
    d normal "Couldn't we narrow down the type of coffee that was poisoned based on its aroma compounds?"

# game/script.rpy:600
translate english yuanyangcha_security_talk_coffee_kind_e1c49c69:

    # coffee "なるほど。\n捜査資料の共有フォルダにアクセスしますね。"
    coffee "I see.\nI'll access the shared folder containing the investigation materials."

# game/script.rpy:601
translate english yuanyangcha_security_talk_coffee_kind_b36dc5b9:

    # coffee "マグカップに残された飲み物の匂い成分を鑑識が解析した結果がありますね"
    coffee "Here are the results of the forensic analysis of the aroma compounds in the drink left in the mug."

# game/script.rpy:602
translate english yuanyangcha_security_talk_coffee_kind_8f45511c:

    # coffee "紅茶については『【躑躅|つつじ】 【椿|つばき】の水筒の中のアールグレイと同じ』という照合がされていますが、コーヒーについては手つかずです。"
    coffee "The tea has been matched as being the same as the Earl Grey in Tsubaki Tsutsuji's thermos, but the coffee has not been analyzed yet."

# game/script.rpy:603
translate english yuanyangcha_security_talk_coffee_kind_9cfd396b:

    # coffee "以前趣味で調べたのですが、{color=[gui.keyword_color]}アラビカ種{/color}はグリーンな香調の成分とキャッティーな香調の成分が多く、{color=[gui.keyword_color]}ロブスタ種{/color}はナッティーな香調の成分とスモーキーな香調の成分が多いそうです"
    coffee "I once researched this as a hobby, and apparently {color=[gui.keyword_color]}Arabica{/color} contains more compounds with green and catty aromas, while {color=[gui.keyword_color]}Robusta{/color} contains more compounds with nutty and smoky aromas."

# game/script.rpy:604
translate english yuanyangcha_security_talk_coffee_kind_930683b7:

    # coffee "せめて{color=[gui.keyword_color]}アラビカ種{/color}と{color=[gui.keyword_color]}ロブスタ種{/color}の比率だけでもわかると嬉しいのですが……。"
    coffee "It would be helpful if we could at least determine the ratio of {color=[gui.keyword_color]}Arabica{/color} to {color=[gui.keyword_color]}Robusta{/color}..."

# game/script.rpy:605
translate english yuanyangcha_security_talk_coffee_kind_a31f89d6:

    # d desired "{color=[gui.keyword_color]}アラビカ種{/color}の「キャッティー」な香りというのは、「ネコ」みたいな香りということでしょうか？\nボクは「タチ」も「ネコ」もイケますが。"
    d desired "Does the {color=[gui.keyword_color]}Arabica{/color}'s \"catty\" aroma mean that it smells like a cat?\nI'm into both \"tachi\" and \"neko,\" though."

# game/script.rpy:607
translate english yuanyangcha_security_talk_coffee_kind_ffa4d026:

    # a "お前の夜のポジションは聞いてねぇよ。"
    a "I didn't ask about your position in bed."

# game/script.rpy:608
translate english yuanyangcha_security_talk_coffee_kind_e41d1091:

    # coffee "出ました。\nナッティーな香調の成分とスモーキーな香調の成分が圧倒的に多いです。"
    coffee "There it is.\nThere are overwhelmingly more compounds with nutty and smoky aromas."

# game/script.rpy:609
translate english yuanyangcha_security_talk_coffee_kind_0862d867:

    # coffee "これだけ{color=[gui.keyword_color]}ロブスタ種{/color}の比率が高いコーヒーは日本では珍しいですね。"
    coffee "Coffee with such a high proportion of {color=[gui.keyword_color]}Robusta{/color} is quite rare in Japan."

# game/script.rpy:610
translate english yuanyangcha_security_talk_coffee_kind_f756f6f7:

    # m normal "事件解決に大きく近づきましたね"
    m normal "We've gotten much closer to solving the case."

# game/script.rpy:624
translate english yuanyangcha_security_talk_coffee_hairpin_7c9b6a7f:

    # d normal "【竜胆|りんどう】 【茜|あかね】さんはいつも特徴的なかんざしを着けていますね。"
    d normal "【竜胆|りんどう】 【茜|あかね】 always wears such a distinctive hairpin."

# game/script.rpy:626
translate english yuanyangcha_security_talk_coffee_hairpin_f2c10177:

    # coffee "「珈琲」という当て字は、コーヒーノキにたわわに実る赤い小さい実を、玉飾りのついた花かんざしに見立てたものなんです。"
    coffee "The ateji \"珈琲\" was inspired by the small, abundant red berries of the coffee plant, which were likened to ornamental flower hairpins with beaded decorations."

# game/script.rpy:627
translate english yuanyangcha_security_talk_coffee_hairpin_c325d13d:

    # coffee "それを知った【椿|つばき】は、私がコーヒーを飲めないときも頑張れるように、このかんざしをプレゼントしてくれました。"
    coffee "After learning that, Tsubaki gave me this hairpin so that I could keep going even when I couldn't drink coffee."

# game/script.rpy:628
translate english yuanyangcha_security_talk_coffee_hairpin_a554a199:

    # coffee "私の大事な宝物です。"
    coffee "It is my precious treasure."

# game/script.rpy:629
translate english yuanyangcha_security_talk_coffee_hairpin_3083718f:

    # d desired "ボクは「たわわ」な胸も「たおやか」な胸も好きです。"
    d desired "I like both \"full\" breasts and \"graceful\" breasts."

# game/script.rpy:631
translate english yuanyangcha_security_talk_coffee_hairpin_9531cbbb:

    # a "割って入ろうとすんな。"
    a "Don't interrupt."

# game/script.rpy:632
translate english yuanyangcha_security_talk_coffee_hairpin_b10ad745:

    # m normal "【竜胆|りんどう】 【茜|あかね】さんのためにも、この事件を解決しないといけませんね"
    m normal "For Akane Rindo's sake, we have to solve this case."

# game/script.rpy:659
translate english yuanyangcha_tea_encounter_faa77b51:

    # tp "同日 12:10\n桜月大学 給湯室"
    tp "Same day, 12:10\nSakurazuki University kitchenette"

# game/script.rpy:661
translate english yuanyangcha_tea_encounter_812f4cf7:

    # "警備員室を出ると、黒いセーラー服風の女性が給湯室の前で待ち構えていた。"
    "When we left the security office, a woman dressed in a black sailor-style uniform was waiting for us in front of the kitchenette."

# game/script.rpy:664
translate english yuanyangcha_tea_encounter_587701ed:

    # tea smug "私は【躑躅|つつじ】 【椿|つばき】。\nそして、君たちは私に用があるのだろう。"
    tea smug "I am Tsubaki Tsutsuji.\nAnd I presume you have business with me."

# game/script.rpy:665
translate english yuanyangcha_tea_encounter_9f8928df:

    # tea smug "給湯室で優雅なティータイムを過ごしていたら、【茜|あかね】君の声がしてね。"
    tea smug "I was enjoying an elegant tea time in the kitchenette when I heard Akane calling out."

# game/script.rpy:666
translate english yuanyangcha_tea_encounter_c9152bf6:

    # tea smug "しかし、私のルームメイトである【茜|あかね】君は本来ここにいてはならない。"
    tea smug "However, my roommate, Akane Rindo, should not normally be here."

# game/script.rpy:667
translate english yuanyangcha_tea_encounter_12776817:

    # tea smug "つまり、君たちは警察関係者で、教授が死亡した事件の調査を【茜|あかね】君に依頼された。\nそうだろう？"
    tea smug "In other words, you are connected to the police, and Akane asked you to investigate the case involving the professor's death.\nAm I right?"

# game/script.rpy:668
translate english yuanyangcha_tea_encounter_882c6b4b:

    # m normal "【竜胆|りんどう】 【茜|あかね】さん、個性的な方と同棲されているのですね"
    m normal "Akane Rindo, you live with quite an eccentric person."

# game/script.rpy:693
translate english yuanyangcha_kitchenette_research_shelf_8cf1b4fd:

    # "給湯室の流し台の下に、大きな棚がある。"
    "There is a large cabinet under the sink in the kitchenette."

# game/script.rpy:694
translate english yuanyangcha_kitchenette_research_shelf_14a78776:

    # "扉は木製で、外から中を見ることはできない。"
    "The door is made of wood, so you cannot see inside from outside."

# game/script.rpy:695
translate english yuanyangcha_kitchenette_research_shelf_3847f70b:

    # "開けてみると、中身は少なく、仕切りがないため、人が隠れられそうだ。"
    "When you open it, there isn't much inside, and since there are no partitions, it looks like a person could hide inside."

# game/script.rpy:696
translate english yuanyangcha_kitchenette_research_shelf_efb57a7b:

    # d normal "ニコル、このなかに入っていただいてもよろしいですか？"
    d normal "Nicole, would you mind getting inside this?"

# game/script.rpy:698
translate english yuanyangcha_kitchenette_research_shelf_c8f52cf4:

    # a "はぁ？\n小柄なお前のほうがお似合いだろ。"
    a "Huh?\nIt would suit you better since you're smaller."

# game/script.rpy:699
translate english yuanyangcha_kitchenette_research_shelf_f36fa380:

    # d normal "ボクが入れたとしても、ボクより大柄な容疑者が入れるかどうかはわからないでしょう？"
    d normal "Even if I can fit inside, we won't know whether a suspect larger than me could fit, would we?"

# game/script.rpy:700
translate english yuanyangcha_kitchenette_research_shelf_6ab8efb3:

    # d normal "それを確認するためには、ニコルにも入っていただく必要があります。"
    d normal "To confirm that, Nicole needs to get inside as well."

# game/script.rpy:701
translate english yuanyangcha_kitchenette_research_shelf_7c2ec4ca:

    # d normal "そして、ニコルが入れたら、ボクは入る必要がない。"
    d normal "And if Nicole can fit, I don't need to get inside."

# game/script.rpy:702
translate english yuanyangcha_kitchenette_research_shelf_56452c5a:

    # d normal "効率の問題ですよ。"
    d normal "It's simply a matter of efficiency."

# game/script.rpy:703
translate english yuanyangcha_kitchenette_research_shelf_ed7d373f:

    # a "しゃあねぇな。"
    a "Fine."

# game/script.rpy:704
translate english yuanyangcha_kitchenette_research_shelf_97ef3ee4:

    # m normal "もしもニコルが入れなかったらボクも入る必要がありますが、黙っておきましょう"
    m normal "If Nicole can't fit, I'll have to get inside too, but let's keep that to ourselves."

# game/script.rpy:705
translate english yuanyangcha_kitchenette_research_shelf_74daacdd:

    # a "かなり狭いが、入れなくはねぇな。"
    a "It's pretty cramped, but I can fit."

# game/script.rpy:706
translate english yuanyangcha_kitchenette_research_shelf_f70b4d8f:

    # m desired "シャッターチャンスです！"
    m desired "Photo opportunity!"

# game/script.rpy:707
translate english yuanyangcha_kitchenette_research_shelf_22aef04c:

    # "フラッシュを焚きながら激写した。"
    "I took a series of photos with the flash on."

# game/script.rpy:708
translate english yuanyangcha_kitchenette_research_shelf_1e25e6f9:

    # a "おい、やめろ！\n消せ！"
    a "Hey, stop!\nDelete them!"

# game/script.rpy:709
translate english yuanyangcha_kitchenette_research_shelf_cd5b14a5:

    # d normal "貴重な証拠ですからね。\n削除できかねます。"
    d normal "It's valuable evidence.\nI'm afraid I can't delete it."

# game/script.rpy:710
translate english yuanyangcha_kitchenette_research_shelf_f6967c99:

    # a "はめられた……。"
    a "I've been set up..."

# game/script.rpy:711
translate english yuanyangcha_kitchenette_research_shelf_5f41cfff:

    # m happy "あとで待ち受け画面に設定しましょう"
    m happy "Let's set it as your wallpaper later."

# game/script.rpy:725
translate english yuanyangcha_kitchenette_research_colander_microwave_800bd1d6:

    # "流し台の横には水切りかごと電子レンジがある。"
    "There is a dish rack and a microwave next to the sink."

# game/script.rpy:726
translate english yuanyangcha_kitchenette_research_colander_microwave_4b052590:

    # "水切りかごには、研究所のメンバーが使っているのであろうカップがならんでいた。"
    "The dish rack is lined with cups that presumably belong to the members of the laboratory."

# game/script.rpy:727
translate english yuanyangcha_kitchenette_research_colander_microwave_b4ef11ec:

    # "お土産であろう「I♡香港」と書かれたものや、キャンプ用品の大型タンブラーもある。"
    "There is one that says \"I♡Hong Kong,\" presumably a souvenir, as well as a large tumbler for camping."

# game/script.rpy:728
translate english yuanyangcha_kitchenette_research_colander_microwave_da42c4e2:

    # m normal "皆さん、個性的なカップを使われているのですね"
    m normal "Everyone seems to use such distinctive cups."

# game/script.rpy:757
translate english yuanyangcha_kitchenette_talk_yesterday_b1b3e1df:

    # tea smug "まずは昨日のアリバイに関心がある。\nそうだろう？"
    tea smug "First, you're interested in my alibi for yesterday.\nAm I right?"

# game/script.rpy:759
translate english yuanyangcha_kitchenette_talk_yesterday_020ce2f1:

    # a "勝手に進めてきたな。"
    a "You just went ahead without us."

# game/script.rpy:760
translate english yuanyangcha_kitchenette_talk_yesterday_e4ce62a8:

    # tea smug "昨日は9時に研究室に到着してからはずっと実験室にいたよ。\n例外は、12時の{color=[gui.keyword_color]}優雅なティータイム{/color}と、15時の{color=[gui.keyword_color]}個人面談{/color}だね。"
    tea smug "Yesterday, I was in the laboratory the entire time after arriving at 9:00.\nThe exceptions were my {color=[gui.keyword_color]}elegant tea time{/color} at 12:00 and my {color=[gui.keyword_color]}individual meeting{/color} at 15:00."

# game/script.rpy:773
translate english yuanyangcha_kitchenette_talk_teatime_30ca3f1a:

    # d normal "{color=[gui.keyword_color]}優雅なティータイム{/color}とは？"
    d normal "What do you mean by an {color=[gui.keyword_color]}elegant tea time{/color}?"

# game/script.rpy:775
translate english yuanyangcha_kitchenette_talk_teatime_3bb20d22:

    # tea smug "実験室にある{color=[gui.keyword_color]}遠心分離機{/color}を私は毎日12時に使っている。"
    tea smug "I use the {color=[gui.keyword_color]}centrifuge{/color} in the laboratory every day at 12:00."

# game/script.rpy:776
translate english yuanyangcha_kitchenette_talk_teatime_0d3d31d8:

    # tea smug "そして、あれは検体をセットしてから分離が完了するまで{color=[gui.keyword_color]}15分{/color}かかるんだよ。"
    tea smug "It takes {color=[gui.keyword_color]}15 minutes{/color} from setting the specimen until the separation is complete."

# game/script.rpy:777
translate english yuanyangcha_kitchenette_talk_teatime_5bea5039:

    # tea smug "給湯室に移動して、携帯食料と紅茶を一服し、カップを洗うにはちょうどよい時間だ。"
    tea smug "That's just enough time to go to the kitchenette, have some emergency food and tea, and wash my cup."

# game/script.rpy:778
translate english yuanyangcha_kitchenette_talk_teatime_b696fa8f:

    # tea smug "マウスは強い匂いに反応してしまうからね。\n教授が執務室を開けていないときは、水以外の飲み物は給湯室で飲む決まりになっているのさ。"
    tea smug "Mice react to strong smells, you see.\nWhen the professor's office isn't open, we're required to drink anything other than water in the kitchenette."

# game/script.rpy:779
translate english yuanyangcha_kitchenette_talk_teatime_a0938491:

    # tea smug "暗くて色はまったくわからないが、ファーストフラッシュでオレンジペコーなダージリンとベルガモット、そして牛乳の香りに集中するにはもってこいの場所さ。"
    tea smug "It's dark, so I can't make out the colors at all, but it's the perfect place to focus on the aromas of first-flush Darjeeling with orange pekoe, bergamot, and milk."

# game/script.rpy:781
translate english yuanyangcha_kitchenette_talk_teatime_7822baf8:

    # "たしかに、上質な紅茶と柑橘系の果物の香りが漂っている。"
    "Indeed, the aroma of high-quality black tea and citrus fruit fills the air."

# game/script.rpy:783
translate english yuanyangcha_kitchenette_talk_teatime_a7bfa524:

    # a "ファーストフラッシュ？　オレンジペコー？　ダージリン？　ベルガモット？"
    a "First flush? Orange pekoe? Darjeeling? Bergamot?"

# game/script.rpy:784
translate english yuanyangcha_kitchenette_talk_teatime_0381ce8a:

    # d happy "「ファーストフラッシュ」は「クオリティシーズン」、「オレンジペコー」は「等級」、「ダージリン」は「産地」、「ベルガモット」は「香料」の一種です。"
    d happy "\"First flush\" refers to the \"quality season,\" \"orange pekoe\" to a \"grade,\" \"Darjeeling\" to an \"origin,\" and \"bergamot\" to a type of \"flavoring.\""

# game/script.rpy:785
translate english yuanyangcha_kitchenette_talk_teatime_91a3f325:

    # a "呪文であることはわかったから、1つずつ説明してくれ。"
    a "I get that they sound like spells, so explain them one by one."

# game/script.rpy:786
translate english yuanyangcha_kitchenette_talk_teatime_40c84c10:

    # d normal "「クオリティシーズン」は紅茶の収穫時期の違いです。"
    d normal "\"Quality season\" refers to differences in when black tea is harvested."

# game/script.rpy:787
translate english yuanyangcha_kitchenette_talk_teatime_6bde00f7:

    # d normal "ダージリンの場合、ファーストフラッシュ（3月中旬～4月）、セカンドフラッシュ（5月～7月上旬）、オータムナル（10月～11月中旬）でそれぞれ異なる香りや味を楽しむことができますよ。"
    d normal "In the case of Darjeeling, you can enjoy different aromas and flavors from the first flush (mid-March to April), second flush (May to early July), and autumnal (October to mid-November)."

# game/script.rpy:788
translate english yuanyangcha_kitchenette_talk_teatime_65bc6103:

    # d normal "5月に摘まれた「一番茶」を「煎茶」、それ以降に摘まれた「二番茶」以降を「番茶」と呼ぶ緑茶と似ていますね。"
    d normal "It's similar to green tea, where the \"first tea\" picked in May is called \"sencha,\" while the \"second tea\" and later harvests are called \"bancha.\""

# game/script.rpy:789
translate english yuanyangcha_kitchenette_talk_teatime_ebd6668e:

    # a "茶葉は1年に何度も収穫できるから、いつ収穫したかで呼び分けているのか。"
    a "Tea leaves can be harvested several times a year, so they're named according to when they're harvested."

# game/script.rpy:790
translate english yuanyangcha_kitchenette_talk_teatime_d31b757c:

    # d normal "紅茶の「等級」は茶葉の形状と大きさです。"
    d normal "The \"grade\" of black tea refers to the shape and size of the tea leaves."

# game/script.rpy:791
translate english yuanyangcha_kitchenette_talk_teatime_cda17182:

    # d normal "紅茶の抽出時間は、大きい葉なら長く、細かい葉なら短くなるでしょう。"
    d normal "The brewing time for black tea is longer for large leaves and shorter for smaller leaves."

# game/script.rpy:792
translate english yuanyangcha_kitchenette_talk_teatime_95f40fa3:

    # d normal "製造過程で【篩|ふるい】にかけて同じ大きさの茶葉に揃えることで、抽出の時間も一定になり、バランスのよい味にしているのです。"
    d normal "By sifting the leaves during production and sorting them into uniform sizes, the brewing time can also be kept consistent, resulting in a well-balanced flavor."

# game/script.rpy:793
translate english yuanyangcha_kitchenette_talk_teatime_d1232b50:

    # a "「等級」って名前だけど、品質とは関係がないのか。"
    a "It's called a \"grade,\" but it has nothing to do with quality?"

# game/script.rpy:794
translate english yuanyangcha_kitchenette_talk_teatime_c84e676e:

    # d normal "「チャ」は「ツツジ目ツバキ科カメリア属の永年性常緑樹」のことで、飲用に使われるのは「中国種」と「アッサム種」の主に2種類しかないのです。"
    d normal "\"Tea\" refers to a perennial evergreen tree of the genus Camellia in the family Theaceae, and there are mainly only two varieties used for drinking: the \"China variety\" and the \"Assam variety.\""

# game/script.rpy:795
translate english yuanyangcha_kitchenette_talk_teatime_6a5cd7d6:

    # a "「コーヒーノキ」の「アラビカ種」と「ロブスタ種」みたいなもんか。"
    a "Like the \"Arabica\" and \"Robusta\" varieties of the coffee plant?"

# game/script.rpy:796
translate english yuanyangcha_kitchenette_talk_teatime_09dcac65:

    # d normal "それ以上の細かい茶葉の分類は産地の違いですね。"
    d normal "The more detailed classifications of tea leaves are based on differences in their regions of origin."

# game/script.rpy:797
translate english yuanyangcha_kitchenette_talk_teatime_f750d973:

    # d normal "「ダージリン」はインドの北東部の地名で、チベット語で「雷の町」を意味し、イギリス軍の避暑地として発展しました。"
    d normal "\"Darjeeling\" is a place name in northeastern India. It means \"town of thunder\" in Tibetan and developed as a summer resort for the British military."

# game/script.rpy:798
translate english yuanyangcha_kitchenette_talk_teatime_46f972c9:

    # d normal "その茶葉はフルーティな香りから「紅茶のシャンパン」と呼ばれることもありますよ。"
    d normal "Its tea leaves are sometimes called the \"champagne of black tea\" because of their fruity aroma."

# game/script.rpy:799
translate english yuanyangcha_kitchenette_talk_teatime_8776f797:

    # a "それこそ「シャンパン」も「シャンパーニュ地方のスパークリングワイン」という意味だもんな。"
    a "That's just like \"Champagne,\" which means \"sparkling wine from the Champagne region.\""

# game/script.rpy:800
translate english yuanyangcha_kitchenette_talk_teatime_677597b0:

    # d normal "ベルガモットは柑橘類の一種で、その香りをつけた紅茶はすべて「アールグレイ」と呼ばれます。"
    d normal "Bergamot is a type of citrus fruit, and all black tea flavored with its aroma is called 'Earl Grey.'"

# game/script.rpy:801
translate english yuanyangcha_kitchenette_talk_teatime_7f0c8244:

    # a "「アールグレイ」は聞いたことがあったけど、茶葉の品種や産地は関係ないのか。"
    a "I had heard of 'Earl Grey,' but does it have nothing to do with the variety or place of origin of the tea leaves?"

# game/script.rpy:802
translate english yuanyangcha_kitchenette_talk_teatime_0ccfd882:

    # d normal "19世紀にイギリス首相を務めた政治家「チャールズ・グレイ伯爵」が紹介したことが名前の由来です。"
    d normal "Its name comes from the politician 'Charles Grey, 2nd Earl Grey,' who served as Prime Minister of the United Kingdom in the 19th century."

# game/script.rpy:803
translate english yuanyangcha_kitchenette_talk_teatime_ebc0bec0:

    # d normal "「アールグレイ」のように、お茶以外のものを添加するのが「フレーバーティー」なのに対し、複数の茶葉を配合するのが「ブレンドティー」。"
    d normal "While adding something other than tea to it, as with 'Earl Grey,' makes it a 'flavored tea,' combining multiple types of tea leaves makes it a 'blended tea.'"

# game/script.rpy:804
translate english yuanyangcha_kitchenette_talk_teatime_05bb7525:

    # d normal "各社が出している「ブレックファスト」「アフタヌーンティー」も「ブレンドティー」の一種ですね。"
    d normal "The 'Breakfast' and 'Afternoon Tea' blends offered by various companies are also types of 'blended tea.'"

# game/script.rpy:805
translate english yuanyangcha_kitchenette_talk_teatime_08c6fae9:

    # tea smug "ふむ、君もなかなかの紅茶党だね。"
    tea smug "Hmm, you're quite the tea enthusiast yourself."

# game/script.rpy:806
translate english yuanyangcha_kitchenette_talk_teatime_24c3c797:

    # m normal "【躑躅|つつじ】 【椿|つばき】さんは相当の紅茶好きですね"
    m normal "You really are quite fond of black tea, aren't you, Tsubaki Tsutsuji?"

# game/script.rpy:835
translate english yuanyangcha_kitchenette_talk_cup_a1c9c0b6:

    # d normal "どのようなカップを使ってますか？"
    d normal "What kind of cup do you use?"

# game/script.rpy:837
translate english yuanyangcha_kitchenette_talk_cup_ca9a0e4b:

    # tea smug "配属当初は【茜|あかね】君からプレゼントされたマグカップを使っていたんだが、優雅なティータイムを過ごしているときに、革新的なアイディアを思いついたのさ。"
    tea smug "When I first joined the lab, I used a mug that Akane gave me as a gift, but I came up with a revolutionary idea while enjoying an elegant tea time."

# game/script.rpy:839
translate english yuanyangcha_kitchenette_talk_cup_dde1dabd:

    # d desired "「エウレカ」と叫びながら、全裸で走り回ったのですね。"
    d desired "So you ran around naked shouting 'Eureka,' then."

# game/script.rpy:840
translate english yuanyangcha_kitchenette_talk_cup_be1155fb:

    # tea smug "ふむ、アルキメデスか。"
    tea smug "Hmm, Archimedes, was it?"

# game/script.rpy:841
translate english yuanyangcha_kitchenette_talk_cup_fb194704:

    # tea smug "そこまでではないが、衝撃のあまり、マグカップを落として割ってしまってね。"
    tea smug "Not quite that dramatic, but I was so shocked that I dropped and broke the mug."

# game/script.rpy:842
translate english yuanyangcha_kitchenette_talk_cup_5690428a:

    # tea smug "替えとして{color=[gui.keyword_color]}大学生協の公式マグカップ{/color}を買って、そのままさ。"
    tea smug "I bought the {color=[gui.keyword_color]}official university co-op mug{/color} as a replacement, and I've been using it ever since."

# game/script.rpy:843
translate english yuanyangcha_kitchenette_talk_cup_2d2914ed:

    # m surprised "【竜胆|りんどう】 【茜|あかね】さんが聞いたら、ショックを受けそうそうですね。"
    m surprised "Akane Rindo would probably be shocked if she heard that."

# game/script.rpy:844
translate english yuanyangcha_kitchenette_talk_cup_beae1f08:

    # tea smug "【松風|まつかぜ】 【柚子|ゆず】教授も同じものを使っていることに後で気づいたが、水切りかごで干す位置が違うから、取り違えることはないさ。"
    tea smug "I later realized that Professor Yuzu Matsukaze uses the same one, but we dry them in different spots in the dish rack, so there's no chance of mixing them up."

# game/script.rpy:846
translate english yuanyangcha_kitchenette_talk_cup_02b1fe4b:

    # "助手がボクに耳打ちをする。"
    "My assistant whispers in my ear."

# game/script.rpy:848
translate english yuanyangcha_kitchenette_talk_cup_2e7f6205:

    # a "【躑躅|つつじ】 【椿|つばき】が12時に水切りラックに置いたマグカップが、15時に犯行に使われたんじゃないか。"
    a "Could the mug Tsubaki Tsutsuji put in the dish rack at noon have been used to commit the crime at 3 p.m.?"

# game/script.rpy:849
translate english yuanyangcha_kitchenette_talk_cup_daa23c1a:

    # m concerned "洗ったあとのマグカップに、はたして十分な量の唾液が含まれているでしょうか？"
    m concerned "Would a washed mug really contain a sufficient amount of saliva?"

# game/script.rpy:867
translate english yuanyangcha_kitchenette_talk_wash_f4effcb3:

    # d normal "昨日、マグカップに口をつけてから洗うまでの間に、なにか不自然なことはありませんでしたか？"
    d normal "Did anything unusual happen between when you drank from the mug yesterday and when you washed it?"

# game/script.rpy:869
translate english yuanyangcha_kitchenette_talk_wash_e48a9d62:

    # tea smug "それがね、飲み始めたばかりなのに、遠心分離機のタイマーが鳴ったんだよ。"
    tea smug "Well, I had only just started drinking when the centrifuge timer went off."

# game/script.rpy:870
translate english yuanyangcha_kitchenette_talk_wash_30e8ba3e:

    # tea smug "結果が気になってね。\n{color=[gui.keyword_color]}200ml{/color}ほど飲み残したマグカップを給湯室に置いて、実験室に向かったんだ。"
    tea smug "I was curious about the results.\nI left the mug with about {color=[gui.keyword_color]}200 ml{/color} of tea still in it in the kitchenette and went to the laboratory."

# game/script.rpy:871
translate english yuanyangcha_kitchenette_talk_wash_b21837d1:

    # tea smug "前に使った人がタイマーを{color=[gui.keyword_color]}5分{/color}に早めていたようでね。\n15分に戻して、給湯室に戻ったよ。"
    tea smug "It seems the person who used it before me had changed the timer to {color=[gui.keyword_color]}5 minutes{/color}.\nI changed it back to 15 minutes and returned to the kitchenette."

# game/script.rpy:873
translate english yuanyangcha_kitchenette_talk_wash_8b591dea:

    # d normal "マグカップに変化はありましたか？"
    d normal "Was there anything different about the mug?"

# game/script.rpy:874
translate english yuanyangcha_kitchenette_talk_wash_fed329a9:

    # tea smug "マグカップはそのままさ。\nただ、{color=[gui.keyword_color]}100ml{/color}ほど残っていた水筒が空になっていたね。"
    tea smug "The mug was untouched.\nHowever, the water bottle, which had about {color=[gui.keyword_color]}100 ml{/color} left in it, was empty."

# game/script.rpy:875
translate english yuanyangcha_kitchenette_talk_wash_77a1a70b:

    # m concerned "水筒の中身には【躑躅|つつじ】 【椿|つばき】さんの唾液は含まれていないはずですが……"
    m concerned "The contents of the water bottle shouldn't contain any of Tsubaki Tsutsuji's saliva, though..."

# game/script.rpy:878
translate english yuanyangcha_kitchenette_talk_wash_ab8d4605:

    # a "天使の取り分だとしたら、その天使は相当せっかちだな。"
    a "If it was the angels' share, that angel must have been awfully impatient."

# game/script.rpy:879
translate english yuanyangcha_kitchenette_talk_wash_0f477ecb:

    # d concerned "天使の取り分？"
    d concerned "The angels' share?"

# game/script.rpy:880
translate english yuanyangcha_kitchenette_talk_wash_9b875869:

    # a "酒を熟成させるときに樽を使ったことで、樽から蒸発した水分やアルコール分を「【天使の取り分|エンジェルズ・シェア】」と呼ぶんだ。"
    a "When alcohol is aged in barrels, the water and alcohol that evaporate from the barrel are called the 'Angel's Share'."

# game/script.rpy:881
translate english yuanyangcha_kitchenette_talk_wash_c92ed269:

    # a "ほかにも、樽に染み込んで取り出せなかった酒を「【悪魔の取り分|デビルズ・カット】」と呼んだりもするな。"
    a "Liquor that soaks into the barrel and can't be extracted is also called the 'Devil's Cut'."

# game/script.rpy:882
translate english yuanyangcha_kitchenette_talk_wash_233fbe90:

    # a "「デビルズカット」という、そのままの名前のお酒もあって、樽から抽出したバーボンをブレンドすることで、木材の香りをより強く楽しめる。"
    a "There's also a liquor literally called 'Devil's Cut,' which blends bourbon extracted from the barrel to give it a stronger woody aroma."

# game/script.rpy:883
translate english yuanyangcha_kitchenette_talk_wash_848af658:

    # m normal "水筒の中身は、はたしてどこに行ったのでしょうか？"
    m normal "Where could the contents of the water bottle have gone?"

# game/script.rpy:908
translate english yuanyangcha_kitchenette_talk_interview_16d81fac:

    # d normal "{color=[gui.keyword_color]}個人面談{/color}とは？"
    d normal "What is a {color=[gui.keyword_color]}one-on-one meeting{/color}?"

# game/script.rpy:910
translate english yuanyangcha_kitchenette_talk_interview_9a466db0:

    # tea smug "【松風|まつかぜ】研究室の研究員は、毎月第4火曜日に教授と個人面談をすることになっている。"
    tea smug "The researchers in the Matsukaze Lab are required to have a one-on-one meeting with the professor on the fourth Tuesday of every month."

# game/script.rpy:911
translate english yuanyangcha_kitchenette_talk_interview_a417893b:

    # tea smug "ちょうど昨日がその日だったわけさ。\n一昨日にはリマインドメールも受け取ったよ。"
    tea smug "Yesterday happened to be that day.\nI also received a reminder email the day before."

# game/script.rpy:913
translate english yuanyangcha_kitchenette_talk_interview_c42d853c:

    # d normal "そのメールを拝見してもいいですか？"
    d normal "May I see that email?"

# game/script.rpy:914
translate english yuanyangcha_kitchenette_talk_interview_70765453:

    # tea smug "もちろんだ。\n宛先を見るに、ジャシー・チェンと【菊苦菜|きくにがな】 ちこりも同じメールを受け取っている。"
    tea smug "Of course.\nJudging by the recipients, Jassy Chen and Chikori Kikugana received the same email."

# game/script.rpy:915
translate english yuanyangcha_kitchenette_talk_interview_c94f8043:

    # "【躑躅|つつじ】 【椿|つばき】にメールを転送してもらった。"
    "I had Tsubaki Tsutsuji forward the email to me."

# game/script.rpy:917
translate english yuanyangcha_kitchenette_talk_interview_2590c89b:

    # d normal "{color=[gui.machine_color]}「皆さんの論文を読み返して気づいたことがあったので、お話ししましょう。」{/color}とありますね。"
    d normal "It says, {color=[gui.machine_color]}\"I noticed something while rereading everyone's papers, so let's talk about it.\"{/color}"

# game/script.rpy:918
translate english yuanyangcha_kitchenette_talk_interview_9015dc3f:

    # tea smug "「研究指導をとおして、教育者としても学ぶところがあった」ということだと私は解釈した。"
    tea smug "I interpreted that as meaning, 'Through supervising your research, I also learned something as an educator.'"

# game/script.rpy:919
translate english yuanyangcha_kitchenette_talk_interview_da7f4389:

    # m concerned "はたして、それだけでしょうか？"
    m concerned "Was that really all there was to it?"

# game/script.rpy:920
translate english yuanyangcha_kitchenette_talk_interview_4e8d17d0:

    # tea smug "【松風|まつかぜ】 【柚子|ゆず】教授は実験結果だけでなく、個人面談の内容も自身の{color=[gui.keyword_color]}研究ノート{/color}に記録している。"
    tea smug "Professor Yuzu Matsukaze records not only experimental results but also the contents of one-on-one meetings in her {color=[gui.keyword_color]}research notebook{/color}."

# game/script.rpy:921
translate english yuanyangcha_kitchenette_talk_interview_5da6ab14:

    # tea smug "常にカバンに入れて持ち歩いていたから、執務室で調べるといい。"
    tea smug "She always carried it in her bag, so you should look for it in her office."

# game/script.rpy:922
translate english yuanyangcha_kitchenette_talk_interview_4e401837:

    # m concerned "個人面談で何が話されたか、気になりますね"
    m concerned "I'm curious about what was discussed during those one-on-one meetings."

# game/script.rpy:963
translate english yuanyangcha_chen_encounter_8c1f1019:

    # tp "同日 12:30\n桜月大学 【松風|まつかぜ】研究室 実験室"
    tp "Same day 12:30\nSakurazuki University, 【松風|まつかぜ】 Laboratory, Laboratory Room"

# game/script.rpy:965
translate english yuanyangcha_chen_encounter_fd430738:

    # "実験室の扉を開けると、動物的な臭いと科学的な臭い、小動物の鳴き声と滑車を回す音が、渾然一体となって襲ってきた。"
    "When I opened the laboratory door, the smells of animals and chemicals, the squeaks of small animals, and the sound of wheels turning all assaulted me at once."

# game/script.rpy:966
translate english yuanyangcha_chen_encounter_f30be0f3:

    # "それらの臭気と騒音の原因は、マウスの飼育ケースと薬品棚のようだ。"
    "The sources of the smells and noises appeared to be the mouse cages and the chemical shelves."

# game/script.rpy:967
translate english yuanyangcha_chen_encounter_9ced1231:

    # "黄色いジャージの女性がピペットを手にしながら、マウスに話しかけていた。"
    "A woman in a yellow tracksuit was holding a pipette and talking to the mice."

# game/script.rpy:970
translate english yuanyangcha_chen_encounter_4e5203f9:

    # chen sad "こんな日もエサやり当番なんて、かわいそうですよね、ネズ太郎"
    chen sad "Having to feed them even on a day like this is so sad, isn't it, Nezutarou?"

# game/script.rpy:971
translate english yuanyangcha_chen_encounter_3a70070f:

    # chen sad "【躑躅|つつじ】 【椿|つばき】さんも【菊苦菜|きくにがな】 ちこりさんもケロリとした顔で、薄情だと思いませんか、ネズ子"
    chen sad "Don't you think Tsubaki Tsutsuji and Chikori Kikugana are heartless, Nezuko? They both look completely unfazed."

# game/script.rpy:972
translate english yuanyangcha_chen_encounter_747e323d:

    # chen sad "研究室が解散になったら、私もあなたも路頭に迷ってしまいますね、ネズッキー"
    chen sad "If the lab gets shut down, you and I will both be left with nowhere to go, Nezukki."

# game/script.rpy:973
translate english yuanyangcha_chen_encounter_8645f9ab:

    # "これ以上放置しても愚痴を聞かされるだけなので、警察手帳を見せながら話しかける。"
    "If I left her alone any longer, I'd just have to listen to more complaints, so I approached her while showing my police badge."

# game/script.rpy:974
translate english yuanyangcha_chen_encounter_4e7b41e2:

    # d normal "少々お話をうかがってもよろしいですか？"
    d normal "May I ask you a few questions?"

# game/script.rpy:975
translate english yuanyangcha_chen_encounter_a60c49b4:

    # chen smug "アイヤ！\nお見苦しいところを見せてしまいました。\n私、ジャシー・チェンと申します。"
    chen smug "Aiya!\nI'm sorry you had to see me like that.\nMy name is Jassy Chen."

# game/script.rpy:976
translate english yuanyangcha_chen_encounter_1088ad66:

    # m normal "アクション映画俳優を彷彿とさせる服装ですね"
    m normal "Your outfit reminds me of an action movie star."

# game/script.rpy:997
translate english yuanyangcha_labo_research_centrifuge_4d965ff7:

    # "遠心分離機の横にノートパソコンがある。"
    "There is a laptop next to the centrifuge."

# game/script.rpy:999
translate english yuanyangcha_labo_research_centrifuge_157e6a6c:

    # a "パソコンに接続することで、操作のログを見られるな。"
    a "If we connect to the computer, we can view the operation logs."

# game/script.rpy:1000
translate english yuanyangcha_labo_research_centrifuge_efc05ea2:

    # a "昨日は、11時45分に「{color=[gui.keyword_color]}タイマーを5分に変更{/color}」、12時に「実行」、12時10分に「タイマーを15分に変更」「実行」だけだな。"
    a "Yesterday, there was only 'Change {color=[gui.keyword_color]}timer to 5 minutes{/color}' at 11:45, 'Run' at noon, and 'Change timer to 15 minutes' and 'Run' at 12:10."

# game/script.rpy:1001
translate english yuanyangcha_labo_research_centrifuge_58d87b6d:

    # d normal "【躑躅|つつじ】 【椿|つばき】さんの証言通りですね。"
    d normal "Just as Tsubaki Tsutsuji testified."

# game/script.rpy:1002
translate english yuanyangcha_labo_research_centrifuge_943547fc:

    # d normal "「タイマーを5分に変更」したのは誰か、わかりますか？"
    d normal "Do you know who changed the timer to five minutes?"

# game/script.rpy:1003
translate english yuanyangcha_labo_research_centrifuge_cfe01529:

    # a "ユーザー名の記録はないが、「タイマーを5分に変更」だけ操作日時を書き換えた痕跡ならあるぞ。"
    a "There's no record of the username, but there's evidence that the date and time of the 'Change timer to 5 minutes' operation was altered."

# game/script.rpy:1004
translate english yuanyangcha_labo_research_centrifuge_6a35cf3e:

    # a "誰がいつ書き換えたかはわかんねぇな。"
    a "We don't know who changed it or when."

# game/script.rpy:1005
translate english yuanyangcha_labo_research_centrifuge_a41b054f:

    # d concerned "人は誰だって、書き換えたい過去があるものです。"
    d concerned "Everyone has a past they'd like to rewrite."

# game/script.rpy:1006
translate english yuanyangcha_labo_research_centrifuge_55e22307:

    # a "お前との長い付き合いとかな。"
    a "Like my long history with you."

# game/script.rpy:1007
translate english yuanyangcha_labo_research_centrifuge_44f8ba0f:

    # d normal "なぜ書き換えたのかを考えれば、十分大きな手がかりですね。"
    d normal "If we figure out why it was changed, that's a significant clue."

# game/script.rpy:1022
translate english yuanyangcha_labo_research_chemical_a3eef21c:

    # "薬品棚は簡素で、鍵はついていなかった。"
    "The chemical shelves were simple and had no lock."

# game/script.rpy:1023
translate english yuanyangcha_labo_research_chemical_6fa97b45:

    # "犯行に使われた薬品も、ガラス戸をスライドさせるだけで手に入れることができる。"
    "The chemical used in the crime could also be obtained simply by sliding open the glass door."

# game/script.rpy:1024
translate english yuanyangcha_labo_research_chemical_6749c96e:

    # d concerned "もしかして、これらの薬品は……"
    d concerned "Could these chemicals be...?"

# game/script.rpy:1026
translate english yuanyangcha_labo_research_chemical_6dfffcd4:

    # chen "マウスの殺処分は日常茶飯事ですからね。\n研究員ならだれでも扱えますよ。"
    chen "Culling mice is an everyday occurrence here.\nAny researcher can handle them."

# game/script.rpy:1029
translate english yuanyangcha_labo_research_chemical_a54f2336:

    # a "セキュリティに穴がありすぎる……。"
    a "There are way too many holes in the security..."

# game/script.rpy:1030
translate english yuanyangcha_labo_research_chemical_73784460:

    # d desired "人間にも穴はたくさんありますからね。"
    d desired "Humans have plenty of holes too."

# game/script.rpy:1031
translate english yuanyangcha_labo_research_chemical_0ef3dddd:

    # a "お前と同じ穴の狢とは思われなくねぇな。"
    a "I don't want people thinking I'm cut from the same cloth as you."

# game/script.rpy:1032
translate english yuanyangcha_labo_research_chemical_e8883e2a:

    # m concerned "毒の入手経路から犯人を絞り込むのは難しそうですね"
    m concerned "It seems difficult to narrow down the culprit based on how they obtained the poison."

# game/script.rpy:1061
translate english yuanyangcha_labo_talk_yesterday_c61d3527:

    # d normal "昨日、教授が倒れるまでに何をなさっていましたか？"
    d normal "What were you doing yesterday before the professor collapsed?"

# game/script.rpy:1063
translate english yuanyangcha_labo_talk_yesterday_34ff2b50:

    # chen smug "昨日は9時に研究室に着いて、12時に食堂に行ったり、15時10分に教授との個人面談で執務室に行ったりした以外は、ずっと実験室にいました。"
    chen smug "Yesterday, I arrived at the lab at 9, went to the cafeteria at noon, and went to the office at 3:10 p.m. for my one-on-one meeting with the professor. Other than that, I was in the laboratory the entire time."

# game/script.rpy:1073
translate english yuanyangcha_labo_talk_drink_4df0df6d:

    # d normal "研究室ではどのような飲み物をたしなまれていますか？"
    d normal "What kind of drinks do you enjoy at the lab?"

# game/script.rpy:1075
translate english yuanyangcha_labo_talk_drink_e4840572:

    # chen smug "コーヒーには一家言ありましてね、100％{color=[gui.keyword_color]}アラビカ種{/color}の上質な豆を毎日ドリップして持ってきています。"
    chen smug "I'm rather particular about coffee. Every day, I brew and bring in high-quality beans that are 100\% {color=[gui.keyword_color]}Arabica{/color}."

# game/script.rpy:1077
translate english yuanyangcha_labo_talk_drink_d837b6bf:

    # d concerned "アラビカ種？"
    d concerned "Arabica?"

# game/script.rpy:1079
translate english yuanyangcha_labo_talk_drink_3996d966:

    # a "「コーヒーノキ」は「リンドウ目アカネ科コーヒーノキ属」の植物だが、主に栽培されているのは「{color=[gui.keyword_color]}アラビカ種{/color}」と「{color=[gui.keyword_color]}ロブスタ種{/color}」の2種類だ。"
    a "The coffee plant is a plant in the genus Coffea of the family Rubiaceae, order Gentianales, but the two main cultivated varieties are {color=[gui.keyword_color]}Arabica{/color} and {color=[gui.keyword_color]}Robusta{/color}."

# game/script.rpy:1080
translate english yuanyangcha_labo_talk_drink_e6a6ebb8:

    # a "「アラビカ種」は15世紀から数百年間「世界で唯一のコーヒー」であり、現在も世界の生産量の6割を占めている。"
    a "{color=[gui.keyword_color]}Arabica{/color} was the 'only coffee in the world' for several centuries starting in the 15th century, and it still accounts for 60\% of global production."

# game/script.rpy:1081
translate english yuanyangcha_labo_talk_drink_b21a088c:

    # a "ただし、病害虫に弱く、高地でしか栽培できず、面積当たりの収穫量も少ないという欠点がある。"
    a "However, it is vulnerable to diseases and pests, can only be grown at high elevations, and has a low yield per unit of land."

# game/script.rpy:1082
translate english yuanyangcha_labo_talk_drink_e9b4234a:

    # a "そこで、19世紀末に東南アジアでコーヒーさび病が流行したときに発見されたのが、すべての型のさび病に耐性を持つ唯一の種である「ロブスタ種」だ。"
    a "That's why, when coffee leaf rust spread through Southeast Asia in the late 19th century, the 'Robusta' variety was discovered as the only species resistant to all forms of coffee rust."

# game/script.rpy:1083
translate english yuanyangcha_labo_talk_drink_41f86ad0:

    # a "「頑強な」を意味する「ロブスタ」と名付けられたのは、高い耐病性のほかにも、低地でも栽培可能で、面積当たりの収穫量が多いからだな。"
    a "It was named 'Robusta,' meaning 'robust,' not only because of its high disease resistance, but also because it can be grown at low elevations and produces a high yield per unit of land."

# game/script.rpy:1084
translate english yuanyangcha_labo_talk_drink_7e7c3889:

    # a "ただし、酸味と香りでアラビカ種に劣り、「ロブスタ臭」と呼ばれる独特の土臭さがあるという欠点がある。"
    a "However, it is inferior to Arabica in acidity and aroma, and has the distinctive earthy smell known as 'Robusta odor.'"

# game/script.rpy:1085
translate english yuanyangcha_labo_talk_drink_5fd32386:

    # a "ちなみに、「豆」は「マメ目マメ科」の植物の種子の総称だから、「コーヒー豆」は厳密には「コーヒーノキの種子」だ。"
    a "Incidentally, 'beans' is a general term for the seeds of plants in the order Fabales and family Fabaceae, so strictly speaking, 'coffee beans' are actually 'the seeds of the coffee plant.'"

# game/script.rpy:1086
translate english yuanyangcha_labo_talk_drink_cb9217f5:

    # d surprised "「コーヒーさび病」は紅茶の歴史にも無関係ではありませんよ。"
    d surprised "Coffee leaf rust is also not unrelated to the history of black tea."

# game/script.rpy:1087
translate english yuanyangcha_labo_talk_drink_4da487a5:

    # d normal "コーヒーさび病で壊滅したスリランカのコーヒー農園を、トーマス・リプトン卿が紅茶の栽培に転用したのが「セイロンティー」と「リプトン」の始まりです。"
    d normal "Sir Thomas Lipton converted the coffee plantations in Sri Lanka that had been devastated by coffee leaf rust to tea cultivation, which marked the beginning of 'Ceylon tea' and 'Lipton.'"

# game/script.rpy:1088
translate english yuanyangcha_labo_talk_drink_0a1fb757:

    # chen smug "紅茶と言えば、たまに{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}も楽しめるように、ティーバッグも持ってますよ。"
    chen smug "Speaking of black tea, I also carry tea bags so I can occasionally enjoy some {color=[gui.keyword_color]}Yuen Yeung Cha{/color}."

# game/script.rpy:1090
translate english yuanyangcha_labo_talk_drink_42e6c73b:

    # d desired "「Tバック」？"
    d desired "A 'T-back'?"

# game/script.rpy:1091
translate english yuanyangcha_labo_talk_drink_93109ea9:

    # a "紅茶の話をしたのはお前だろ。"
    a "You're the one who was talking about tea."

# game/script.rpy:1092
translate english yuanyangcha_labo_talk_drink_2eb071ed:

    # m concerned "{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}……初めて聞くお茶ですね"
    m concerned "{color=[gui.keyword_color]}Yuen Yeung Cha{/color}... That's a tea I've never heard of before."

# game/script.rpy:1116
translate english yuanyangcha_labo_talk_yuanyangcha_f5c50628:

    # d normal "{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}とはどのような飲み物ですか？"
    d normal "What kind of drink is {color=[gui.keyword_color]}Yuen Yeung Cha{/color}?"

# game/script.rpy:1118
translate english yuanyangcha_labo_talk_yuanyangcha_52a33cf8:

    # chen smug "私の故郷の香港はかつてイギリスに占領されていたので、紅茶もコーヒーもたくさん飲みます。"
    chen smug "My hometown of Hong Kong was once occupied by Britain, so we drink plenty of both black tea and coffee."

# game/script.rpy:1119
translate english yuanyangcha_labo_talk_yuanyangcha_0b9c4fab:

    # chen smug "紅茶貿易が原因で、アメリカ独立戦争とアヘン戦争を起こしたイギリスほどではないですが。"
    chen smug "Though perhaps not quite as much as Britain, which started the American Revolution and the Opium Wars because of the tea trade."

# game/script.rpy:1120
translate english yuanyangcha_labo_talk_yuanyangcha_cbc2d68c:

    # m concerned "今のはイギリス由来のブラックジョークでしょうか"
    m concerned "Was that a British-style dark joke?"

# game/script.rpy:1121
translate english yuanyangcha_labo_talk_yuanyangcha_603eedf9:

    # chen smug "その香港で生まれたのが、紅茶とコーヒーを混ぜた{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}です。"
    chen smug "That Hong Kong is where {color=[gui.keyword_color]}Yuen Yeung Cha{/color}, a mixture of black tea and coffee, was born."

# game/script.rpy:1122
translate english yuanyangcha_labo_talk_yuanyangcha_36845dd5:

    # chen smug "「【鴛鴦|ユンヨン】」は「オシドリのオスとメス」のことです。"
    chen smug "'{color=[gui.keyword_color]}Yuenyeung{/color}' refers to a male and female mandarin duck."

# game/script.rpy:1124
translate english yuanyangcha_labo_talk_yuanyangcha_ea014a23:

    # d angry "実際のオシドリは実際は冬になるたびにパートナーを変え、【抱卵|ほうらん】も【育雛|いくすう】もメスのみが行うようですが。"
    d angry "In reality, mandarin ducks actually change partners every winter, and only the females incubate the eggs and raise the young."

# game/script.rpy:1126
translate english yuanyangcha_labo_talk_yuanyangcha_0700ccc4:

    # a "今はイメージの話をしてんだよ。"
    a "We're talking about the image it evokes right now."

# game/script.rpy:1127
translate english yuanyangcha_labo_talk_yuanyangcha_b3e914d9:

    # chen smug "中国では男女同時に使うものや、二つが一つになったものの名前に「【鴛鴦|ユンヨン】」を付けることがあります。"
    chen smug "In China, '【鴛鴦|Yuenyeung】' is sometimes added to the names of things used by men and women together, or things that combine two elements into one."

# game/script.rpy:1128
translate english yuanyangcha_labo_talk_yuanyangcha_8712d8ac:

    # chen smug "「2人用の長い枕」は「【鴛鴦枕|ユンヨンチェン】」、「男女二人での入浴」は「【鴛鴦浴|ユンヨンユー】」、"
    chen smug "A 'long pillow for two people' is called '【鴛鴦枕|Yuenyeung pillow】,' and 'bathing together as a man and woman' is called '【鴛鴦浴|Yuenyeung bath】,'"

# game/script.rpy:1129
translate english yuanyangcha_labo_talk_yuanyangcha_6642fad4:

    # chen smug "「2つに仕切られた鍋」は「【鴛鴦火鍋|ユンヨンフオグオ】」、「2色のあんかけ炒飯」は「【鴛鴦炒飯|ユンヨンチャーハン】」といった感じです。"
    chen smug "a 'pot divided into two sections' is '【鴛鴦火鍋|Yuenyeung hot pot】,' and 'two-colored fried rice with sauce' is '【鴛鴦炒飯|Yuenyeung fried rice】,' for example."

# game/script.rpy:1131
translate english yuanyangcha_labo_talk_yuanyangcha_6c7bf78b:

    # d normal "現在世界各国で使われている「茶」を意味する言葉は「チャ」か「ティー」の、いずれかに大別されます。"
    d normal "The words meaning 'tea' used around the world today can broadly be divided into either 'cha' or 'tea.'"

# game/script.rpy:1132
translate english yuanyangcha_labo_talk_yuanyangcha_8708d949:

    # d normal "もとはどちらも中国で、広東語の「チャ」と福建語の「テー」が語源ですね。"
    d normal "Both originally came from China, with Cantonese 'cha' and Fujianese 'te' being their etymological sources."

# game/script.rpy:1133
translate english yuanyangcha_labo_talk_yuanyangcha_4c2f367f:

    # d normal "広東語の「チャ」は陸路経由でユーラシア大陸の東側に広まり、福建語の「テー」はオランダと貿易していた福建の港から海路でヨーロッパに広まりました。"
    d normal "The Cantonese 'cha' spread to the eastern side of Eurasia by land, while the Fujianese 'te' spread to Europe by sea from Fujian ports that traded with the Netherlands."

# game/script.rpy:1134
translate english yuanyangcha_labo_talk_yuanyangcha_21e035ef:

    # a "「{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}」の「チャ」は広東語由来ってことか。"
    a "So the 'cha' in {color=[gui.keyword_color]}Yuen Yeung Cha{/color} comes from Cantonese."

# game/script.rpy:1135
translate english yuanyangcha_labo_talk_yuanyangcha_eb7d2331:

    # m concerned "なぜ犯人は{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}に毒を盛ったのでしょうか？"
    m concerned "Why did the culprit poison the {color=[gui.keyword_color]}Yuen Yeung Cha{/color}?"

# game/script.rpy:1150
translate english yuanyangcha_labo_talk_cup_1a73a707:

    # d surprised "故郷が香港とのことでしたが、もしかして「I♡香港」というマグカップは……"
    d surprised "You said your hometown is Hong Kong. Could it be that the 'I♡Hong Kong' mug is...?"

# game/script.rpy:1152
translate english yuanyangcha_labo_talk_cup_af42ab9d:

    # chen smug "はい、私のですよ。"
    chen smug "Yes, it's mine."

# game/script.rpy:1153
translate english yuanyangcha_labo_talk_cup_a5d4c5fd:

    # m normal "ほかの【方|かた】のカップと間違えることはなさそうですね"
    m normal "It doesn't seem likely that you would mistake it for someone else's cup."

# game/script.rpy:1183
translate english yuanyangcha_robusta_encounter_dd96e083:

    # tp "同日 13:00\n桜月大学 【松風|まつかぜ】研究室 執務室"
    tp "Same day 13:00\nSakurazuki University, Matsukaze Laboratory, Office"

# game/script.rpy:1184
translate english yuanyangcha_robusta_encounter_d8afd973:

    # "執務室の壁は本で埋まっており、質素な机の上にも積み重なっていた。"
    "The walls of the office were covered with books, which were also piled up on the plain desk."

# game/script.rpy:1185
translate english yuanyangcha_robusta_encounter_2ae4ecc9:

    # "机の横にはオフィスチェアがいくつかあり、そのうちのひとつに座っているスーツ姿の女性が、書類に目を通している。"
    "There were several office chairs beside the desk, and a woman in a suit sitting in one of them was reading through some documents."

# game/script.rpy:1186
translate english yuanyangcha_robusta_encounter_08496018:

    # "なぜ、この女性は平然としていられるのだろうか。"
    "How could this woman remain so calm?"

# game/script.rpy:1187
translate english yuanyangcha_robusta_encounter_99483955:

    # "刺激的なほど強いラベンダーの香りが充満している部屋で。"
    "In a room filled with an almost painfully strong lavender scent."

# game/script.rpy:1189
translate english yuanyangcha_robusta_encounter_748d5a16:

    # a "もはや悪臭だろ。"
    a "That's basically a foul smell."

# game/script.rpy:1192
translate english yuanyangcha_robusta_encounter_a91e25c2:

    # robusta concerned "え？\n私、臭いますか？"
    robusta concerned "Huh?\nDo I smell?"

# game/script.rpy:1193
translate english yuanyangcha_robusta_encounter_95f064fc:

    # d concerned "おそらく香水かなにかだと思われますが。"
    d concerned "I believe it's probably perfume or something similar."

# game/script.rpy:1194
translate english yuanyangcha_robusta_encounter_79c3076b:

    # "3人で調べると、横になったディフューザーからアロマオイルが漏れていたことがわかった。"
    "The three of us investigated and discovered that aroma oil had been leaking from a diffuser that had fallen on its side."

# game/script.rpy:1195
translate english yuanyangcha_robusta_encounter_b00df60c:

    # "ディフューザーをもとに戻し、アロマオイルをふき取りつつ、窓を開ける。"
    "We put the diffuser back in place, wiped up the aroma oil, and opened the window."

# game/script.rpy:1196
translate english yuanyangcha_robusta_encounter_063ba9ef:

    # robusta concerned "おそらく【松風|まつかぜ】 【柚子|ゆず】教授を搬送するときに倒れてしまったのだと思われます。"
    robusta concerned "I believe it probably fell over when Professor Yuzu Matsukaze was being carried out."

# game/script.rpy:1197
translate english yuanyangcha_robusta_encounter_a1f020fc:

    # d concerned "もしかして、{color=[gui.keyword_color]}嗅覚が不自由{/color}なお方ですか？"
    d concerned "Are you perhaps {color=[gui.keyword_color]}unable to smell{/color}?"

# game/script.rpy:1198
translate english yuanyangcha_robusta_encounter_c8a6d3da:

    # robusta concerned "ええ。\n寝不足で実験をしていたときに、劇薬を直接嗅いで以来、匂いが分からなくなってしまって……。"
    robusta concerned "Yes.\nI lost my sense of smell after directly smelling a powerful chemical while conducting an experiment when I was sleep-deprived..."

# game/script.rpy:1199
translate english yuanyangcha_robusta_encounter_62c78435:

    # d concerned "腋の下の芳醇な匂いをかげないなんて、かわいそうに。"
    d concerned "How unfortunate that you can't smell the rich aroma of someone's armpits."

# game/script.rpy:1200
translate english yuanyangcha_robusta_encounter_74551f61:

    # a "植物や飲食物でたとえろよ。"
    a "Use an example involving plants or food and drinks."

# game/script.rpy:1201
translate english yuanyangcha_robusta_encounter_58f57ce2:

    # d normal "気を取り直して、捜査に協力していただけますでしょうか？"
    d normal "Anyway, would you be willing to cooperate with our investigation?"

# game/script.rpy:1202
translate english yuanyangcha_robusta_encounter_0856aa02:

    # robusta speak "ええ。\n【菊苦菜|きくにがな】 ちこりと申します。"
    robusta speak "Yes.\nMy name is Chikori Kikugana."

# game/script.rpy:1203
translate english yuanyangcha_robusta_encounter_0ed4899c:

    # m normal "几帳面そうな方ですね"
    m normal "She seems like a very meticulous person."

# game/script.rpy:1232
translate english yuanyangcha_office_research_paper_tea_07419f7f:

    # "【躑躅|つつじ】 【椿|つばき】の最新の論文を取り出した。"
    "I took out Tsubaki Tsutsuji's latest paper."

# game/script.rpy:1233
translate english yuanyangcha_office_research_paper_tea_1248752a:

    # "タイトルは「GABAの疲労回復効果」。"
    "The title is 'The Effects of GABA on Fatigue Recovery.'"

# game/script.rpy:1234
translate english yuanyangcha_office_research_paper_tea_bf26352e:

    # "【松風|まつかぜ】 【柚子|ゆず】教授との共著論文だ。"
    "It is a co-authored paper with Professor Yuzu Matsukaze."

# game/script.rpy:1235
translate english yuanyangcha_office_research_paper_tea_f28f3c09:

    # "しかしながら、謝辞を見ると【躑躅|つつじ】 【椿|つばき】が着想から作業まですべてこなしたようだ"
    "However, judging from the acknowledgments, it seems Tsubaki Tsutsuji handled everything from the initial idea to the actual work."

# game/script.rpy:1236
translate english yuanyangcha_office_research_paper_tea_f73ff142:

    # d concerned "この貢献度なら単著でもおかしくなさそうですが。"
    d concerned "With that level of contribution, it wouldn't seem strange for it to be a sole-authored paper."

# game/script.rpy:1238
translate english yuanyangcha_office_research_paper_tea_90d73ad7:

    # a "業界ごとに慣習が違ったりするから、断言できねぇな。"
    a "Customs differ between fields, so we can't say for sure."

# game/script.rpy:1251
translate english yuanyangcha_office_research_paper_chen_0ddc2221:

    # "ジャシー・チェンの最新の論文を取り出した。"
    "I took out Jassy Chen's latest paper."

# game/script.rpy:1252
translate english yuanyangcha_office_research_paper_chen_a86be0ad:

    # "タイトルは「漢方の疲労回復効果」。"
    "The title is 'The Effects of Traditional Chinese Medicine on Fatigue Recovery.'"

# game/script.rpy:1253
translate english yuanyangcha_office_research_paper_chen_73cd8e6f:

    # "謝辞には複数の助成金が名を連ねている。"
    "Several grants are listed in the acknowledgments."

# game/script.rpy:1255
translate english yuanyangcha_office_research_paper_chen_17cbf2cf:

    # a "論文名で検索してみたが、謝辞にない助成金もヒットするぞ。"
    a "I searched for the paper by its title, and some grants not listed in the acknowledgments came up too."

# game/script.rpy:1256
translate english yuanyangcha_office_research_paper_chen_682d9275:

    # d concerned "ジャシー・チェンさんの知らない助成金も、【松風|まつかぜ】 【柚子|ゆず】教授が受け取っていたのでしょうか。"
    d concerned "Could Professor Yuzu Matsukaze have received grants that Jassy Chen didn't know about?"

# game/script.rpy:1269
translate english yuanyangcha_office_research_paper_robusta_116915d3:

    # "【菊苦菜|きくにがな】 ちこりの最新の論文を取り出した。"
    "I took out Chikori Kikugana's latest paper."

# game/script.rpy:1270
translate english yuanyangcha_office_research_paper_robusta_ae8b290f:

    # "タイトルは「代用コーヒーの疲労回復効果」。"
    "The title is 'The Effects of Coffee Substitutes on Fatigue Recovery.'"

# game/script.rpy:1272
translate english yuanyangcha_office_research_paper_robusta_201f3a91:

    # a "専門外だが、形式的にはおかしなところはねぇな。"
    a "It's outside my field, but there doesn't seem to be anything formally wrong with it."

# game/script.rpy:1273
translate english yuanyangcha_office_research_paper_robusta_f42bc7b3:

    # m concerned "たしかにおかしくない……むしろ、おかしくなさすぎる……"
    m concerned "It certainly isn't strange... If anything, it's too normal..."

# game/script.rpy:1274
translate english yuanyangcha_office_research_paper_robusta_5bb2a124:

    # d normal "数値の1番最初の数字、1から9までどれも出現頻度が約11％な気がしませんか？"
    d normal "Don't you find it strange that the first digit of the numbers, from 1 through 9, each seems to occur about 11\% of the time?"

# game/script.rpy:1275
translate english yuanyangcha_office_research_paper_robusta_b4d7b242:

    # a "そりゃ100％を9で割ったら約11％だろ。"
    a "Of course. Divide 100\% by nine and you get about 11\%."

# game/script.rpy:1276
translate english yuanyangcha_office_research_paper_robusta_1190a83e:

    # d normal "「{color=[gui.keyword_color]}ベンフォードの法則{/color}」では、数値の1番最初の数字が「1」である確率は約30％、「9」である確率は約5％ですよ。"
    d normal "According to {color=[gui.keyword_color]}Benford's Law{/color}, the probability that the first digit of a number is '1' is about 30\%, while the probability that it is '9' is about 5\%."

# game/script.rpy:1277
translate english yuanyangcha_office_research_paper_robusta_3cbb3a31:

    # a "「2.0」は「1.0」の2倍だけど、「9.0」は「8.0」の1.125倍みたいなもんか。"
    a "So 2.0 is twice 1.0, but 9.0 is only 1.125 times 8.0."

# game/script.rpy:1278
translate english yuanyangcha_office_research_paper_robusta_8fcce6cd:

    # d normal "「ベンフォードの法則」は2番目以降の数字でも適用できますから、さらに詳細な解析をお願いします。"
    d normal "Benford's Law can also be applied to the second digit and beyond, so please perform a more detailed analysis."

# game/script.rpy:1279
translate english yuanyangcha_office_research_paper_robusta_83e2b758:

    # a "しゃーねぇな。"
    a "Fine, whatever."

# game/script.rpy:1292
translate english yuanyangcha_office_research_professor_note_7814f314:

    # "【松風|まつかぜ】 【柚子|ゆず】教授のカバンの中身を確認したが、研究ノートは見つけられなかった。"
    "I checked the contents of Professor Yuzu Matsukaze's bag, but couldn't find the research notebook."

# game/script.rpy:1293
translate english yuanyangcha_office_research_professor_note_fbaabfe8:

    # "執務室をくまなく調べたが、状況は変わらない。"
    "I searched the office thoroughly, but the situation remained unchanged."

# game/script.rpy:1295
translate english yuanyangcha_office_research_professor_note_bb6cff6f:

    # a "研究ノートの中身、気になりすぎるな。"
    a "I'm way too curious about what's in that research notebook."

# game/script.rpy:1296
translate english yuanyangcha_office_research_professor_note_f5a731a7:

    # d normal "個人面談の内容を知られないよう、犯人が隠したのかもしれません。"
    d normal "The culprit may have hidden it to prevent anyone from learning what was discussed during the one-on-one meetings."

# game/script.rpy:1297
translate english yuanyangcha_office_research_professor_note_c090d51f:

    # a "なら、容疑者の持ち物を検査すれば……"
    a "Then we could search the suspects' belongings..."

# game/script.rpy:1298
translate english yuanyangcha_office_research_professor_note_b2e808b6:

    # d concerned "昨日の17時以降に盗み出し、自宅などに持ち帰った可能性が高いですし、それだけで家宅捜索の令状を発行するのは難しいですね。"
    d concerned "It's highly likely that it was stolen after 5 p.m. yesterday and taken home or somewhere else, but that alone wouldn't be enough to obtain a search warrant."

# game/script.rpy:1299
translate english yuanyangcha_office_research_professor_note_2e3bb5ae:

    # m normal "個人面談は犯人にとって何を意味したのでしょうか？"
    m normal "What did the one-on-one meeting mean to the culprit?"

# game/script.rpy:1326
translate english yuanyangcha_office_talk_yesterday_704308cf:

    # d normal "昨日、教授が倒れるまでに何をなさっていたか、教えてくださいますか？"
    d normal "Could you tell me what you were doing yesterday before the professor collapsed?"

# game/script.rpy:1328
translate english yuanyangcha_office_talk_yesterday_59dea443:

    # robusta speak "昨日は8時に実験室に到着し、11時30分から12時30分までは食堂、15時20分から15時30分までは執務室で教授と個人面談をしていました。"
    robusta speak "Yesterday, I arrived at the laboratory at 8, was in the cafeteria from 11:30 to 12:30, and had a one-on-one meeting with the professor in the office from 3:20 to 3:30 p.m."

# game/script.rpy:1329
translate english yuanyangcha_office_talk_yesterday_a33dd805:

    # d surprised "朝、お早いのですね。"
    d surprised "You arrive quite early in the morning."

# game/script.rpy:1330
translate english yuanyangcha_office_talk_yesterday_039eced6:

    # robusta speak "ええ。\n私は他のかたと違って天才ではありませんから、せめて稼働時間を増やすことで貢献できればと思いまして。"
    robusta speak "Yes.\nUnlike the others, I'm not a genius, so I thought I could at least contribute by increasing the amount of time I work."

# game/script.rpy:1345
translate english yuanyangcha_office_talk_drink_4df0df6d:

    # d normal "研究室ではどのような飲み物をたしなまれていますか？"
    d normal "What kind of drinks do you enjoy at the lab?"

# game/script.rpy:1347
translate english yuanyangcha_office_talk_drink_76a88c2b:

    # robusta speak "研究は眠気との戦いですからね。\nコーヒーを多めに淹れて持ってきています。"
    robusta speak "Research is a battle against sleepiness.\nI brew a lot of coffee and bring it with me."

# game/script.rpy:1349
translate english yuanyangcha_office_talk_drink_96053bd5:

    # a "毎日午前1時に起きて、コーヒーを50杯飲み、執筆と社交に励んだ小説家、オノレ・ド・バルザックみたいなもんか。"
    a "Like the novelist Honoré de Balzac, who woke up at 1 a.m. every day, drank 50 cups of coffee, and devoted himself to writing and socializing."

# game/script.rpy:1350
translate english yuanyangcha_office_talk_drink_d5561877:

    # robusta concerned "よくわかりませんが、褒め言葉として受け取っておきます。"
    robusta concerned "I don't really understand, but I'll take that as a compliment."

# game/script.rpy:1351
translate english yuanyangcha_office_talk_drink_c58fb726:

    # d normal "どのようなコーヒーか、詳細を教えていただいてよろしいですか？"
    d normal "Could you tell me more about what kind of coffee it is?"

# game/script.rpy:1352
translate english yuanyangcha_office_talk_drink_f5853d96:

    # robusta concerned "あまり詳しくないもので。\n現物ならこちらですが。"
    robusta concerned "I'm not very knowledgeable about it.\nBut I have the actual coffee right here."

# game/script.rpy:1353
translate english yuanyangcha_office_talk_drink_26e706bf:

    # "【菊苦菜|きくにがな】 ちこりが差し出した大型の水筒を助手が受け取り、黒々とした中身の匂いをかいだ。"
    "My assistant took the large water bottle that Chikori Kikugana held out and smelled its dark contents."

# game/script.rpy:1354
translate english yuanyangcha_office_talk_drink_2ae9afec:

    # a "……もしかして原材料名に「100％ベトナム産」とか書いてなかったか？"
    a "...Wasn't there something like '100\% Made in Vietnam' written in the ingredients section?"

# game/script.rpy:1355
translate english yuanyangcha_office_talk_drink_c77d9828:

    # robusta speak "ええ、そうだった気がします。"
    robusta speak "Yes, I think there was."

# game/script.rpy:1357
translate english yuanyangcha_office_talk_drink_02b1fe4b:

    # "助手がボクに耳打ちをする。"
    "My assistant whispers in my ear."

# game/script.rpy:1358
translate english yuanyangcha_office_talk_drink_9cc8ca55:

    # a "ブラジルに次ぐコーヒーの産地であるベトナムで栽培されているのは、高温多湿でも育てられる{color=[gui.keyword_color]}ロブスタ種{/color}だ。"
    a "The coffee grown in Vietnam, the world's second-largest coffee-producing country after Brazil, is {color=[gui.keyword_color]}Robusta{/color}, which can grow in hot and humid conditions."

# game/script.rpy:1359
translate english yuanyangcha_office_talk_drink_b8ffdd90:

    # a "ただ、{color=[gui.keyword_color]}ロブスタ種{/color}は臭みが強いから、現地では練乳を入れて飲むことが多く、そのような飲み方を「ベトナムコーヒー」と呼んだりする。"
    a "However, {color=[gui.keyword_color]}Robusta{/color} has a strong, unpleasant smell, so it is often consumed locally with condensed milk. This style of preparation is sometimes called 'Vietnamese coffee.'"

# game/script.rpy:1360
translate english yuanyangcha_office_talk_drink_15ebb302:

    # a "100％{color=[gui.keyword_color]}ロブスタ種{/color}をブラックで飲む人間を初めて見たぜ。"
    a "I've never seen anyone drink 100\% {color=[gui.keyword_color]}Robusta{/color} black before."

# game/script.rpy:1361
translate english yuanyangcha_office_talk_drink_b39e357f:

    # d surprised "【菊苦菜|きくにがな】 ちこりさんだからこそできる芸当ですね。"
    d surprised "That's quite a feat, one that only someone like Chikori Kikugana could pull off."

# game/script.rpy:1378
translate english yuanyangcha_office_talk_cup_61ffbc61:

    # "ちなみに、どのようなカップを使ってますか？"
    "By the way, what kind of cup do you use?"

# game/script.rpy:1380
translate english yuanyangcha_office_talk_cup_67764060:

    # robusta speak "実用性の観点から、キャンプ用品の大型タンブラーを使っています。" 
    robusta speak "For practical reasons, I use a large tumbler designed for camping gear." 
 
# game/script.rpy:1381 
translate english yuanyangcha_office_talk_cup_35a2127b: 
 
    # m normal "こちらも、ほかの【方|かた】のカップと間違えることはなさそうですね" 
    m normal "It doesn't seem likely that this one will be mistaken for someone else's cup either." 
 
# game/script.rpy:1448 
translate english yuanyangcha_deduction_dba78636: 
 
    # tp "同日 13:30\n桜月大学 【松風|まつかぜ】研究室 廊下" 
    tp "Same day, 13:30\nSakurazuki University, 【Matsukaze|Matsukaze】 Laboratory, Hallway" 
 
# game/script.rpy:1449 
translate english yuanyangcha_deduction_cd30cb26: 
 
    # "ひととおり捜査を終えて廊下に出ると、2人の刑事と鉢合わせた。" 
    "After finishing our investigation and stepping into the hallway, we ran into two detectives." 
 
# game/script.rpy:1454 
translate english yuanyangcha_deduction_0b80f92d: 
 
    # "同じ警視庁捜査一課の【毛利|もうり】 【森子|もりこ】と【町矢|まちや】 【抹茶|まっちゃ】だ。" 
    "They were Moriko Mori and Matcha Machiya, both from the Tokyo Metropolitan Police Department's First Investigative Division." 
 
# game/script.rpy:1455 
translate english yuanyangcha_deduction_8d596894: 
 
    # gal "あーしのヤマで抜け駆けしようとは、いい根性してんじゃねーの。" 
    gal "Trying to get ahead of me on my case? You've got some nerve." 
 
# game/script.rpy:1456 
translate english yuanyangcha_deduction_a66906be: 
 
    # matcha "お二方は本当に現場がお好きなんですね。\n警視庁ではなく所轄のほうがお似合いですわ。" 
    matcha "You two really do love working at crime scenes, don't you?\nYou'd be better suited to a local police station than the Metropolitan Police Department." 
 
# game/script.rpy:1459 
translate english yuanyangcha_deduction_14661c77: 
 
    # "2人の背後の警備室では【竜胆|りんどう】 【茜|あかね】がカウンターの後ろに身を隠しながら、こちらの様子をうかがっている。" 
    "In the security office behind the two of them, Akane Rindo was hiding behind the counter and watching us." 
 
# game/script.rpy:1460 
translate english yuanyangcha_deduction_71738735: 
 
    # m concerned "【竜胆|りんどう】 【茜|あかね】さんが撤退するまで、時間を稼がなくては……" 
    m concerned "We need to buy some time until Akane Rindo can get away..." 
 
# game/script.rpy:1464 
translate english yuanyangcha_deduction_4596b13e: 
 
    # d normal "このような場所で立ち話すると館内に響きますから、執務室に移動しませんか？\n合わせて、関係者も集めましょう。" 
    d normal "If we discuss this standing here, our voices will carry throughout the building. Why don't we move to the office?\nLet's gather the relevant people as well." 
 
# game/script.rpy:1465 
translate english yuanyangcha_deduction_bda2ea0a: 
 
    # matcha "それもそうですわね。" 
    matcha "That's true." 
 
# game/script.rpy:1468 
translate english yuanyangcha_deduction_81a06038: 
 
    # "【竜胆|りんどう】 【茜|あかね】にこっそり目くばせすると、こちらの意図を察してくれたようだ。" 
    "I secretly caught Akane Rindo's eye, and she seemed to understand what I was trying to do." 
 
# game/script.rpy:1469 
translate english yuanyangcha_deduction_70e8f93c: 
 
    # m normal "【竜胆|りんどう】 【茜|あかね】さんが2人に見つかったら、ボクたちも始末書を書くはめになりますからね" 
    m normal "If Akane Rindo gets caught by those two, we'll end up having to write incident reports too." 
 
# game/script.rpy:1489 
translate english yuanyangcha_deduction_introduction_2c071263: 
 
    # tp "同日 13:40\n桜月大学 【松風|まつかぜ】研究室 執務室" 
    tp "Same day, 13:40\nSakurazuki University, 【Matsukaze|Matsukaze】 Laboratory, Office" 
 
# game/script.rpy:1490 
translate english yuanyangcha_deduction_introduction_a5980d5c: 
 
    # "執務室は、ボクとニコル、3人の容疑者、2人の同僚で、すし詰めになっていた。" 
    "The office was packed with me, Nicole, the three suspects, and two colleagues." 
 
# game/script.rpy:1491 
translate english yuanyangcha_deduction_introduction_8b2fe0e9: 
 
    # "幸い、ラベンダーの香りはかなり薄らいでいる。" 
    "Fortunately, the smell of lavender had faded considerably." 
 
# game/script.rpy:1492 
translate english yuanyangcha_deduction_introduction_3c7f3bc6: 
 
    # d normal "このたびはお集まりいただきありがとうございます。" 
    d normal "Thank you all for gathering here." 
 
# game/script.rpy:1493 
translate english yuanyangcha_deduction_introduction_dac1aecb: 
 
    # d normal "今から【松風|まつかぜ】 【柚子|ゆず】教授毒殺事件の犯人を論証しますので、しばしのご傾聴をお願いします。" 
    d normal "I will now demonstrate who was responsible for the poisoning of Professor Yuzu Matsukaze, so I ask that you listen carefully for a while." 
 
# game/script.rpy:1496 
translate english yuanyangcha_deduction_introduction_507c50b5: 
 
    # gal "は？\n今来たとこなんだけど！" 
    gal "Huh?\nWe just got here!" 
 
# game/script.rpy:1498 
translate english yuanyangcha_deduction_introduction_45473f9e: 
 
    # matcha "どのような世迷言を聞かせていただけるか、楽しみですわ。" 
    matcha "I look forward to hearing what sort of nonsense you have to tell us." 
 
# game/script.rpy:1500 
translate english yuanyangcha_deduction_introduction_f34d8c26: 
 
    # d normal "まずは事件の概要を整理しましょう。" 
    d normal "First, let's review the outline of the case." 
 
# game/script.rpy:1501 
translate english yuanyangcha_deduction_introduction_4418ebea: 
 
    # d normal "服薬推定時刻に【松風|まつかぜ】 【柚子|ゆず】教授と会った人物は【躑躅|つつじ】 【椿|つばき】、ジャシー・チェン、【菊苦菜|きくにがな】 ちこりの3名。" 
    d normal "The three people who met Professor Yuzu Matsukaze around the estimated time of ingestion were Tsubaki Tsutsuji, Jassie Chen, and Chicory Kikunigana." 
 
# game/script.rpy:1502 
translate english yuanyangcha_deduction_introduction_e3f4a8ec: 
 
    # d normal "また、【松風|まつかぜ】 【柚子|ゆず】教授の指紋と唾液、そして毒が検出されたカップからは、【躑躅|つつじ】 【椿|つばき】の指紋と唾液も検出されました。" 
    d normal "In addition, fingerprints and saliva belonging to Tsubaki Tsutsuji were detected alongside Professor Yuzu Matsukaze's fingerprints and saliva on the cup in which the poison was detected." 
 
# game/script.rpy:1504 
translate english yuanyangcha_deduction_introduction_8e375c26: 
 
    # tea "ほう、それは不可解だね。" 
    tea "Oh, that is puzzling." 
 
# game/script.rpy:1505 
translate english yuanyangcha_deduction_introduction_d6c88f03: 
 
    # d normal "「1つのカップから、2名の指紋だけでなく、唾液も検出される」という一見不可解な状況ですが、この事件ではそこまで不自然ではありません。" 
    d normal "At first glance, it seems strange that both the fingerprints and saliva of two people were detected on a single cup, but in this case, it isn't actually that unusual." 
 
# game/script.rpy:1510 
translate english yuanyangcha_deduction_professor_cup_8eadccb9: 
 
    # d normal "【躑躅|つつじ】 【椿|つばき】の飲み残しのカップさえあれば、それに毒を入れて、【松風|まつかぜ】 【柚子|ゆず】教授に飲ませることは容易でした。\nなぜなら……" 
    d normal "If you had Tsubaki Tsutsuji's cup with some drink left in it, it would have been easy to put poison in it and have Professor Yuzu Matsukaze drink it.\nBecause..." 
 
# game/script.rpy:1519 
translate english yuanyangcha_deduction_professor_cup_dark_8443b9a0: 
 
    # d normal "執務室は暗かったからです。" 
    d normal "The office was dark." 
 
# game/script.rpy:1521 
translate english yuanyangcha_deduction_professor_cup_dark_062e1af7: 
 
    # a "暗かったのは給湯室のほうだろ。" 
    a "It was the kitchenette that was dark." 
 
# game/script.rpy:1522 
translate english yuanyangcha_deduction_professor_cup_dark_14190504: 
 
    # m surprised "執務室が明るくても成立する証拠があったはずですね" 
    m surprised "There must have been evidence that would make this work even if the office had been bright." 
 
# game/script.rpy:1527 
translate english yuanyangcha_deduction_professor_cup_same_d22407ff: 
 
    # d normal "【躑躅|つつじ】 【椿|つばき】さんも【松風|まつかぜ】 【柚子|ゆず】教授も、大学生協の公式マグカップを使っていたからです。" 
    d normal "Both Tsubaki Tsutsuji and Professor Yuzu Matsukaze used the university co-op's official mugs." 
 
# game/script.rpy:1528 
translate english yuanyangcha_deduction_professor_cup_same_dd060645: 
 
    # d normal "「給湯室の水切りラックのどこで干すか」以外に違いがなく、執務室に持ち込んでしまえば本人にも区別ができない状況だったのです。" 
    d normal "There was no difference between them other than where they were dried on the kitchenette's dish rack, so once they were brought into the office, even their owners couldn't tell them apart." 
 
# game/script.rpy:1530 
translate english yuanyangcha_deduction_professor_cup_same_625e2b59: 
 
    # matcha "では、【躑躅|つつじ】 【椿|つばき】が犯人で決まりではありませんこと？" 
    matcha "Then doesn't that settle it? Tsubaki Tsutsuji must be the culprit, surely?" 
 
# game/script.rpy:1531 
translate english yuanyangcha_deduction_professor_cup_same_d9207aa5: 
 
    # d concerned "しかしながら、【躑躅|つつじ】 【椿|つばき】さんの飲み残しのカップを手に入れることができたのは、【躑躅|つつじ】 【椿|つばき】さんだけではなかったのです。" 
    d concerned "However, Tsubaki Tsutsuji was not the only person who could have obtained her cup with some drink left in it." 
 
# game/script.rpy:1532 
translate english yuanyangcha_deduction_professor_cup_same_d3c902fc: 
 
    # d normal "【躑躅|つつじ】 【椿|つばき】さんは毎日12時に実験室の遠心分離機を回し、タイマーが鳴る15分の間に、給湯室でカップと水筒を使う習慣がありました。" 
    d normal "Every day at noon, Tsubaki Tsutsuji would start the centrifuge in the laboratory and spend the fifteen minutes until the timer rang using her cup and thermos in the kitchenette." 
 
# game/script.rpy:1533 
translate english yuanyangcha_deduction_professor_cup_same_fba96be6: 
 
    # d normal "つまり、大学生協の公式マグカップを購入し、午前中にタイマーの時間を5分に早める。" 
    d normal "In other words, you could buy an official university co-op mug and change the timer to five minutes earlier that morning." 
 
# game/script.rpy:1534 
translate english yuanyangcha_deduction_professor_cup_same_04dc4e68: 
 
    # d normal "そして、12時に【躑躅|つつじ】 【椿|つばき】さんに飲み残しのカップと水筒を放置させたあと、水筒の中身を自前のカップに注ぐことで、すり替えることができたのです。" 
    d normal "Then, at noon, after getting Tsubaki Tsutsuji to leave her cup with the remaining drink and her thermos unattended, you could pour the contents of the thermos into your own cup and switch them." 
 
# game/script.rpy:1535 
translate english yuanyangcha_deduction_professor_cup_same_963ecb8c: 
 
    # matcha "しかし、【躑躅|つつじ】 【椿|つばき】に見つからずにそんなことが可能でして？" 
    matcha "But how could you possibly do that without being seen by Tsubaki Tsutsuji?" 
 
# game/script.rpy:1540 
translate english yuanyangcha_deduction_place_hide_4c8e039a: 
 
    # d normal "【躑躅|つつじ】 【椿|つばき】さんに見つからない方法、それは給湯室の中で隠れることです。" 
    d normal "The way to avoid being seen by Tsubaki Tsutsuji was to hide inside the kitchenette." 
 
# game/script.rpy:1550 
translate english yuanyangcha_deduction_place_hide_microwave_8fa80732: 
 
    # d normal "隠れられる場所は電子レンジの中です。" 
    d normal "The place you could hide was inside the microwave." 
 
# game/script.rpy:1552 
translate english yuanyangcha_deduction_place_hide_microwave_b314a7ee: 
 
    # a "人間もマグカップも穴が1つでトポロジー的に同じだから、とかいうジョークじゃねえよな？" 
    a "You're not making some joke about humans and mugs being topologically equivalent because they both have one hole, are you?" 
 
# game/script.rpy:1553 
translate english yuanyangcha_deduction_place_hide_microwave_4b9912f3: 
 
    # m concerned "穴があったら入りたいですね" 
    m concerned "If there were a hole, I'd want to crawl into it." 
 
# game/script.rpy:1558 
translate english yuanyangcha_deduction_place_hide_shelf_e8b691f8: 
 
    # d normal "隠れられる場所は棚の中です。" 
    d normal "The place you could hide was inside the cabinet." 
 
# game/script.rpy:1559 
translate english yuanyangcha_deduction_place_hide_shelf_5d13b01b: 
 
    # d normal "【躑躅|つつじ】 【椿|つばき】さんより先に給湯室に到着し、棚の中に隠れ、すり替えたカップを棚の中に隠して、給湯室を出る。" 
    d normal "You arrived at the kitchenette before Tsubaki Tsutsuji, hid inside the cabinet, hid the switched cup in the cabinet, and then left the kitchenette." 
 
# game/script.rpy:1560 
translate english yuanyangcha_deduction_place_hide_shelf_ce006a9a: 
 
    # d normal "あとは、【松風|まつかぜ】 【柚子|ゆず】教授との個人面談がある15時の前に給湯室に行き、すり替えたカップを取り出し、電子レンジで温め、毒を盛るだけです。" 
    d normal "After that, all you had to do was go to the kitchenette before your 3:00 p.m. meeting with Professor Yuzu Matsukaze, take out the switched cup, heat it in the microwave, and add the poison." 
 
# game/script.rpy:1561 
translate english yuanyangcha_deduction_place_hide_shelf_1cb2e856: 
 
    # d normal "そして、当日午前中にタイマーを5分に早められたことは、遠心分離機のログに残っています。" 
    d normal "And the fact that the timer was changed to five minutes earlier that morning is recorded in the centrifuge logs." 
 
# game/script.rpy:1563 
translate english yuanyangcha_deduction_place_hide_shelf_7ff3c5c0: 
 
    # matcha "その人物がわかれば、犯人もわかったようなものではありませんこと？" 
    matcha "If we can identify that person, wouldn't that essentially tell us who the culprit is?" 
 
# game/script.rpy:1564 
translate english yuanyangcha_deduction_place_hide_shelf_59a248b6: 
 
    # d concerned "残念ながら、それが誰かはわかりませんでした。" 
    d concerned "Unfortunately, we weren't able to determine who it was." 
 
# game/script.rpy:1565 
translate english yuanyangcha_deduction_place_hide_shelf_1a6fad62: 
 
    # d normal "しかし、ある別の証拠から、タイマーを早めた人物を絞り込むことができます。" 
    d normal "However, another piece of evidence allows us to narrow down who changed the timer." 
 
# game/script.rpy:1566 
translate english yuanyangcha_deduction_place_hide_shelf_fd78ca33: 
 
    # d normal "鑑識も見逃しておりましたが、「タイマーを5分に早めた日時」についてだけ、ログが書き換えらえていました。" 
    d normal "The forensics team missed this, but only the entry for the \"date and time when the timer was changed to five minutes\" had been altered." 
 
# game/script.rpy:1567 
translate english yuanyangcha_deduction_place_hide_shelf_bcf2b0f8: 
 
    # d normal "書き換えたあとの日時は「{color=[gui.keyword_color]}11時45分{/color}」。" 
    d normal "The altered time was \"{color=[gui.keyword_color]}11:45{/color}.\"" 
 
# game/script.rpy:1572 
translate english yuanyangcha_deduction_log_rewrite_d8b5964e: 
 
    # d normal "「タイマーを5分に早めた日時」を「{color=[gui.keyword_color]}11時45分{/color}」と書き換える動機があった人物は1人だけです。" 
    d normal "There is only one person who had a motive to change the \"date and time when the timer was changed to five minutes\" to \"{color=[gui.keyword_color]}11:45{/color}.\"" 
 
# game/script.rpy:1585 
translate english yuanyangcha_deduction_log_rewrite_tea_a2472b15: 
 
    # d normal "「{color=[gui.keyword_color]}11時45分{/color}」と書き換えたのは【躑躅|つつじ】 【椿|つばき】さんです。" 
    d normal "The person who changed it to \"{color=[gui.keyword_color]}11:45{/color}\" was Tsubaki Tsutsuji." 
 
# game/script.rpy:1586 
translate english yuanyangcha_deduction_log_rewrite_tea_967be521: 
 
    # tea smug "ふむ、「私の自作自演だった」とは面白い考えだね。" 
    tea smug "Hmm, \"I staged the whole thing myself\" is an interesting theory." 
 
# game/script.rpy:1587 
translate english yuanyangcha_deduction_log_rewrite_tea_02ba4ad9: 
 
    # tea smug "しかし、私が書き換えるならもっとふさわしい時間があったのではないか。" 
    tea smug "However, if I were going to alter it, wouldn't there have been a more suitable time?" 
 
# game/script.rpy:1588 
translate english yuanyangcha_deduction_log_rewrite_tea_ac59fc19: 
 
    # tea smug "たとえば、【菊苦菜|きくにがな】 ちこりだけが実験室にいた「8時過ぎ」……とかね。" 
    tea smug "For example, \"just after 8:00,\" when Chicory Kikunigana was the only one in the laboratory..." 
 
# game/script.rpy:1589 
translate english yuanyangcha_deduction_log_rewrite_tea_dac5fe27: 
 
    # m concerned "【躑躅|つつじ】 【椿|つばき】さんの言い分も、もっともですね" 
    m concerned "Tsubaki Tsutsuji does have a point." 
 
# game/script.rpy:1595 
translate english yuanyangcha_deduction_log_rewrite_chen_980b5ccb: 
 
    # d normal "「{color=[gui.keyword_color]}11時45分{/color}」と書き換えたのはジャシー・チェンさんです。" 
    d normal "The person who changed it to \"{color=[gui.keyword_color]}11:45{/color}\" was Jassie Chen." 
 
# game/script.rpy:1596 
translate english yuanyangcha_deduction_log_rewrite_chen_18b42813: 
 
    # chen smug "アイヤ！\n私、「{color=[gui.keyword_color]}11時45分{/color}」はまだ実験室にいましたよ。" 
    chen smug "Aiya!\nI was still in the laboratory at \"{color=[gui.keyword_color]}11:45{/color}.\"" 
 
# game/script.rpy:1597 
translate english yuanyangcha_deduction_log_rewrite_chen_1885c0d4: 
 
    # chen smug "もしも私が犯人だったら、【菊苦菜|きくにがな】 ちこりさんだけが実験室にいる「8時過ぎ」にします。" 
    chen smug "If I were the culprit, I would have changed it to \"just after 8:00,\" when Chicory Kikunigana was the only one in the laboratory." 
 
# game/script.rpy:1598 
translate english yuanyangcha_deduction_log_rewrite_chen_b8165a1f: 
 
    # m concerned "もっとほかに怪しい人がいますね" 
    m concerned "There are other people who seem more suspicious." 
 
# game/script.rpy:1604 
translate english yuanyangcha_deduction_log_rewrite_robusta_5698ba19: 
 
    # d normal "「{color=[gui.keyword_color]}11時45分{/color}」と書き換えたのは【菊苦菜|きくにがな】 ちこりさんです。" 
    d normal "The person who changed it to \"{color=[gui.keyword_color]}11:45{/color}\" was Chicory Kikunigana." 
 
# game/script.rpy:1605 
translate english yuanyangcha_deduction_log_rewrite_robusta_e2ff7340: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりさんは毎日、ほかの方よりも1時間早く実験室に到着するようですね。" 
    d normal "It seems that Chicory Kikunigana arrives at the laboratory one hour earlier than everyone else every day." 
 
# game/script.rpy:1606 
translate english yuanyangcha_deduction_log_rewrite_robusta_c2eb65e6: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりさんだけが実験室にいる8時過ぎなら、誰にも見られずにタイマーを早め、ログを書き換えることができた。" 
    d normal "Just after 8:00, when Chicory Kikunigana was the only person in the laboratory, she could have changed the timer and altered the log without being seen." 
 
# game/script.rpy:1607 
translate english yuanyangcha_deduction_log_rewrite_robusta_4ee23efe: 
 
    # d normal "また、【菊苦菜|きくにがな】 ちこりさんには「11時30分から12時30分まで実験室にいなかった」というアリバイがあった。" 
    d normal "Also, Chicory Kikunigana had an alibi that she was not in the laboratory from \"11:30 to 12:30.\"" 
 
# game/script.rpy:1608 
translate english yuanyangcha_deduction_log_rewrite_robusta_2b00634d: 
 
    # d normal "よって、「{color=[gui.keyword_color]}11時45分{/color}」と書き換える動機がある。" 
    d normal "Therefore, she had a motive to change it to \"{color=[gui.keyword_color]}11:45{/color}.\"" 
 
# game/script.rpy:1609 
translate english yuanyangcha_deduction_log_rewrite_robusta_11777b55: 
 
    # d normal "しかし、【躑躅|つつじ】 【椿|つばき】さんやジャシー・チェンさんなら「8時過ぎ」と書き換えたはずです。" 
    d normal "However, if it had been Tsubaki Tsutsuji or Jassie Chen, they would have changed it to \"just after 8:00.\"" 
 
# game/script.rpy:1610 
translate english yuanyangcha_deduction_log_rewrite_robusta_aa99b94e: 
 
    # "犯人扱いされて、【菊苦菜|きくにがな】 ちこりは怒りに肩を震わせた。" 
    "Angered at being treated as the culprit, Chicory Kikunigana trembled with indignation." 
 
# game/script.rpy:1611 
translate english yuanyangcha_deduction_log_rewrite_robusta_697e4330: 
 
    # robusta angry "そんなもの、状況証拠にすぎません！" 
    robusta angry "That's nothing more than circumstantial evidence!" 
 
# game/script.rpy:1612 
translate english yuanyangcha_deduction_log_rewrite_robusta_a2472cde: 
 
    # d "もっと決定的な証拠があります。" 
    d "I have more decisive evidence." 
 
# game/script.rpy:1613 
translate english yuanyangcha_deduction_log_rewrite_robusta_124fcf0d: 
 
    # d "それは、毒が盛られた飲み物です。" 
    d "It is the poisoned drink." 
 
# game/script.rpy:1618 
translate english yuanyangcha_deduction_poison_coffee_b7df9563: 
 
    # d normal "毒が検出されたカップにはコーヒーが入っていました。" 
    d normal "The cup in which the poison was detected contained coffee." 
 
# game/script.rpy:1628 
translate english yuanyangcha_deduction_poison_coffee_arabica_e4d6e1cd: 
 
    # d normal "毒が盛られたコーヒーは{color=[gui.keyword_color]}アラビカ種{/color}です。" 
    d normal "The poisoned coffee was {color=[gui.keyword_color]}Arabica{/color}." 
 
# game/script.rpy:1630 
translate english yuanyangcha_deduction_poison_coffee_arabica_29020ada: 
 
    # a "【竜|りん】……アイツに香りの成分を調べてもらっただろーが。" 
    a "【Ryu|Rin】... You had her analyze the aroma compounds." 
 
# game/script.rpy:1631 
translate english yuanyangcha_deduction_poison_coffee_arabica_5916f2be: 
 
    # m concerned "【竜胆|りんどう】 【茜|あかね】さんとの会話を思い出しましょう" 
    m concerned "Let's remember our conversation with Akane Rindo." 
 
# game/script.rpy:1636 
translate english yuanyangcha_deduction_poison_coffee_robusta_d375aae1: 
 
    # d normal "毒が盛られたコーヒーは{color=[gui.keyword_color]}ロブスタ種{/color}です。" 
    d normal "The poisoned coffee was {color=[gui.keyword_color]}Robusta{/color}." 
 
# game/script.rpy:1642 
translate english yuanyangcha_deduction_robusta_drink_2a4193be: 
 
    # d normal "そして、【菊苦菜|きくにがな】 ちこりさんも飲み物を持参していました。" 
    d normal "And Chicory Kikunigana had also brought her own drink." 
 
# game/script.rpy:1654 
translate english yuanyangcha_deduction_robusta_drink_arabica_8616ee27: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりさんの飲み物は{color=[gui.keyword_color]}アラビカ種{/color}のコーヒーです。" 
    d normal "Chicory Kikunigana's drink is {color=[gui.keyword_color]}Arabica{/color} coffee." 
 
# game/script.rpy:1656 
translate english yuanyangcha_deduction_robusta_drink_arabica_b35f3e94: 
 
    # a "たしかにコーヒーだったが、香りが決定的に違うな。" 
    a "It was definitely coffee, but the aroma was completely different." 
 
# game/script.rpy:1657 
translate english yuanyangcha_deduction_robusta_drink_arabica_c55ab7ac: 
 
    # m concerned "アラビカ種ではないコーヒーだったはずです" 
    m concerned "It should have been coffee that wasn't Arabica." 
 
# game/script.rpy:1662 
translate english yuanyangcha_deduction_robusta_drink_tea_868b9f17: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりさんの飲み物は{color=[gui.keyword_color]}紅茶{/color}です。" 
    d normal "Chicory Kikunigana's drink is {color=[gui.keyword_color]}black tea{/color}." 
 
# game/script.rpy:1664 
translate english yuanyangcha_deduction_robusta_drink_tea_b39ba79b: 
 
    # a "お前もあの色が紅茶でないことぐらいは見ただろ。" 
    a "You could at least tell from the color that it wasn't black tea." 
 
# game/script.rpy:1665 
translate english yuanyangcha_deduction_robusta_drink_tea_f3149a8f: 
 
    # m surprised "たしかにあの黒々とした色ははコーヒーでしたね" 
    m surprised "Indeed, that deep black color was coffee." 
 
# game/script.rpy:1670 
translate english yuanyangcha_deduction_robusta_drink_robusta_277ce859: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりさんの飲み物は{color=[gui.keyword_color]}ロブスタ種{/color}のコーヒーです。" 
    d normal "Chicory Kikunigana's drink is {color=[gui.keyword_color]}Robusta{/color} coffee." 
 
# game/script.rpy:1671 
translate english yuanyangcha_deduction_robusta_drink_robusta_99b0fc24: 
 
    # d normal "毒が盛られたコーヒーと一致しているのですよ。" 
    d normal "It matches the poisoned coffee." 
 
# game/script.rpy:1673 
translate english yuanyangcha_deduction_robusta_drink_robusta_448e16b4: 
 
    # robusta concerned "なぜ犯人が、毒を盛るカップに自分の飲み物を入れる必要があるのですか？" 
    robusta concerned "Why would the culprit need to put their own drink into the cup they were going to poison?" 
 
# game/script.rpy:1675 
translate english yuanyangcha_deduction_robusta_drink_robusta_99f23828: 
 
    # d normal "【躑躅|つつじ】 【椿|つばき】さんの飲み残しは{color=[gui.keyword_color]}200ml{/color}でしたが、水筒の残りは{color=[gui.keyword_color]}100ml{/color}しかありませんでした。" 
    d normal "There was {color=[gui.keyword_color]}200 ml{/color} of Tsubaki Tsutsuji's remaining drink, but there were only {color=[gui.keyword_color]}100 ml{/color} left in the thermos." 
 
# game/script.rpy:1676 
translate english yuanyangcha_deduction_robusta_drink_robusta_5ed62d86: 
 
    # d normal "そこで、自前のカップに水筒の100mlと飲み残しの100mlを注ぎ、200mlを確保した。" 
    d normal "So you poured the 100 ml from the thermos and 100 ml of the remaining drink into your own cup, securing 200 ml." 
 
# game/script.rpy:1677 
translate english yuanyangcha_deduction_robusta_drink_robusta_e688b546: 
 
    # d normal "しかし、【松風|まつかぜ】 【柚子|ゆず】教授にふるまうには、飲み残しのさらに残りの100mlは少なすぎる。" 
    d normal "However, the remaining 100 ml of the leftover drink was too little to serve to Professor Yuzu Matsukaze." 
 
# game/script.rpy:1678 
translate english yuanyangcha_deduction_robusta_drink_robusta_bb665e56: 
 
    # d normal "そこで、あなたは自前の飲み物を注ぎ足したのです。" 
    d normal "So you added some of your own drink." 
 
# game/script.rpy:1679 
translate english yuanyangcha_deduction_robusta_drink_robusta_0efc9ac8: 
 
    # robusta speak "【躑躅|つつじ】 【椿|つばき】さんやジャシー・チェンさんの飲み物の可能性は？" 
    robusta speak "What about Tsubaki Tsutsuji's or Jassie Chen's drinks?" 
 
# game/script.rpy:1682 
translate english yuanyangcha_deduction_robusta_drink_robusta_8765001f: 
 
    # tea smug "私は{color=[gui.keyword_color]}紅茶{/color}だ。" 
    tea smug "Mine is {color=[gui.keyword_color]}black tea{/color}." 
 
# game/script.rpy:1685 
translate english yuanyangcha_deduction_robusta_drink_robusta_d1ffd1bf: 
 
    # chen smug "私は100％{color=[gui.keyword_color]}アラビカ種{/color}ですよ。" 
    chen smug "Mine is 100\% {color=[gui.keyword_color]}Arabica{/color}." 
 
# game/script.rpy:1687 
translate english yuanyangcha_deduction_robusta_drink_robusta_274ef9b9: 
 
    # robusta concerned "えぇ！\nそんなものを飲んでいたんですか！？" 
    robusta concerned "What?!\nYou were drinking that!?" 
 
# game/script.rpy:1688 
translate english yuanyangcha_deduction_robusta_drink_robusta_cd0d36a5: 
 
    # robusta concerned "でも、【躑躅|つつじ】 【椿|つばき】さんの飲み残しのように、私のコーヒーを盗んで入れた可能性だったあるでしょう？" 
    robusta concerned "But couldn't someone have stolen my coffee and added it, just like Tsubaki Tsutsuji's leftover drink?" 
 
# game/script.rpy:1689 
translate english yuanyangcha_deduction_robusta_drink_robusta_e851965e: 
 
    # d normal "まず、【躑躅|つつじ】 【椿|つばき】さんなら、【菊苦菜|きくにがな】 ちこりさんに罪を着せるときに自分の飲み物を混ぜたり、自分で口をつける理由がない。" 
    d normal "First, if it were Tsubaki Tsutsuji, there would be no reason for her to mix in her own drink or drink from it herself when framing Chicory Kikunigana." 
 
# game/script.rpy:1690 
translate english yuanyangcha_deduction_robusta_drink_robusta_5a7ea6eb: 
 
    # robusta concerned "ええ、それは認めましょう。" 
    robusta concerned "Yes, I'll concede that." 
 
# game/script.rpy:1691 
translate english yuanyangcha_deduction_robusta_drink_robusta_f5f85d63: 
 
    # d normal "そして、ジャシーチェンさんなら、紅茶にコーヒーを混ぜたりしないんですよ。" 
    d normal "And if it were Jassie Chen, she wouldn't mix coffee into black tea." 
 
# game/script.rpy:1696 
translate english yuanyangcha_deduction_chen_home_eaffd420: 
 
    # d "紅茶にコーヒーを混ぜると、容疑がジャシーチェンさんに向くことになります。\nなぜなら……" 
    d "If you mix coffee into black tea, suspicion would fall on Jassie Chen.\nBecause..." 
 
# game/script.rpy:1706 
translate english yuanyangcha_deduction_chen_home_vietnam_c2e3c5be: 
 
    # d normal "ジャシーチェンさんの故郷では、コーヒーをブラックで飲まないからです。" 
    d normal "Because in Jassie Chen's hometown, people don't drink coffee black." 
 
# game/script.rpy:1708 
translate english yuanyangcha_deduction_chen_home_vietnam_1e54bb7b: 
 
    # a "ロブスタ種のコーヒーに練乳を入れるのはベトナムだろ。" 
    a "Vietnam is where they put condensed milk in Robusta coffee." 
 
# game/script.rpy:1709 
translate english yuanyangcha_deduction_chen_home_vietnam_049955c3: 
 
    # m surprised "ジャシーチェンさんの故郷は香港で、コーヒーはアラビカ種でしたね" 
    m surprised "Jassie Chen's hometown is Hong Kong, and the coffee there was Arabica, wasn't it?" 
 
# game/script.rpy:1714 
translate english yuanyangcha_deduction_chen_home_hong_kong_15f40f4d: 
 
    # d normal "ジャシーチェンさんの故郷では、{color=[gui.keyword_color]}【鴛鴦茶|ユンヨンチャ】{/color}として、紅茶にコーヒーを入れることがあるからです。" 
    d normal "Because in Jassie Chen's hometown, people sometimes add coffee to black tea as {color=[gui.keyword_color]}【Yuanyang Tea|Yuenyeung Tea】{/color}." 
 
# game/script.rpy:1715 
translate english yuanyangcha_deduction_chen_home_hong_kong_fcfb72f6: 
 
    # d normal "さらに、ジャシーチェンさんは紅茶を注ぎ足すことができました。" 
    d normal "Furthermore, Jassie Chen could have added more black tea." 
 
# game/script.rpy:1717 
translate english yuanyangcha_deduction_chen_home_hong_kong_939ed78e: 
 
    # chen smug "ティーバッグを持ち歩いてますからね。" 
    chen smug "I carry tea bags with me, after all." 
 
# game/script.rpy:1719 
translate english yuanyangcha_deduction_chen_home_hong_kong_d8674b45: 
 
    # a "で、【菊苦菜|きくにがな】 ちこりはなんで紅茶にコーヒーを注いんだんだ？" 
    a "So why did Chicory Kikunigana pour coffee into the black tea?" 
 
# game/script.rpy:1720 
translate english yuanyangcha_deduction_chen_home_hong_kong_910679c0: 
 
    # d normal "それは、紅茶をコーヒーと誤認したからです。" 
    d normal "Because she mistook the black tea for coffee." 
 
# game/script.rpy:1724 
translate english yuanyangcha_deduction_robusta_miss_d9061e1e: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりが紅茶をコーヒーと誤認した原因は2つ。" 
    d normal "There were two reasons why Chicory Kikunigana mistook the black tea for coffee." 
 
# game/script.rpy:1725 
translate english yuanyangcha_deduction_robusta_miss_94210c39: 
 
    # d normal "1つは「給湯室が暗かったから」。\nもう1つの原因は……" 
    d normal "One was \"because the kitchenette was dark.\"\nThe other reason was..." 
 
# game/script.rpy:1735 
translate english yuanyangcha_deduction_robusta_miss_sleep_b7492f14: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりさんの睡眠不足です。" 
    d normal "Chicory Kikunigana's lack of sleep." 
 
# game/script.rpy:1737 
translate english yuanyangcha_deduction_robusta_miss_sleep_f51ab465: 
 
    # a "いくら判断力が低下しても、紅茶とコーヒーの香りを間違えるか？" 
    a "No matter how impaired your judgment is, could you really mistake the smell of black tea for coffee?" 
 
# game/script.rpy:1738 
translate english yuanyangcha_deduction_robusta_miss_sleep_553eb080: 
 
    # m concerned "香りがわからなかった理由があるはずです" 
    m concerned "There must be a reason she couldn't recognize the aroma." 
 
# game/script.rpy:1743 
translate english yuanyangcha_deduction_robusta_miss_smell_62e3c8fa: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりさんの{color=[gui.keyword_color]}嗅覚障害{/color}です。" 
    d normal "Chicory Kikunigana's {color=[gui.keyword_color]}olfactory disorder{/color}." 
 
# game/script.rpy:1744 
translate english yuanyangcha_deduction_robusta_miss_smell_9f3e7060: 
 
    # d normal "色も香りも確認できなかった【菊苦菜|きくにがな】 ちこりさんは、{color=[gui.keyword_color]}紅茶{/color}を{color=[gui.keyword_color]}コーヒー{/color}と誤認したのです。" 
    d normal "Unable to confirm either the color or aroma, Chicory Kikunigana mistook the {color=[gui.keyword_color]}black tea{/color} for {color=[gui.keyword_color]}coffee{/color}." 
 
# game/script.rpy:1745 
translate english yuanyangcha_deduction_robusta_miss_smell_fb999472: 
 
    # "コンプレックスを暴露された【菊苦菜|きくにがな】 ちこりは、不快感をあらわにした。" 
    "Chicory Kikunigana showed her displeasure at having her complex exposed." 
 
# game/script.rpy:1747 
translate english yuanyangcha_deduction_robusta_miss_smell_ba54f289: 
 
    # robusta angry "仮に私が犯人だったとして、【松風|まつかぜ】 【柚子|ゆず】教授を毒殺する動機がありませんよ？" 
    robusta angry "Even if I were the culprit, I have no motive to poison Professor Yuzu Matsukaze." 
 
# game/script.rpy:1752 
translate english yuanyangcha_deduction_motive_b78cccd8: 
 
    # d normal "事件の前日に【松風|まつかぜ】 【柚子|ゆず】教授からメールを受け取ったあなたは、自身の論文の問題点に気づきました。" 
    d normal "The day before the incident, you received an email from Professor Yuzu Matsukaze and realized the problems with your own paper." 
 
# game/script.rpy:1764 
translate english yuanyangcha_deduction_motive_tea_e4e4046a: 
 
    # d normal "【松風|まつかぜ】 【柚子|ゆず】教授が功績を{color=[gui.keyword_color]}横取り{/color}していたことです。" 
    d normal "Professor Yuzu Matsukaze had been {color=[gui.keyword_color]}stealing credit{/color} for your achievements." 
 
# game/script.rpy:1766 
translate english yuanyangcha_deduction_motive_tea_eb246cb1: 
 
    # a "それはどっちかというと、【躑躅|つつじ】 【椿|つばき】の動機じゃねぇか？" 
    a "Wouldn't that be more of a motive for Tsubaki Tsutsuji?" 
 
# game/script.rpy:1767 
translate english yuanyangcha_deduction_motive_tea_3b5b61ca: 
 
    # m concerned "もっと研究者生命にかかわる動機でしたね" 
    m concerned "It was a motive that had more serious implications for someone's career as a researcher." 
 
# game/script.rpy:1772 
translate english yuanyangcha_deduction_motive_chen_80faa4ac: 
 
    # d normal "【松風|まつかぜ】 【柚子|ゆず】教授が助成金を{color=[gui.keyword_color]}横領{/color}していたことです。" 
    d normal "Professor Yuzu Matsukaze had been {color=[gui.keyword_color]}embezzling research funds{/color}." 
 
# game/script.rpy:1774 
translate english yuanyangcha_deduction_motive_chen_3b754309: 
 
    # a "それはどっちかというと、ジャシー・チェンの動機じゃねぇか？" 
    a "Wouldn't that be more of a motive for Jassie Chen?" 
 
# game/script.rpy:1775 
translate english yuanyangcha_deduction_motive_chen_2042bf55: 
 
    # m concerned "金銭的な問題ではありませんでしたね" 
    m concerned "It wasn't a financial issue." 
 
# game/script.rpy:1780 
translate english yuanyangcha_deduction_motive_robusta_b83de184: 
 
    # d normal "【松風|まつかぜ】 【柚子|ゆず】教授が{color=[gui.keyword_color]}データの捏造{/color}に気づいたことです。" 
    d normal "Professor Yuzu Matsukaze had discovered the {color=[gui.keyword_color]}fabrication of your data{/color}." 
 
# game/script.rpy:1781 
translate english yuanyangcha_deduction_motive_robusta_cd27fedd: 
 
    # d normal "データの捏造が公表されれば研究者生命が終わりますから、動機としては十分ですよね。" 
    d normal "If the data fabrication were made public, your career as a researcher would be over, so that is certainly enough of a motive." 
 
# game/script.rpy:1782 
translate english yuanyangcha_deduction_motive_robusta_5245d25a: 
 
    # "そのとき、【濁澤|にごりさわ】ニコルの端末から通知音が鳴り響いた。" 
    "At that moment, a notification sound rang out from Nicole Nigorisawa's device." 
 
# game/script.rpy:1784 
translate english yuanyangcha_deduction_motive_robusta_fa7ff9f6: 
 
    # a "解析完了。\n【菊苦菜|きくにがな】 ちこり、あんたの論文は100％クロだ。" 
    a "Analysis complete.\nChicory Kikunigana, your paper is 100\% fraudulent." 
 
# game/script.rpy:1786 
translate english yuanyangcha_deduction_motive_robusta_2686e2eb: 
 
    # "研究者としての死を宣告された【菊苦菜|きくにがな】 ちこりは膝から崩れ落ちた。" 
    "With her career as a researcher pronounced dead, Chicory Kikunigana collapsed to her knees." 
 
# game/script.rpy:1789 
translate english yuanyangcha_deduction_motive_robusta_ac84fcf6: 
 
    # chen sad "アイヤ！\n誰よりも実験していたのに、有意差が出なかったんですか？！" 
    chen sad "Aiya!\nYou experimented more than anyone else, and still couldn't get a statistically significant difference?!" 
 
# game/script.rpy:1792 
translate english yuanyangcha_deduction_motive_robusta_ed4f9066: 
 
    # tea smug "ふむ、興味深い研究だと思っていたのだがね。" 
    tea smug "Hmm, I thought it was an interesting study." 
 
# game/script.rpy:1794 
translate english yuanyangcha_deduction_motive_robusta_3dc8b73f: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりさんの行動をおさらいしましょう。" 
    d normal "Let's review Chicory Kikunigana's actions." 
 
# game/script.rpy:1795 
translate english yuanyangcha_deduction_motive_robusta_c942630b: 
 
    # d normal "【松風|まつかぜ】 【柚子|ゆず】教授からのメールをみたあなたは、一連の犯行を計画し、実行しました。" 
    d normal "After reading the email from Professor Yuzu Matsukaze, you planned and carried out the entire crime." 
 
# game/script.rpy:1796 
translate english yuanyangcha_deduction_motive_robusta_f0961d63: 
 
    # d normal "大学生協で公式マグカップを買い、8時に実験室に到着、毒を入手し、タイマーを5分に早め、ログの操作日時を「11時45分」に書き換える。" 
    d normal "You bought an official university co-op mug, arrived at the laboratory at 8:00, obtained the poison, changed the timer to five minutes, and altered the log's operation time to \"11:45.\"" 
 
# game/script.rpy:1797 
translate english yuanyangcha_deduction_motive_robusta_1badcaa4: 
 
    # d normal "11時30分、食堂に行くと見せかけて、給湯室の棚に隠れる。" 
    d normal "At 11:30, you pretended to go to the cafeteria and hid in the kitchenette cabinet." 
 
# game/script.rpy:1798 
translate english yuanyangcha_deduction_motive_robusta_868710c0: 
 
    # d normal "12時、【躑躅|つつじ】 【椿|つばき】さんが放置した水筒の中身を購入したマグカップに注ぎ、【躑躅|つつじ】 【椿|つばき】のマグカップを給湯室の棚に隠す。" 
    d normal "At 12:00, you poured the contents of the thermos left behind by Tsubaki Tsutsuji into the mug you had purchased, and hid Tsubaki Tsutsuji's mug in the kitchenette cabinet." 
 
# game/script.rpy:1799 
translate english yuanyangcha_deduction_motive_robusta_1fbe29a5: 
 
    # d normal "このとき、水筒の中身だけでは飲み残しの量に満たなかったため、飲み残しの一部も購入したマグカップに注いだ。" 
    d normal "At that point, because the contents of the thermos alone were not enough to match the amount of the leftover drink, you also poured some of the leftover drink into the mug you had purchased." 
 
# game/script.rpy:1800 
translate english yuanyangcha_deduction_motive_robusta_8c720d89: 
 
    # d normal "15時20分、給湯室で【躑躅|つつじ】 【椿|つばき】さんのマグカップを棚から取り出し、電子レンジで温めなおしてから毒を加える。" 
    d normal "At 3:20 p.m., you took Tsubaki Tsutsuji's mug out of the kitchenette cabinet, reheated it in the microwave, and added the poison." 
 
# game/script.rpy:1801 
translate english yuanyangcha_deduction_motive_robusta_497e9d06: 
 
    # d normal "このとき、視覚と嗅覚が制限されていたあなたは、飲み残しの紅茶をコーヒーと誤認し、カップに自前のコーヒーを注ぎたすことで満たした。" 
    d normal "At that point, with your vision and sense of smell impaired, you mistook the leftover black tea for coffee and filled the cup by adding your own coffee." 
 
# game/script.rpy:1802 
translate english yuanyangcha_deduction_motive_robusta_f88e479a: 
 
    # d normal "さらに、水切りラックから【松風|まつかぜ】 【柚子|ゆず】教授のカップを回収する。" 
    d normal "You then retrieved Professor Yuzu Matsukaze's cup from the dish rack." 
 
# game/script.rpy:1803 
translate english yuanyangcha_deduction_motive_robusta_00a81aa2: 
 
    # d normal "個人面談で【松風|まつかぜ】 【柚子|ゆず】教授がデータの捏造に気づいていることを確認し、公表までに猶予をもらってから、毒入りのカップを渡した。" 
    d normal "During the private meeting, you confirmed that Professor Yuzu Matsukaze knew about the data fabrication, asked for time before it was made public, and then handed him the poisoned cup." 
 
# game/script.rpy:1804 
translate english yuanyangcha_deduction_motive_robusta_c122d59e: 
 
    # d normal "【松風|まつかぜ】 【柚子|ゆず】教授も【躑躅|つつじ】 【椿|つばき】さんも大学生協の公式マグカップを使っているため、自身のカップと勘違いした【松風|まつかぜ】 【柚子|ゆず】教授は疑うことなく口にする。" 
    d normal "Because both Professor Yuzu Matsukaze and Tsubaki Tsutsuji used the university co-op's official mugs, Professor Yuzu Matsukaze mistook it for his own cup and drank from it without suspicion." 
 
# game/script.rpy:1805 
translate english yuanyangcha_deduction_motive_robusta_a2ad4a05: 
 
    # d normal "17時、亡くなった【松風|まつかぜ】 【柚子|ゆず】教授を搬送する混乱に乗じて、面談の内容が記載されている【松風|まつかぜ】 【柚子|ゆず】教授の研究ノートを回収した。" 
    d normal "At 5:00 p.m., amid the confusion of transporting the deceased Professor Yuzu Matsukaze, you took Professor Yuzu Matsukaze's research notebook containing the details of your meeting." 
 
# game/script.rpy:1806 
translate english yuanyangcha_deduction_motive_robusta_4c2c7e28: 
 
    # d normal "【菊苦菜|きくにがな】 ちこりさん、間違いないですね？" 
    d normal "Chicory Kikunigana, that's what happened, isn't it?" 
 
# game/script.rpy:1807 
translate english yuanyangcha_deduction_motive_robusta_84a3e592: 
 
    # robusta concerned "【躑躅|つつじ】 【椿|つばき】があんな小さな水筒に紅茶なんて入れていなければ……" 
    robusta concerned "If only Tsubaki Tsutsuji hadn't put black tea in such a small thermos..." 
 
# game/script.rpy:1808 
translate english yuanyangcha_deduction_motive_robusta_6c981ac8: 
 
    # d angry "いいえ、あなたが論文のデータを捏造したあげく、その告発者を口封じしようとしなければ、そもそも【松風|まつかぜ】 【柚子|ゆず】教授は亡くなっていませんでしたよ。" 
    d angry "No. If you hadn't fabricated the data in your paper and then tried to silence the person who exposed you, Professor Yuzu Matsukaze would never have died in the first place." 
 
# game/script.rpy:1809 
translate english yuanyangcha_deduction_motive_robusta_75dd3fd3: 
 
    # robusta concerned "ええ。成果を急ぐあまり、私は嗅覚だけでなく倫理観も失っていたようです。" 
    robusta concerned "Yes. In my haste to achieve results, it seems I lost not only my sense of smell, but also my sense of ethics." 
 
# game/script.rpy:1814 
translate english yuanyangcha_deduction_motive_robusta_41a15936: 
 
    # "ボクからの目線を受けて、【町矢|まちや】 【抹茶|まっちゃ】は【菊苦菜|きくにがな】 ちこりの両手に手錠をかけた。" 
    "At my signal, Matcha Machiya handcuffed Chicory Kikunigana." 
 
# game/script.rpy:1815 
translate english yuanyangcha_deduction_motive_robusta_d7218921: 
 
    # matcha "刑法199条違反の明白な疑いがあり、逃亡、および、証拠隠滅の恐れがあるため、緊急逮捕しますわ。" 
    matcha "There is clear suspicion that you have violated Article 199 of the Penal Code, and because you may flee or destroy evidence, I am placing you under emergency arrest." 
 
# game/script.rpy:1816 
translate english yuanyangcha_deduction_motive_robusta_2e44528d: 
 
    # "さて、【竜胆|りんどう】 【茜|あかね】からの依頼は事件を解決することであって、事件を担当することではない。" 
    "Now, Akane Rindo had asked us to solve the case, not to take responsibility for it." 
 
# game/script.rpy:1817 
translate english yuanyangcha_deduction_motive_robusta_023c14c1: 
 
    # "大量の書類を警視庁に放置してきたのだ。\nこれ以上増やされてはかなわない。" 
    "We had left a huge pile of paperwork at the Metropolitan Police Department.\nI couldn't bear to add any more to it." 
 
# game/script.rpy:1818 
translate english yuanyangcha_deduction_motive_robusta_5dcd5f87: 
 
    # d happy "それでは、逮捕状の請求と裁判書類の作成はおまかせしますね。" 
    d happy "Then I'll leave the arrest warrant application and the preparation of the court documents to you." 
 
# game/script.rpy:1820 
translate english yuanyangcha_deduction_motive_robusta_5427b61a: 
 
    # a "オレたちが集めた証拠も送ってやるから、感謝しろよ。" 
    a "We'll send you the evidence we collected too, so you'd better be grateful." 
 
# game/script.rpy:1825 
translate english yuanyangcha_deduction_motive_robusta_79625e9c: 
 
    # gal "あいつら、面倒なとこだけ押しつけてきたんだけど！" 
    gal "Those guys dumped all the troublesome parts on us!" 
 
# game/script.rpy:1826 
translate english yuanyangcha_deduction_motive_robusta_59f38b31: 
 
    # "【毛利|もうり】 【森子|もりこ】からの非難を尻目に、ボクとニコルは現場から一目散に逃げ出した。" 
    "Ignoring Moriko Mori's complaints, Nicole and I fled the scene as fast as we could." 
 
# game/script.rpy:1831 
translate english yuanyangcha_epilogue_coffee_c8315920: 
 
    # tp "8月28日（金） 10:00\n警視庁 第四取調室" 
    tp "Friday, August 28, 10:00\nTokyo Metropolitan Police Department, Fourth Interrogation Room" 
 
# game/script.rpy:1832 
translate english yuanyangcha_epilogue_coffee_123f40e0: 
 
    # "【竜胆|りんどう】 【茜|あかね】の助けを借りたことで、なんとか書類を片付け、一段落ついたころ。" 
    "With help from Akane Rindo, we somehow managed to finish the paperwork, and just as things were finally settling down..." 
 
# game/script.rpy:1833 
translate english yuanyangcha_epilogue_coffee_502ce3be: 
 
    # "【竜胆|りんどう】 【茜|あかね】からのメールで取調室に呼び出されると、今度は【躑躅|つつじ】 【椿|つばき】も在席していた。" 
    "We were summoned to the interrogation room by an email from Akane Rindo, and this time Tsubaki Tsutsuji was there as well." 
 
# game/script.rpy:1837 
translate english yuanyangcha_epilogue_coffee_d497a288: 
 
    # coffee "【菊苦菜|きくにがな】 ちこりの家宅を捜索したところ、すり替えたマグカップと、【松風|まつかぜ】 【柚子|ゆず】教授の研究ノートが見つかりました。" 
    coffee "A search of Chicory Kikunigana's home turned up the switched mug and Professor Yuzu Matsukaze's research notebook." 
 
# game/script.rpy:1838 
translate english yuanyangcha_epilogue_coffee_3db63b93: 
 
    # d normal "【躑躅|つつじ】 【椿|つばき】さんの潔白が証明されたようで、なによりです。" 
    d normal "I'm glad Tsubaki Tsutsuji's innocence has been proven." 
 
# game/script.rpy:1839 
translate english yuanyangcha_epilogue_coffee_d17577a0: 
 
    # coffee "あやうく、新しいルームシェア相手を探すところでした。" 
    coffee "I almost had to start looking for a new roommate." 
 
# game/script.rpy:1840 
translate english yuanyangcha_epilogue_coffee_48719ccf: 
 
    # tea "【茜|あかね】君、冗談がきつすぎるよ。" 
    tea "【Akane|Akane】, that's a bit too harsh a joke." 
 
# game/script.rpy:1841 
translate english yuanyangcha_epilogue_coffee_5a6191ed: 
 
    # coffee "私が何を作っても、「おいしい」としか言わないじゃないですか。" 
    coffee "No matter what I make, you only ever say, \"It's delicious.\"" 
 
# game/script.rpy:1842 
translate english yuanyangcha_epilogue_coffee_ab0015d7: 
 
    # tea "【茜|あかね】君が作った料理を【茜|あかね】君と食べれば、何でもおいしいのさ。" 
    tea "If I eat food made by 【Akane|Akane】 with 【Akane|Akane】, anything tastes delicious." 
 
# game/script.rpy:1843 
translate english yuanyangcha_epilogue_coffee_f75db218: 
 
    # coffee "【椿|つばき】……。" 
    coffee "Tsubaki..." 
 
# game/script.rpy:1845 
translate english yuanyangcha_epilogue_coffee_49ca2984: 
 
    # a "オレたちは何を見せられてんだ？" 
    a "What are we watching here?" 
 
# game/script.rpy:1846 
translate english yuanyangcha_epilogue_coffee_2a8a18c6: 
 
    # d normal "それで、研究室のほうは？" 
    d normal "So, what about the laboratory?" 
 
# game/script.rpy:1847 
translate english yuanyangcha_epilogue_coffee_2a46b06c: 
 
    # tea "ふむ。【松風|まつかぜ】 【柚子|ゆず】教授の研究室と研究は、私とジャシー君が共同で引き継ぐことにしたよ。" 
    tea "Hmm. Jassie and I have decided to take over Professor Yuzu Matsukaze's laboratory and research together." 
 
# game/script.rpy:1848 
translate english yuanyangcha_epilogue_coffee_2d690ff8: 
 
    # tea "お蔵入りさせるのは人類の損失だからね。" 
    tea "It would be a loss to humanity to let it go to waste." 
 
# game/script.rpy:1849 
translate english yuanyangcha_epilogue_coffee_01d4a964: 
 
    # tea "君たちがいなければ、科学の進歩が5年は遅れるところだったよ。\n深く感謝する。" 
    tea "Without you, the progress of science would have been delayed by at least five years.\nI am deeply grateful." 
 
# game/script.rpy:1850 
translate english yuanyangcha_epilogue_coffee_b737df7e: 
 
    # a "推理とお茶の知識は全部こいつに任せきりだったがな。" 
    a "Although we left all the deduction and tea knowledge to this guy." 
 
# game/script.rpy:1851 
translate english yuanyangcha_epilogue_coffee_54b4e620: 
 
    # d happy "ニコルの情報解析とコーヒー知識も不可欠でしたよ。" 
    d happy "Nicole's information analysis and coffee knowledge were indispensable too." 
 
# game/script.rpy:1852 
translate english yuanyangcha_epilogue_coffee_bef0fe8a: 
 
    # coffee "【鴛鴦茶|ユンヨンチャ】には紅茶とコーヒーの両方が必要なように、今回の事件の解決にも【水神|みなかみ】 【南|みなみ】さんと【濁澤|にごりさわ】ニコルさんの両方が必要だった、ということですね。" 
    coffee "Just as Yuenyeung Tea requires both black tea and coffee, solving this case required both Minami Minakami and Nicole Nigorisawa, didn't it?" 
 
# game/script.rpy:1853 
translate english yuanyangcha_epilogue_coffee_ee2113aa: 
 
    # m concerned "飲み物にちなんだ、おかしな事件が重なっていますね" 
    m concerned "We've had a series of strange cases involving drinks." 
 
# game/script.rpy:1854 
translate english yuanyangcha_epilogue_coffee_5010eebb: 
 
    # m concerned "偶然だといいのですが……" 
    m concerned "I hope it's just a coincidence..." 
 
# game/script.rpy:1855 
translate english yuanyangcha_epilogue_coffee_86a89dc9: 
 
    # chara_rb "つづく" 
    chara_rb "To be continued"

translate english strings: 
 
    # game/script.rpy:135 
    old "ギャバロン茶" 
    new "Gabalong tea" 
 
    # game/script.rpy:135 
    old "【大森|おおもり】 【正司|まさし】教授が、まともな値段のつかなかった二番茶、三番茶を活用するために、生の茶葉を窒素ガスの中でしばらく保存したところ、γ-アミノ酪酸（英語名γ(gamma)-aminobutyric acid の頭文字をとった略称がGABA）が一般的な緑茶の20〜30倍になることを発見した。\nGABAの経口摂取は、高血圧患者の血圧を下げる作用や、肝臓のアルコール分解能を促進する作用、食後の急激な血糖値の上昇を抑制する作用があり、脳卒中の予防、認知症の予防にも効果がある。\n【大森|おおもり】 【正司|まさし】教授はGABAに烏龍茶の「ロン」を組み合わせて「ギャバロン茶」と命名して学会発表したものの、特許申請をしなかったことにより、複数の企業から「GABA」を冠した商品が出る「GABAブーム」が起きた。" 
    new "Professor Masashi Omori discovered that when fresh tea leaves were stored in nitrogen gas for a while to make use of second- and third-flush tea leaves that could not command a decent price, their γ-aminobutyric acid (GABA, an abbreviation of the English name gamma-aminobutyric acid) content became 20 to 30 times higher than that of ordinary green tea.\nOral intake of GABA can lower blood pressure in people with hypertension, promote the liver's ability to break down alcohol, and suppress rapid rises in blood sugar after meals. It is also said to help prevent strokes and dementia.\nProfessor Masashi Omori combined GABA with the \"long\" in oolong tea and named the product \"Gabalong tea\" when presenting it at an academic conference. However, because he did not apply for a patent, a \"GABA boom\" occurred, with multiple companies releasing products bearing the name \"GABA\"." 
 
    # game/script.rpy:135 
    old "「緑茶」「烏龍茶」「紅茶」の違い" 
    new "The Difference Between \"Green Tea\", \"Oolong Tea\", and \"Black Tea\"" 
 
    # game/script.rpy:135 
    old "「緑茶」「烏龍茶」「紅茶」はすべて中国茶由来の言葉であり、中国茶では緑茶、白茶、黄茶、青茶、紅茶の順に発酵度合いが上がっていく。\n「烏龍茶」は中国茶の「青茶」の一種。" 
    new "\"Green tea\", \"oolong tea\", and \"black tea\" are all terms derived from Chinese tea. In Chinese tea, the degree of oxidation increases in the order of green tea, white tea, yellow tea, blue tea, and black tea.\n\"Oolong tea\" is a type of the Chinese tea category known as \"blue tea\"." 
 
    # game/script.rpy:135 
    old "お茶の「発酵」は厳密には「付加反応」" 
    new "The \"fermentation\" of tea is technically an \"addition reaction\"" 
 
    # game/script.rpy:135 
    old "「烏龍茶」「紅茶」の製造過程で行われる「発酵」は「水と酸素による反応」であり、「有機物に対する微生物の反応」ではないため、厳密には「付加反応」。\nちなみに「有機物に対する微生物の反応」のうち、人間に有益なものが「発酵」、そうではないものが「腐敗」。\n製造過程で厳密な意味での「発酵」をさせるお茶は「黒茶」や「後発酵茶」と呼ばれる。\nちなみに、英語で「black tea」は紅茶を指し、黒茶や後発酵茶を指す場合は、発酵を意味するfermentから「fermented tea」や、黒茶の色の特性から「brown tea」と呼ぶ。" 
    new "The \"fermentation\" performed during the production of \"oolong tea\" and \"black tea\" is a \"reaction involving water and oxygen\" rather than a \"microbial reaction involving organic matter\", so technically it is an \"addition reaction\".\nIncidentally, among \"microbial reactions involving organic matter\", those that are beneficial to humans are called \"fermentation\", while those that are not are called \"putrefaction\".\nTeas that undergo \"fermentation\" in the strict sense during production are called \"dark tea\" or \"post-fermented tea\".\nIncidentally, in English, \"black tea\" refers to 紅茶, while 黒茶 or 後発酵茶 may be called \"fermented tea\", from \"ferment\" meaning fermentation, or \"brown tea\", referring to the characteristic color of dark tea." 
 
    # game/script.rpy:135 
    old "「クオリティーシーズン」は紅茶の収穫時期の違い" 
    new "\"Quality season\" refers to differences in the harvesting seasons of black tea" 
 
    # game/script.rpy:135 
    old "香りや味が最も充実した良質な紅茶が期待できる季節のことを「クオリティーシーズン」と呼ぶ。\nダージリンの場合、ファーストフラッシュ（3月中旬～4月）、セカンドフラッシュ（5月～7月上旬）、オータムナル（10月～11月中旬）がクオリティーシーズンと呼ばれ、それぞれ異なる香りや味を楽しむことができる。\n緑茶でも同様の呼び分けがあり、5月に摘まれた「一番茶」を「煎茶」、それ以降に摘まれた「二番茶」以降を「番茶」と呼ぶ。" 
    new "The season when high-quality black tea with the richest aromas and flavors can be expected is called the \"quality season\".\nIn the case of Darjeeling, the first flush (mid-March to April), second flush (May to early July), and autumnal (October to mid-November) are called quality seasons, and each offers different aromas and flavors.\nGreen tea also has similar distinctions: the \"first flush\" harvested in May is called \"sencha\", while tea harvested thereafter, beginning with the \"second flush\", is called \"bancha\"." 
 
    # game/script.rpy:135 
    old "紅茶の「等級」は茶葉の形状と大きさ" 
    new "Black tea \"grades\" indicate the shape and size of the tea leaves" 
 
    # game/script.rpy:135 
    old "紅茶の等級とは、紅茶の製造過程で【篩|ふるい】のメッシュによって分けられた、葉の形状、大きさを表す言葉。\n茶葉の品質とは関係がない。\n紅茶の抽出時間（蒸らし時間）は、大きい葉なら長く、細かい葉なら短くなる。\n【篩|ふるい】にかけて同じ大きさの茶葉に揃えることで、抽出の時間も一定になり、バランスのよい味になる。\n「オレンジ・ペコー」が一番大きく、頭に「フラワリー」が付くと新芽の比率が高くなり、頭に「ブロークン」が付くとカットしたもの、末尾に「ファニングス」が付くとほとんど粉状になったもの、さらに細かくなると「ダスト」。\nほかに、機械で成型した「CTC」がある。" 
    new "Black tea grades are terms describing the shape and size of the leaves, determined by separating them according to the mesh size of a 【篩|ふるい】 during the manufacturing process.\nThey have nothing to do with the quality of the tea leaves.\nThe brewing time of black tea is longer for large leaves and shorter for smaller leaves.\nBy using a 【篩|ふるい】 to sort the leaves into the same size, the brewing time becomes consistent and the resulting flavor is well balanced.\n\"Orange Pekoe\" is the largest. Adding \"Flowery\" at the beginning indicates a higher proportion of young buds; \"Broken\" indicates cut leaves; \"Fannings\" at the end indicates leaves reduced almost to powder; and even finer particles are called \"Dust\".\nThere is also \"CTC\", which is shaped by machine." 
 
    # game/script.rpy:135 
    old "「中国種」と「アッサム種」" 
    new "\"China variety\" and \"Assam variety\"" 
 
    # game/script.rpy:135 
    old "「チャ」は「ツツジ目ツバキ科カメリア属の永年性常緑樹」のことで、飲用に使われるのは「中国種」と「アッサム種」の主に2種類。\n中国種は寒さに強く小葉で主に緑茶・烏龍茶向け、アッサム種は寒さに弱く大葉で紅茶（特にコクのあるタイプ）向け。" 
    new "\"Tea\" refers to an evergreen perennial tree of the Camellia genus in the family Theaceae, order Ericales. There are mainly two varieties used for drinking: the \"China variety\" and the \"Assam variety\".\nThe China variety is cold-hardy and has small leaves, making it mainly suited to green and oolong tea. The Assam variety is less cold-tolerant and has large leaves, making it suited to black tea, particularly full-bodied types." 
 
    # game/script.rpy:135 
    old "「ダージリン」は紅茶の産地名" 
    new "\"Darjeeling\" is the name of a black tea producing region" 
 
    # game/script.rpy:135 
    old "「ダージリン」はチベット語で「雷の町」を意味し、1835年に在印イギリス軍の避暑地として発展した。\nそのフルーティな香りから「紅茶のシャンパン」と呼ばれることもある。" 
    new "\"Darjeeling\" means \"land of the thunderbolt\" in Tibetan and developed as a summer retreat for the British forces in India in 1835.\nBecause of its fruity aroma, it is sometimes called the \"champagne of teas\"." 
 
    # game/script.rpy:135 
    old "「シャンパン」の語源も定義も地名" 
    new "Both the origin and definition of \"champagne\" are geographical" 
 
    # game/script.rpy:135 
    old "「シャンパン」の語源はフランス北東部の「シャンパーニュ地方」。\n国際的な知的財産権として地理的表示に指定され、「シャンパーニュ地方で、定められた製法で作られた物」のみ「シャンパン」という名称を使うことができる。" 
    new "The origin of the name \"champagne\" is the \"Champagne region\" of northeastern France.\nIt is designated as a geographical indication under international intellectual property law, and only products \"made in the Champagne region using the prescribed production methods\" may use the name \"champagne\"." 
 
    # game/script.rpy:135 
    old "「アールグレイ」はベルガモットで香りをつけた紅茶" 
    new "\"Earl Grey\" is black tea flavored with bergamot" 
 
    # game/script.rpy:135 
    old "「アールグレイ」は柑橘類の一種、ベルガモットで香りをつけたフレーバーティ。\n茶葉は主に中国種のキーマンが使われる。\n19世紀にイギリス首相を務めた政治家「チャールズ・グレイ伯爵」が紹介したことが名前の由来。" 
    new "\"Earl Grey\" is a flavored tea scented with bergamot, a type of citrus fruit.\nThe tea leaves used are mainly Keemun, a China variety.\nThe name comes from the politician \"Charles Grey, 2nd Earl Grey\", who served as British prime minister in the 19th century and introduced the tea." 
 
    # game/script.rpy:135 
    old "「フレーバーティー」と「ブレンドティー」の違い" 
    new "The difference between \"flavored tea\" and \"blended tea\"" 
 
    # game/script.rpy:135 
    old "お茶以外のものを添加するのが「フレーバーティー」なのに対し、複数の茶葉を配合するのが「ブレンドティー」。\n各社が出している「ブレックファスト」「アフタヌーンティー」も「ブレンドティー」の一種。" 
    new "Adding something other than tea makes it \"flavored tea\", whereas combining multiple types of tea leaves makes it \"blended tea\".\n\"Breakfast\" and \"Afternoon Tea\" blends offered by various companies are also types of \"blended tea\"." 
 
    # game/script.rpy:135 
    old "「チャ」と「ティー」の違い" 
    new "The difference between \"cha\" and \"tea\"" 
 
    # game/script.rpy:135 
    old "現在世界各国で使われている「茶」を意味する言葉は「チャ」か「ティー」の、いずれかに大別される。\nもとはどちらも中国で、広東語の「チャ」と福建語の「テー」が語源。\n「チャ」は陸路経由で、北は北京やモンゴルへ、西はチベット、インドを経て中近東各地、ロシアへと広まった。\n一方「テー」のほうは、福建の港・アモイで貿易を始めたオランダの影響が強く、イギリス、フランス、北欧各地など、海路で広まった。" 
    new "Words meaning \"tea\" used around the world today can broadly be divided into either \"cha\" or \"tea\".\nBoth ultimately originated in China, from the Cantonese \"cha\" and the Fujian \"te\".\n\"Cha\" spread overland northward to Beijing and Mongolia, and westward through Tibet and India to the Middle East and Russia.\n\"Te\", on the other hand, spread by sea under strong Dutch influence, beginning with trade at the Fujian port of Xiamen and reaching Britain, France, and northern Europe." 
 
    # game/script.rpy:135 
    old "【鴛鴦茶|ユンヨンチャ】" 
    new "Yuanyang tea" 
 
    # game/script.rpy:135 
    old "香港はかつてイギリスに占領されていたため、紅茶とコーヒーの消費量が多い。\nその香港で生まれたのが、紅茶とコーヒーを混ぜた飲み物「【鴛鴦茶|ユンヨンチャ】」。\n「【鴛鴦|ユンヨン】」は「オシドリのオスとメス」のこと。\n中国では男女同時に使うものや、二つが一つになったものの名前に「【鴛鴦|ユンヨン】」を付けることがある。" 
    new "Hong Kong was once occupied by Britain, which is why tea and coffee are both widely consumed there.\nThe drink \"Yuanyang tea\", which mixes black tea and coffee, originated in Hong Kong.\n\"【鴛鴦|Yuanyang】\" refers to \"a male and female mandarin duck\".\nIn China, \"【鴛鴦|Yuanyang】\" is sometimes added to the names of things used by men and women together, or things in which two elements are combined into one." 
 
    # game/script.rpy:135 
    old "「セイロンティー」と「リプトン」はコーヒーさび病の産物" 
    new "\"Ceylon tea\" and \"Lipton\" were products of coffee leaf rust" 
 
    # game/script.rpy:135 
    old "スリランカは19世紀前半からコーヒーの産地だったが、1867年にコーヒーさび病が流行して壊滅した。\n放棄されたコーヒー農園を見たトーマス・リプトン卿が1890年に紅茶の栽培に転用したのが「セイロンティー」と「リプトン」の起源。" 
    new "Sri Lanka had been a coffee-producing region since the first half of the 19th century, but it was devastated by an outbreak of coffee leaf rust in 1867.\nThe origin of \"Ceylon tea\" and \"Lipton\" dates back to 1890, when Sir Thomas Lipton saw the abandoned coffee plantations and converted them to tea cultivation." 
 
    # game/script.rpy:135 
    old "アヘン戦争の原因はイギリスの紅茶貿易" 
    new "The Opium Wars were caused by Britain's tea trade" 
 
    # game/script.rpy:135 
    old "茶を中国からの輸入にのみ頼っていたイギリスは、需要の増加によって、支払いにあてる銀貨が不足した。\nそこで、当時植民地だったインドのアヘンを、中国へ盛んに輸出するようになった。\nこの貿易による軋轢がアヘン戦争（1840-1842）を引き起こすことになった。" 
    new "Britain relied entirely on imports of tea from China, and as demand increased, it faced a shortage of silver coins to pay for them.\nAs a result, Britain began exporting large quantities of opium from India, then a British colony, to China.\nThe tensions caused by this trade eventually led to the Opium War (1840-1842)." 
 
    # game/script.rpy:135 
    old "アメリカ独立戦争の原因はイギリスの紅茶貿易" 
    new "The American Revolution was caused by Britain's tea trade" 
 
    # game/script.rpy:135 
    old "18世紀後半、イギリスの植民地だったアメリカでは、本国同様に茶の消費が増加していた。\nしかし政府が課した茶税への反発から不買運動と密輸が広がり、茶の独占輸入権を持っていた東インド会社は大量の在庫を抱えてしまう。\n1773年、この在庫を安く販売するため東インド会社の関税を免除する「茶法（茶条例）」が制定されると、本国政府のでたらめな政策に反発した人々はボストンに入港した同社の船を襲い、積荷の茶を海に投げ捨ててしまうという事件を起こした。\nこれが「ボストン・ティーパーティー事件」であり、後にアメリカ独立戦争へと発展していった。" 
    new "In the latter half of the 18th century, tea consumption was increasing in America, then a British colony, just as it was in Britain.\nHowever, boycotts and smuggling spread in opposition to the tea tax imposed by the government, leaving the East India Company, which held a monopoly on tea imports, with a huge inventory.\nIn 1773, the Tea Act was enacted, exempting the East India Company from certain duties so that it could sell this inventory cheaply. In protest against the British government's reckless policies, people attacked the company's ships entering Boston and threw their cargo of tea into the sea.\nThis became known as the \"Boston Tea Party」 and later developed into the American Revolutionary War." 
 
    # game/script.rpy:135 
    old "「カフェオレ」と「カフェラテ」の違い" 
    new "The difference between \"café au lait\" and \"caffè latte\"" 
 
    # game/script.rpy:135 
    old "エスプレッソマシンが1902年のミラノ万博で発表されると、エスプレッソはイタリアを象徴する飲み物として、バール（立ち飲み可能なカフェ）で普及した。\nこれはコーヒーの飲み方の名前にも現れており、「カフェオレ」と「カフェラテ」はどちらも直訳すると「ミルク入りコーヒー」だが、フランス語の「カフェオレ」はベースがドリップコーヒーなのに対し、イタリア語の「カフェラテ」はベースがエスプレッソ。" 
    new "When the espresso machine was unveiled at the 1902 Milan World's Fair, espresso became popular in bars (cafés where standing to drink is common) as a beverage symbolizing Italy.\nThis distinction is also reflected in the names of coffee preparations. Both \"café au lait\" and \"caffè latte\" literally mean \"coffee with milk\", but the French \"café au lait\" is based on drip coffee, whereas the Italian \"caffè latte\" is based on espresso." 
 
    # game/script.rpy:135 
    old "「カフェラテ」と「カプチーノ」の違い" 
    new "The difference between \"caffè latte\" and \"cappuccino\"" 
 
    # game/script.rpy:135 
    old "「カプチーノ」も「カフェラテ」と同じくイタリア語でエスプレッソがベース。\n「カプチーノ」と「カフェラテ」の違いは、「カプチーノ」は牛乳の泡の層が1cm以上あること。" 
    new "Like \"caffè latte\", \"cappuccino\" is an Italian drink based on espresso.\nThe difference between \"cappuccino\" and \"caffè latte\" is that \"cappuccino\" has a layer of milk foam at least 1 cm thick." 
 
    # game/script.rpy:135 
    old "「カプチーノ」の語源" 
    new "The origin of the word \"cappuccino\"" 
 
    # game/script.rpy:135 
    old "「カプチーノ」はもとは「カトリック教会の一派であるカプチン会の修道士」のことを指す言葉で、その「カプチーノ」の語源は彼らが着るフードのついた修道服「カップッチョ（cappuccio、「頭巾、フード」の意）」。" 
    new "\"Cappuccino\" originally referred to \"a monk of the Capuchin order, a branch of the Catholic Church\". The word \"cappuccino\" comes from the hooded habit worn by these monks, called \"cappuccio\" (meaning \"hood\")." 
 
    # game/script.rpy:135 
    old "「カプチーノ」が「カフェラテ」よりも安い理由" 
    new "Why \"cappuccino\" can be cheaper than \"caffè latte\"" 
 
    # game/script.rpy:135 
    old "「カプチーノ」が「カフェラテ」よりも安いことがあるのは、牛乳の泡の占める比率が高く、泡立てている分だけ原料の牛乳が少なくて済むから。" 
    new "\"Cappuccino\" can sometimes be cheaper than \"caffè latte\" because a larger proportion of the drink consists of milk foam, meaning less actual milk is needed because some of it has been whipped into foam." 
 
    # game/script.rpy:135 
    old "「アイスコーヒー」が「ホットコーヒー」よりも高い理由" 
    new "Why \"iced coffee\" can be more expensive than \"hot coffee\"" 
 
    # game/script.rpy:135 
    old "「アイスコーヒー」が「ホットコーヒー」よりも高いことがあるのは、飲み物の温度が低いと味覚が鈍るため、より多くコーヒー豆を使用しないと同じ濃さに感じられないから。" 
    new "\"Iced coffee\" can sometimes be more expensive than \"hot coffee\" because lower beverage temperatures dull the sense of taste, meaning more coffee beans are needed for the drink to taste equally strong." 
 
    # game/script.rpy:135 
    old "「カフェモカ」の「モカ」はコーヒー豆の名前だが、そのコーヒー豆は使っていない" 
    new "The \"mocha\" in \"café mocha\" is the name of a coffee bean, but those beans are not used" 
 
    # game/script.rpy:135 
    old "「カフェモカ」はアメリカ生まれの飲み物で、イタリア風を意識したエスプレッソに牛乳とチョコレートソースを加えている。「カフェ」はコーヒーのことだが、「モカ」はチョコレートのことではない。\n「モカ」とは「イエメンの港『モカ』から出荷されるような、イエメンやエチオピア産のコーヒー豆」のこと。それを淹れた「モカコーヒー」は上品な味わいから「コーヒーの貴婦人」と呼ばれ、カカオ（チョコレート）に似た風味がある。\nつまり「カフェモカ」は、「モカ」ではないコーヒー豆にチョコレートを入れることで「モカコーヒー」に似せたもの。" 
    new "\"Café mocha\" is an American drink consisting of espresso prepared in an Italian style with milk and chocolate sauce. \"Café\" means coffee, but \"mocha\" does not mean chocolate.\n\"Mocha\" refers to \"coffee beans from Yemen or Ethiopia that were shipped through the Yemeni port of Mocha\". The brewed \"mocha coffee\" is known as the \"lady of coffees\" for its refined flavor and has a flavor reminiscent of cacao (chocolate).\nIn other words, \"café mocha\" imitates \"mocha coffee\" by adding chocolate to coffee beans that are not actually \"mocha\" beans." 
 
    # game/script.rpy:135 
    old "ベトナムコーヒー" 
    new "Vietnamese coffee" 
 
    # game/script.rpy:135 
    old "ブラジルに次ぐコーヒーの産地であるベトナムでは、高温多湿でも育てられるロブスタ種が主に栽培されている。\nロブスタ種は臭みが強いため、現地では練乳を入れて飲むことが多く、そのような飲み方を「ベトナムコーヒー」と呼ぶことがある。" 
    new "Vietnam, the world's second-largest coffee-producing country after Brazil, mainly grows the Robusta variety, which can be cultivated in hot and humid conditions.\nBecause Robusta has a strong, distinctive odor, it is often consumed locally with condensed milk. This style of preparation is sometimes called \"Vietnamese coffee\"." 
 
    # game/script.rpy:135 
    old "「アラビカ種」と「ロブスタ種」" 
    new "\"Arabica\" and \"Robusta\"" 
 
    # game/script.rpy:135 
    old "「アラビカ種」は15世紀から数百年間「世界で唯一のコーヒー」であり、現在も世界の生産量の6,7割を占めているが、病害虫に弱く、高地でしか栽培できず、面積当たりの収穫量も少ないという欠点があった。\n19世紀末に東南アジアでコーヒーさび病が流行した際、すべての型のさび病に耐性を持つ唯一の種として見出されたのが「カネフォーラ種」であり、高い耐病性のほかにも、低地でも栽培可能、面積当たりの収穫量が多いことから、コーヒー業界では「頑強な」を意味する「ロブスタ」と名付けられた。\nロブスタ種の欠点は、出来上がったコーヒーの酸味と香りでアラビカ種に劣り、「ロブスタ臭」と呼ばれる独特の土臭さがあること。\nほかにも耐病性と美味しさの両立を目指した様々な種が存在するが、アラビカ種とロブスタ種だけで世界の生産量の9割以上を占めている。" 
    new "\"Arabica\" was the \"world's only coffee\" for several centuries from the 15th century and still accounts for 60 to 70 percent of global production, but it has disadvantages: it is vulnerable to pests and diseases, can only be cultivated at high elevations, and has a low yield per unit area.\nWhen coffee leaf rust spread through Southeast Asia at the end of the 19th century, the \"Canephora\" species was discovered to be the only species resistant to all forms of rust. In addition to its high disease resistance, it can be cultivated at low elevations and produces high yields per unit area, so the coffee industry named it \"Robusta\", meaning \"robust\".\nThe disadvantage of Robusta is that its finished coffee is inferior to Arabica in acidity and aroma and has a distinctive earthy smell known as \"Robusta odor\".\nThere are also various other species developed to combine disease resistance with good flavor, but Arabica and Robusta alone account for more than 90 percent of global production." 
 
    # game/script.rpy:135 
    old "1日50杯コーヒーを飲んだ文豪" 
    new "The literary giant who drank 50 cups of coffee a day" 
 
    # game/script.rpy:135 
    old "『ゴリオ爺さん』を含む小説群『人間喜劇』で有名なオノレ・ド・バルザックは、毎日午前1時に起床し、1日に50杯のコーヒーを飲みながら小説を執筆、一段落すると社交界で暴食するか知人と遊ぶ生活を送っていた。\nそんな生活を送って健康でいられるはずがなく、晩年は失明し、腹膜炎が原因で51歳で亡くなった。" 
    new "Honoré de Balzac, famous for the series of novels \"La Comédie humaine\" including \"Le Père Goriot\", woke up at 1 a.m. every day and wrote novels while drinking 50 cups of coffee a day. When he finished a section, he would either overeat in high society or spend time with acquaintances.\nIt was hardly a lifestyle conducive to good health. In his later years he became blind and died at the age of 51 from peritonitis." 
 
    # game/script.rpy:135 
    old "「コーヒー豆」は厳密には「豆」ではない" 
    new "\"Coffee beans\" are technically not \"beans\"" 
 
    # game/script.rpy:135 
    old "コーヒーの原材料は「コーヒー豆」と呼ばれがちだが、「豆」は「マメ目マメ科」の植物の種子の総称。\n 「コーヒーノキ」は「リンドウ目アカネ科コーヒーノキ属」の植物なので、「コーヒー豆」は厳密には「コーヒーノキの種子」である。" 
    new "The raw material for coffee is commonly called a \"coffee bean\", but \"beans\" is a general term for the seeds of plants in the order Fabales and family Fabaceae.\nThe coffee plant belongs to the genus Coffea in the family Rubiaceae, order Gentianales, so \"coffee beans\" are technically \"the seeds of the coffee plant\"." 
 
    # game/script.rpy:135 
    old "ネコの糞から採る「コピルアク」" 
    new "\"Kopi luwak\" collected from cat feces" 
 
    # game/script.rpy:135 
    old "コーヒーの果実から生豆を取り出すには、生豆を覆っている果肉を取り除く「精製」を行う必要があり、インドネシアではコーヒーの果実を食べたジャコウネコの糞から、体内で消化されなかった生豆だけを集める「コピルアク」が生産されている。\n1995年にコピルアクを扱う会社の社長にイグノーベル賞が贈られたり、映画『かもめ食堂』(2006)や『最高の人生の見つけ方』(2007)ではキーアイテムになったりしたことで、知名度が上がっている。" 
    new "To extract green coffee beans from coffee fruit, the pulp surrounding the beans must be removed through a process called \"processing\". In Indonesia, \"kopi luwak\" is produced by collecting only the undigested green beans from the feces of Asian palm civets that have eaten coffee fruit.\nIts profile rose after the president of a company dealing in kopi luwak received an Ig Nobel Prize in 1995, and after it appeared as a key item in the films \"Kamome Diner\" (2006) and \"The Bucket List\" (2007)." 
 
    # game/script.rpy:135 
    old "「コピルアク」以外の動物の糞から採るコーヒー" 
    new "Coffee collected from animal feces other than \"kopi luwak\"" 
 
    # game/script.rpy:135 
    old "動物の糞から採るコーヒーには他にも、インドでサルの糞から集める「モンキー・コーヒー」、ブラジルでジャクーという鳥の糞から集める「ジャクー・コーヒー」、タイでゾウの糞から集める「ブラック・アイボリー」が存在する。" 
    new "Other coffees collected from animal feces include \"monkey coffee\", collected from monkey feces in India; \"Jacu coffee\", collected from the feces of a bird called the jacu in Brazil; and \"Black Ivory\", collected from elephant feces in Thailand." 
 
    # game/script.rpy:135 
    old "「珈琲」はコーヒーの実を髪飾りに見立てた当て字" 
    new "\"珈琲\" is an ateji likening coffee cherries to a hair ornament" 
 
    # game/script.rpy:135 
    old "珈琲の「珈」は、当時の女性が髪をまとめるために使った「かみかざり」と読み、「花かんざし」を意味する漢字。\nそして「琲」の読み方は「つらぬく」。\nかんざしの飾り玉をつなぐ紐の意味で使われていた。\nつまり「珈琲」はもともと女性の髪を彩る「玉飾りのついた花かんざし」を意味する漢字だった\nコーヒーノキにたわわに実る赤い小さい実を、玉飾りのついた花かんざしに見立てて「珈琲」の字を当てたのが、江戸時代末期の蘭学者、【宇田川|うだがわ】 【榕菴|ようあん】。" 
    new "The \"珈\" in 珈琲 is read as \"hair ornament\" and is a kanji meaning \"flower hairpin\", an ornament women at the time used to arrange their hair.\nThe \"琲\" is read as \"tsuranuku\", meaning \"to pierce through\".\nIt was used to refer to the cord connecting the decorative beads of a hairpin.\nThus, 珈琲 originally referred to \"a flower hairpin decorated with beads\".\nThe late-Edo-period Rangaku scholar 【宇田川|うだがわ】 【榕菴|ようあん】 chose these characters by likening the small red fruits growing abundantly on coffee plants to a flower hairpin decorated with beads." 
 
    # game/script.rpy:135 
    old "樽から蒸発した「【天使の取り分|エンジェルズ・シェア】」" 
    new "\"Angel's share\" evaporated from barrels" 
 
    # game/script.rpy:135 
    old "酒を熟成させるときに樽を使ったことで、樽から蒸発した水分やアルコール分を「【天使の取り分|エンジェルズ・シェア】」と呼ぶことがある。\n木製の樽で1年熟成すると、1〜3\%程度が、「【天使の取り分|エンジェルズ・シェア】」として失われる。" 
    new "When barrels are used to age alcohol, the water and alcohol that evaporate from the barrel are sometimes called the \"angel's share\".\nWhen alcohol is aged in a wooden barrel for one year, approximately 1 to 3 percent is lost as the \"angel's share\"." 
 
    # game/script.rpy:135 
    old "樽に染み込んだ「【悪魔の取り分|デビルズ・カット】」" 
    new "\"Devil's cut\" absorbed into the barrel" 
 
    # game/script.rpy:135 
    old "酒を熟成させるときに樽を使ったことで、樽に染み込んで取り出せなかった酒を「【悪魔の取り分|デビルズ・カット】」と呼ぶことがある。\n「【悪魔の取り分|デビルズ・カット】」の量は、アルコール度数ではなく、樽の木の多孔性に影響を受ける。" 
    new "When barrels are used to age alcohol, the alcohol that soaks into the barrel and cannot be extracted is sometimes called the \"devil's cut\".\nThe amount of \"devil's cut\" is affected not by the alcohol content but by the porosity of the barrel's wood." 
 
    # game/script.rpy:135 
    old "「【悪魔の取り分|デビルズ・カット】」という名前のお酒" 
    new "An alcoholic drink named \"Devil's Cut\"" 
 
    # game/script.rpy:135 
    old "「ジム・ビーム　デビルズカット」という、【悪魔の取り分|デビルズ・カット】そのままの名前のお酒をジム・ビームが製造しており、樽から抽出したバーボンをブレンドすることで、木材の香りをより強く楽しめる。" 
    new "Jim Beam produces an alcoholic drink called \"Jim Beam Devil's Cut\", named directly after the devil's cut. It blends bourbon extracted from the barrels, allowing the woody aroma to be enjoyed more intensely." 
 
    # game/script.rpy:135 
    old "【水神|みなかみ】 【南|みなみ】" 
    new "Minami Minakami" 
 
    # game/script.rpy:135 
    old "警視庁 捜査一課所属。\n水神財閥の一族の三女。\n無類の女好き。\nお茶派。" 
    new "A member of the Tokyo Metropolitan Police Department's First Investigative Division.\nThe third daughter of the Minakami family, owners of the Minakami conglomerate.\nAn unabashed lover of women.\nPrefers tea." 
 
    # game/script.rpy:135 
    old "【濁澤|にごりさわ】ニコル" 
    new "Nicole Nigorisawa" 
 
    # game/script.rpy:135 
    old "警視庁 捜査一課所属。\n【水神|みなかみ】 【南|みなみ】とは幼馴染。\nハッキングが得意。\nコーヒー派。" 
    new "A member of the Tokyo Metropolitan Police Department's First Investigative Division.\nA childhood friend of 【Minakami|みなかみ】 【Minami|みなみ】.\nSkilled at hacking.\nPrefers coffee." 
 
    # game/script.rpy:135 
    old "【竜胆|りんどう】 【茜|あかね】" 
    new "Akane Rindo" 
 
    # game/script.rpy:135 
    old "警視庁 鑑識課所属。\n【躑躅|つつじ】 【椿|つばき】とルームシェアしている。\nコーヒー派。" 
    new "A member of the Tokyo Metropolitan Police Department's Forensics Division.\nShares an apartment with Tsubaki Tsutsuji.\nPrefers coffee." 
 
    # game/script.rpy:135 
    old "【松風|まつかぜ】 【柚子|ゆず】" 
    new "Yuzu Matsukaze" 
 
    # game/script.rpy:135 
    old "桜月大学 薬学部 【松風|まつかぜ】研究室の室長。\n疲労研究の第一人者。\nコーヒー派。" 
    new "Head of the Matsukaze Laboratory in the Faculty of Pharmacy at Sakurazuki University.\nA leading researcher on fatigue.\nPrefers coffee." 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】" 
    new "Tsubaki Tsutsuji" 
 
    # game/script.rpy:135 
    old "桜月大学 薬学部 【松風|まつかぜ】研究室所属の博士研究員。\n【竜胆|りんどう】 【茜|あかね】とルームシェアしている。\nお茶派。" 
    new "A postdoctoral researcher in the Matsukaze Laboratory, Faculty of Pharmacy, Sakurazuki University.\nShares an apartment with Akane Rindo.\nPrefers tea." 
 
    # game/script.rpy:135 
    old "ジャシー・チェン" 
    new "Jassy Chen" 
 
    # game/script.rpy:135 
    old "桜月大学 薬学部 【松風|まつかぜ】研究室所属の博士研究員。\n故郷の香港への愛があふれている。\nコーヒー派。" 
    new "A postdoctoral researcher in the Matsukaze Laboratory, Faculty of Pharmacy, Sakurazuki University.\nOverflows with love for her hometown of Hong Kong.\nPrefers coffee." 
 
    # game/script.rpy:135 
    old "【菊苦菜|きくにがな】 ちこり" 
    new "Chicory Kikunigana" 
 
    # game/script.rpy:135 
    old "桜月大学 薬学部 【松風|まつかぜ】研究室所属の博士研究員。\n誰よりも早くから、誰よりも遅くまで研究室にいる。\nコーヒー派。" 
    new "A postdoctoral researcher in the Matsukaze Laboratory, Faculty of Pharmacy, Sakurazuki University.\nArrives at the lab earlier than anyone else and stays later than anyone else.\nPrefers coffee." 
 
    # game/script.rpy:135 
    old "【毛利|もうり】 【森子|もりこ】" 
    new "Moriko Mori" 
 
    # game/script.rpy:135 
    old "警視庁 捜査一課所属。\n最近はまつ毛の盛りにハマっている。\n映えれば何で飲むが、最近は紅茶派。" 
    new "A member of the Tokyo Metropolitan Police Department's First Investigative Division.\nRecently obsessed with making her eyelashes look extra dramatic.\nShe will drink anything as long as it looks good in photos, but lately she prefers black tea." 
 
    # game/script.rpy:135 
    old "【町矢|まちや】 【抹茶|まっちゃ】" 
    new "Matcha Machiya" 
 
    # game/script.rpy:135 
    old "警視庁 捜査一課所属。\n茶道 裏千家の家系。\nお茶派。" 
    new "A member of the Tokyo Metropolitan Police Department's First Investigative Division.\nComes from a family of the Urasenke school of tea ceremony.\nPrefers tea." 
 
    # game/script.rpy:135 
    old "服薬推定時刻は15時" 
    new "The estimated time of ingestion is 3:00 p.m." 
 
    # game/script.rpy:135 
    old "死亡時刻は19時。\n毒は無味無臭で、服薬して4時間で死に至るため、服薬推定時刻は15時。" 
    new "The time of death was 7:00 p.m.\nThe poison is tasteless and odorless and causes death four hours after ingestion, so the estimated time of ingestion is 3:00 p.m." 
 
    # game/script.rpy:135 
    old "実験室と執務室の入退室のタイムテーブル" 
    new "The laboratory and office entry and exit timetable" 
 
    # game/script.rpy:135 
    old "【松風|まつかぜ】 【柚子|ゆず】教授は13時から、意識不明で搬送された17時まで執務室にいる。\nそして、15時に【躑躅|つつじ】 【椿|つばき】、ジャシー・チェン、【菊苦菜|きくにがな】 ちこりの3人が入れ違いに執務室を訪れている。" 
    new "Professor Yuzu Matsukaze was in the office from 1:00 p.m. until 5:00 p.m., when he was transported away unconscious.\nAt 3:00 p.m., Tsubaki Tsutsuji, Jassy Chen, and Chicory Kikunigana each visited the office in succession." 
 
    # game/script.rpy:135 
    old "yuanyangcha_time_table.jpg" 
    new "yuanyangcha_time_table.jpg" 
 
    # game/script.rpy:135 
    old "毒が検出されたカップは大学生協の公式マグカップ" 
    new "The cup in which the poison was detected is an official university co-op mug" 
 
    # game/script.rpy:135 
    old "つまり、誰でも簡単に入手できる。" 
    new "In other words, anyone could easily obtain one." 
 
    # game/script.rpy:135 
    old "毒が検出されたカップから【躑躅|つつじ】 【椿|つばき】の唾液と指紋を検出" 
    new "Tsubaki Tsutsuji's saliva and fingerprints were detected on the cup containing the poison" 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】が第一容疑者となった原因。" 
    new "This is why Tsubaki Tsutsuji became the prime suspect." 
 
    # game/script.rpy:135 
    old "毒を入れた飲み物は紅茶とコーヒー" 
    new "The poisoned drinks were black tea and coffee" 
 
    # game/script.rpy:135 
    old "紅茶もコーヒーも残量の1/3以上を占めている。" 
    new "Both the black tea and coffee make up more than one-third of the remaining contents." 
 
    # game/script.rpy:135 
    old "毒を入れたコーヒーは100％ロブスタ種" 
    new "The poisoned coffee was 100\% Robusta" 
 
    # game/script.rpy:135 
    old "日本でもロブスタ種は流通しているが、100％で飲むことは珍しい。" 
    new "Robusta is also distributed in Japan, but drinking it at 100\% is uncommon." 
 
    # game/script.rpy:135 
    old "【松風|まつかぜ】 【柚子|ゆず】の研究ノート" 
    new "Yuzu Matsukaze's research notebook" 
 
    # game/script.rpy:135 
    old "自身の研究の実験結果だけでなく、面談の内容も記載されている。" 
    new "It contains not only the results of his own experiments but also the contents of his interviews." 
 
    # game/script.rpy:135 
    old "【松風|まつかぜ】 【柚子|ゆず】の研究ノートの紛失" 
    new "The disappearance of Yuzu Matsukaze's research notebook" 
 
    # game/script.rpy:135 
    old "バッグや執務室を探しても見つからなかった。\n事件当日の17時以降に犯人が隠した可能性が高い。" 
    new "It could not be found even after searching the bag and office.\nIt is highly likely that the culprit hid it sometime after 5:00 p.m. on the day of the incident." 
 
    # game/script.rpy:135 
    old "【松風|まつかぜ】 【柚子|ゆず】のカップは大学生協の公式マグカップ" 
    new "Yuzu Matsukaze's cup is an official university co-op mug" 
 
    # game/script.rpy:135 
    old "おそらくは愛校心から。" 
    new "Probably out of school spirit." 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】の飲み物は紅茶" 
    new "Tsubaki Tsutsuji's drink is black tea" 
 
    # game/script.rpy:135 
    old "正確には、ベルガモット香料で香り付けした、ファーストフレッシュ、オレンジペコーのダージリンと、牛乳と砂糖。" 
    new "More precisely, it is Darjeeling first flush, Orange Pekoe, flavored with bergamot, along with milk and sugar." 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】のカップは大学生協の公式マグカップ" 
    new "Tsubaki Tsutsuji's cup is an official university co-op mug" 
 
    # game/script.rpy:135 
    old "アイディアを思いついた衝撃でマグカップを割り、その替えを大学生協で買って以来、そのまま。" 
    new "She broke her mug from the shock of having an idea, bought a replacement at the university co-op, and has used it ever since." 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】の優雅なティータイム" 
    new "Tsubaki Tsutsuji's elegant tea time" 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】は毎日12時に実験室の遠心分離機を回し、タイマーが鳴るまでの15分間に、水筒を持って給湯室に移動し、携帯食料と紅茶を一服し、カップを洗う習慣がある。" 
    new "Every day at noon, Tsubaki Tsutsuji starts the centrifuge in the laboratory. During the 15 minutes before the timer rings, she takes her thermos to the kitchenette, has a snack and a cup of tea, and washes her cup." 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】の飲み残しは200ml" 
    new "Tsubaki Tsutsuji left 200 ml of her drink" 
 
    # game/script.rpy:135 
    old "かなり大量に飲み残している。" 
    new "That is quite a large amount left unfinished." 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】の水筒が100mlから空に" 
    new "Tsubaki Tsutsuji's thermos went from 100 ml to empty" 
 
    # game/script.rpy:135 
    old "飲み残しの量の半分しかない。" 
    new "That is only half the amount she left in her cup." 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】の論文の過小評価疑惑" 
    new "Suspicion that Tsubaki Tsutsuji's paper was undervalued" 
 
    # game/script.rpy:135 
    old "【躑躅|つつじ】 【椿|つばき】の単著でもおかしくないが、【松風|まつかぜ】 【柚子|ゆず】教授との共著になっている。" 
    new "It could easily have been a paper authored solely by Tsubaki Tsutsuji, but it is co-authored with Professor Yuzu Matsukaze." 
 
    # game/script.rpy:135 
    old "ジャシー・チェンの飲み物は100％アラビカ種のコーヒー" 
    new "Jassy Chen's drink is 100\% Arabica coffee" 
 
    # game/script.rpy:135 
    old "とても上品な香りがする。" 
    new "It has a very refined aroma." 
 
    # game/script.rpy:135 
    old "ジャシー・チェンはティーバッグを持っている" 
    new "Jassy Chen carries a tea bag" 
 
    # game/script.rpy:135 
    old "いつコーヒーに紅茶を混ぜたくなっても大丈夫。" 
    new "She is prepared in case she ever wants to mix black tea into her coffee." 
 
    # game/script.rpy:135 
    old "ジャシー・チェンのカップは「I♡香港」" 
    new "Jassy Chen's cup says \"I♡Hong Kong\"" 
 
    # game/script.rpy:135 
    old "故郷の香港に対する愛情があふれている。" 
    new "It overflows with love for her hometown of Hong Kong." 
 
    # game/script.rpy:135 
    old "ジャシー・チェンの論文の横領疑惑" 
    new "Suspicion that Jassy Chen plagiarized a paper" 
 
    # game/script.rpy:135 
    old "謝辞に記載されていない助成金を受け取ったのは、ジャシー・チェンと【松風|まつかぜ】 【柚子|ゆず】教授のどちらだろうか？" 
    new "Which of them received the grant that was not mentioned in the acknowledgments: Jassy Chen or Professor Yuzu Matsukaze?" 
 
    # game/script.rpy:135 
    old "【菊苦菜|きくにがな】 ちこりは嗅覚に障害がある" 
    new "Chicory Kikunigana has an impaired sense of smell" 
 
    # game/script.rpy:135 
    old "アロマオイルの匂いが充満していることにも気づかなかった。" 
    new "She did not even notice that the room was filled with the smell of aroma oil." 
 
    # game/script.rpy:135 
    old "【菊苦菜|きくにがな】 ちこりだけ1時間早く実験室に到着" 
    new "Chicory Kikunigana arrived at the laboratory one hour early" 
 
    # game/script.rpy:135 
    old "誰よりも早く始め、誰よりも遅くまで残っている。" 
    new "She starts earlier than anyone else and stays later than anyone else." 
 
    # game/script.rpy:135 
    old "【菊苦菜|きくにがな】 ちこりの飲み物は100％ロブスタ種のコーヒー" 
    new "Chicory Kikunigana's drink is 100\% Robusta coffee" 
 
    # game/script.rpy:135 
    old "【菊苦菜|きくにがな】 ちこりのカップはタンブラー" 
    new "Chicory Kikunigana's cup is a tumbler" 
 
    # game/script.rpy:135 
    old "北海道のローカル番組か、ゆるいアニメの影響。" 
    new "Influenced by a local Hokkaido TV program or a laid-back anime." 
 
    # game/script.rpy:135 
    old "【菊苦菜|きくにがな】 ちこりの論文の捏造疑惑" 
    new "Suspicion that Chicory Kikunigana fabricated her paper" 
 
    # game/script.rpy:135 
    old "データの数字の分布が人工的過ぎて、自然界の分布である「ベンフォードの法則」とはかけ離れている。" 
    new "The distribution of numbers in the data is too artificial and far removed from \"Benford's law\", which describes the distribution found in nature." 
 
    # game/script.rpy:135 
    old "毒はだれでも入手できた" 
    new "Anyone could obtain the poison" 
 
    # game/script.rpy:135 
    old "殺鼠剤は危険なので、厳重に管理しましょう。" 
    new "Rodenticide is dangerous, so it should be stored and handled with great care." 
 
    # game/script.rpy:135 
    old "月次の個人面談" 
    new "Monthly individual interviews" 
 
    # game/script.rpy:135 
    old "【松風|まつかぜ】研究室の研究員は、毎月第4火曜日に教授と個人面談をすることになっている。" 
    new "Researchers in the 【Matsukaze|まつかぜ】 Laboratory are scheduled to have individual interviews with the professor on the fourth Tuesday of every month." 
 
    # game/script.rpy:135 
    old "月次の個人面談のリマインドメール" 
    new "Reminder email for the monthly individual interviews" 
 
    # game/script.rpy:135 
    old "「皆さんの論文を読み返して気づいたことがあったので、お話ししましょう。」とある。" 
    new "It says, \"I noticed something while rereading everyone's papers, so let's talk about it.\"" 
 
    # game/script.rpy:135 
    old "給湯室の棚には誰でも隠れられる" 
    new "Anyone can hide in the kitchenette cabinet" 
 
    # game/script.rpy:135 
    old "大柄なニコルが1人入っても、大丈夫。" 
    new "Even someone as large as Nicole can fit inside alone." 
 
    # game/script.rpy:135 
    old "給湯室は暗い" 
    new "The kitchenette is dark" 
 
    # game/script.rpy:135 
    old "カップや水筒の中身の色を確認することはできない。" 
    new "It is impossible to see the color of the contents of the cups or thermoses." 
 
    # game/script.rpy:135 
    old "誰かが遠心分離機のタイマーを5分に変更した" 
    new "Someone changed the centrifuge timer to five minutes" 
 
    # game/script.rpy:135 
    old "ログで確認。\n【躑躅|つつじ】 【椿|つばき】が給湯室にカップと水筒を放置する原因となった。" 
    new "Confirmed in the log.\nThis caused Tsubaki Tsutsuji to leave her cup and thermos in the kitchenette." 
 
    # game/script.rpy:135 
    old "誰かが「タイマーを5分に変更」の操作日時を「11時45分」に書き換えた" 
    new "Someone changed the recorded time of the \"change timer to five minutes\" operation to \"11:45 a.m.\"" 
 
    # game/script.rpy:135 
    old "「11時45分」にアリバイがある人物の犯行だと思われる。" 
    new "The culprit is believed to be someone who has an alibi for \"11:45 a.m.\"." 
 
    # game/script.rpy:320 
    old "「[input_str]」でよろしいでしょうか？" 
    new "Is \"[input_str]\" correct?" 
 
    # game/script.rpy:390 
    old "じゃんけんの結果、【竜胆|りんどう】 【茜|あかね】に振る舞うことになったのは？" 
    new "As a result of rock-paper-scissors, what are you going to serve Akane Rindo?" 
 
    # game/script.rpy:392 
    old "紅茶" 
    new "Black tea" 
 
    # game/script.rpy:394 
    old "コーヒー" 
    new "Coffee" 
 
    # game/script.rpy:454 
    old "行きたい場所を選んでください。" 
    new "Please choose where you want to go." 
 
    # game/script.rpy:456 
    old "警備室" 
    new "Security room" 
 
    # game/script.rpy:458 
    old "給湯室" 
    new "Kitchenette" 
 
    # game/script.rpy:460 
    old "実験室" 
    new "Laboratory" 
 
    # game/script.rpy:462 
    old "執務室" 
    new "Office" 
 
    # game/script.rpy:473 
    old "調べる" 
    new "Investigate" 
 
    # game/script.rpy:475 
    old "話す" 
    new "Talk" 
 
    # game/script.rpy:477 
    old "戻る" 
    new "Back" 
 
    # game/script.rpy:501 
    old "調べたい場所を選んでください。" 
    new "Please choose what you want to investigate." 
 
    # game/script.rpy:503 
    old "監視カメラの映像" 
    new "Security camera footage" 
 
    # game/script.rpy:505 
    old "映画のポスター" 
    new "Movie poster" 
 
    # game/script.rpy:557 
    old "聞きたいことを選んでください。" 
    new "Please choose what you want to ask about." 
 
    # game/script.rpy:559 
    old "毒を入れた飲み物" 
    new "The poisoned drink" 
 
    # game/script.rpy:561 
    old "毒を入れたコーヒーの種類" 
    new "The type of coffee that was poisoned" 
 
    # game/script.rpy:563 
    old "髪飾り" 
    new "Hair ornament" 
 
    # game/script.rpy:682 
    old "棚" 
    new "Cabinet" 
 
    # game/script.rpy:684 
    old "流し台" 
    new "Sink" 
 
    # game/script.rpy:739 
    old "昨日の行動" 
    new "Yesterday's actions" 
 
    # game/script.rpy:741 
    old "優雅なティータイム" 
    new "Elegant tea time" 
 
    # game/script.rpy:743 
    old "カップ" 
    new "Cup" 
 
    # game/script.rpy:745 
    old "マグカップを洗うまでの時間" 
    new "Time until the mug was washed" 
 
    # game/script.rpy:747 
    old "個人面談" 
    new "Individual interview" 
 
    # game/script.rpy:987 
    old "遠心分離機" 
    new "Centrifuge" 
 
    # game/script.rpy:989 
    old "薬品棚" 
    new "Chemical cabinet" 
 
    # game/script.rpy:1049 
    old "飲み物" 
    new "Drink" 
 
    # game/script.rpy:1218 
    old "【躑躅|つつじ】 【椿|つばき】の論文" 
    new "Tsubaki Tsutsuji's paper" 
 
    # game/script.rpy:1220 
    old "ジャシー・チェンの論文" 
    new "Jassy Chen's paper" 
 
    # game/script.rpy:1222 
    old "【菊苦菜|きくにがな】 ちこりの論文" 
    new "Chicory Kikunigana's paper" 
 
    # game/script.rpy:1512 
    old "【躑躅|つつじ】 【椿|つばき】も【松風|まつかぜ】 【柚子|ゆず】教授も、大学生協の公式マグカップを使っていたから" 
    new "Because both Tsubaki Tsutsuji and Professor Yuzu Matsukaze used official university co-op mugs" 
 
    # game/script.rpy:1514 
    old "執務室は暗かったから" 
    new "Because the office was dark" 
 
    # game/script.rpy:1541 
    old "隠れられる場所は……" 
    new "The place where someone could hide is..." 
 
    # game/script.rpy:1543 
    old "電子レンジの中" 
    new "Inside the microwave" 
 
    # game/script.rpy:1545 
    old "棚の中" 
    new "Inside the cabinet" 
 
    # game/script.rpy:1573 
    old "「{color=[gui.keyword_color]}11時45分{/color}」と書き換えたのは……" 
    new "The person who changed it to \"{color=[gui.keyword_color]}11:45 a.m.{/color}\" was..." 
 
    # game/script.rpy:1619 
    old "毒が盛られたコーヒーは……" 
    new "The poisoned coffee was..." 
 
    # game/script.rpy:1621 
    old "アラビカ種" 
    new "Arabica" 
 
    # game/script.rpy:1623 
    old "ロブスタ種" 
    new "Robusta" 
 
    # game/script.rpy:1643 
    old "【菊苦菜|きくにがな】 ちこりの飲み物は……" 
    new "Chicory Kikunigana's drink was..." 
 
    # game/script.rpy:1645 
    old "アラビカ種のコーヒー" 
    new "Arabica coffee" 
 
    # game/script.rpy:1647 
    old "ロブスタ種のコーヒー" 
    new "Robusta coffee" 
 
    # game/script.rpy:1697 
    old "ジャシーチェンの故郷では……" 
    new "In Jassy Chen's hometown..." 
 
    # game/script.rpy:1699 
    old "紅茶にコーヒーを入れることがあるから" 
    new "Because people sometimes add coffee to black tea" 
 
    # game/script.rpy:1701 
    old "コーヒーをブラックで飲まないから" 
    new "Because she does not drink coffee black" 
 
    # game/script.rpy:1726 
    old "【菊苦菜|きくにがな】 ちこりの……" 
    new "Chicory Kikunigana's..." 
 
    # game/script.rpy:1728 
    old "睡眠不足" 
    new "Lack of sleep" 
 
    # game/script.rpy:1730 
    old "嗅覚障害" 
    new "Impaired sense of smell" 
 
    # game/script.rpy:1753 
    old "【菊苦菜|きくにがな】 ちこりの論文の問題点は……" 
    new "The problem with Chicory Kikunigana's paper was..." 
 
    # game/script.rpy:1755 
    old "功績の横取り" 
    new "Taking credit for someone else's work" 
 
    # game/script.rpy:1757 
    old "助成金の横領" 
    new "Embezzling research funds" 
 
    # game/script.rpy:1759 
    old "データの捏造" 
    new "Data fabrication" 

# game/script.rpy:1448
translate english yuanyangcha_deduction_dba78633:

    # tp "同日 13:30\n桜月大学 【松風|まつかぜ】研究室 廊下"
    tp "同日 13:30\n桜月大学 【松風|まつかぜ】研究室 廊下"

# TODO: Translation updated at 2026-08-15 11:02

translate english strings:

    # game/script.rpy:1408
    old "給湯室で隠れられる場所を探す"
    new "Look for a place to hide in the kitchenette"

    # game/script.rpy:1410
    old "実験室の遠心分離機を調べる"
    new "Examine the centrifuge in the laboratory"

    # game/script.rpy:1412
    old "【竜胆|りんどう】 【茜|あかね】に毒入りコーヒーの種類を確認する"
    new "Ask Akane Rindo what kind of coffee was poisoned"

    # game/script.rpy:1414
    old "給湯室を調べる"
    new "Examine the kitchenette"

    # game/script.rpy:1416
    old "実験室を調べる"
    new "Examine the laboratory"

    # game/script.rpy:1418
    old "執務室を調べる"
    new "Examine the office"

    # game/script.rpy:1420
    old "執務室で【躑躅|つつじ】 【椿|つばき】の論文を調べる"
    new "Examine Tsubaki Tsutsuji's paper in the office"

    # game/script.rpy:1422
    old "執務室でジャシー・チェンの論文を調べる"
    new "Examine Jassie Chen's paper in the office"

    # game/script.rpy:1424
    old "執務室で【菊苦菜|きくにがな】 ちこりの論文を調べる"
    new "Examine Chicory Kikunigana's paper in the office"

    # game/script.rpy:1426
    old "執務室で【松風|まつかぜ】 【柚子|ゆず】の研究ノートを調べる"
    new "Examine Professor Yuzu Matsukaze's research notes in the office"
