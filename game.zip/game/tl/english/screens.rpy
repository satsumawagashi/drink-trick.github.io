﻿# TODO: Translation updated at 2026-08-15 08:20

translate english strings:

    # game/screens.rpy:279
    old "ロールバック"
    new "Rollback"

    # game/screens.rpy:280
    old "ヒストリー"
    new "History"

    # game/screens.rpy:281
    old "スキップ"
    new "Skip"

    # game/screens.rpy:282
    old "オート"
    new "Auto"

    # game/screens.rpy:283
    old "セーブ"
    new "Save"

    # game/screens.rpy:284
    old "Q.セーブ"
    new "Q.Save"

    # game/screens.rpy:285
    old "Q.ロード"
    new "Q.Load"

    # game/screens.rpy:286
    old "設定"
    new "Settings"

    # game/screens.rpy:332
    old "スタート"
    new "Start"

    # game/screens.rpy:340
    old "ロード"
    new "Load"

    # game/screens.rpy:342
    old "飲み物トリビア"
    new "Drink Trivia"

    # game/screens.rpy:344
    old "環境設定"
    new "Preferences"

    # game/screens.rpy:348
    old "リプレイ終了"
    new "End Replay"

    # game/screens.rpy:352
    old "メインメニュー"
    new "Main Menu"

    # game/screens.rpy:354
    old "バージョン情報"
    new "Version Information"

    # game/screens.rpy:359
    old "ヘルプ"
    new "Help"

    # game/screens.rpy:365
    old "終了"
    new "Exit"

    # game/screens.rpy:597
    old "バージョン [config.version!t]\n"
    new "Version [config.version!t]\n"

    # game/screens.rpy:603
    old "Made with {a=https://ja.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Made with {a=https://ja.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:677
    old "ページ {}"
    new "Page {}"

    # game/screens.rpy:677
    old "オートセーブ"
    new "Auto Save"

    # game/screens.rpy:677
    old "クイックセーブ"
    new "Quick Save"

    # game/screens.rpy:720
    old "{#file_time}%Y年%m月%d日(%a) %H時%M分"
    new "{#file_time}%Y年%m月%d日(%a) %H時%M分"

    # game/screens.rpy:720
    old "空のスロット"
    new "Empty Slot"

    # game/screens.rpy:740
    old "<"
    new "<"

    # game/screens.rpy:744
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:747
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:753
    old ">"
    new ">"

    # game/screens.rpy:758
    old "同期のアップロード"
    new "Upload Sync"

    # game/screens.rpy:762
    old "同期のダウンロード"
    new "Download Sync"

    # game/screens.rpy:822
    old "ディスプレイ"
    new "Display"

    # game/screens.rpy:823
    old "ウィンドウ"
    new "Window"

    # game/screens.rpy:824
    old "フルスクリーン"
    new "Fullscreen"

    # game/screens.rpy:829
    old "未読テキスト"
    new "Unread Text"

    # game/screens.rpy:830
    old "選択肢後"
    new "After Choices"

    # game/screens.rpy:831
    old "トランジション"
    new "Transition"

    # game/screens.rpy:845
    old "文字表示速度"
    new "Text Speed"

    # game/screens.rpy:849
    old "オート待ち時間"
    new "Auto Wait Time"

    # game/screens.rpy:856
    old "音楽の音量"
    new "Music Volume"

    # game/screens.rpy:863
    old "効果音の音量"
    new "Sound Effect Volume"

    # game/screens.rpy:869
    old "テスト"
    new "Test"

    # game/screens.rpy:873
    old "ボイスの音量"
    new "Voice Volume"

    # game/screens.rpy:884
    old "全てミュート"
    new "Mute All"

    # game/screens.rpy:1005
    old "ヒストリーはありません。"
    new "No history available."

    # game/screens.rpy:1081
    old "キーボード"
    new "Keyboard"

    # game/screens.rpy:1082
    old "マウス"
    new "Mouse"

    # game/screens.rpy:1085
    old "ゲームパッド"
    new "Gamepad"

    # game/screens.rpy:1098
    old "エンター"
    new "Enter"

    # game/screens.rpy:1099
    old "台詞を読み進める。またはボタンを選択する。"
    new "Advance dialogue. Or select a button."

    # game/screens.rpy:1102
    old "スペース"
    new "SPACE"

    # game/screens.rpy:1103
    old "台詞を読み進める。ただしボタンは選択しない。"
    new "Advance dialogue. But don't select any buttons."

    # game/screens.rpy:1106
    old "方向キー"
    new "Directional Keys"

    # game/screens.rpy:1107
    old "インターフェースを移動する。"
    new "Move through the interface."

    # game/screens.rpy:1110
    old "ESC"
    new "ESC"

    # game/screens.rpy:1111
    old "ゲームメニューを開く。"
    new "Open game menu."

    # game/screens.rpy:1114
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1115
    old "押し続けている間スキップする。"
    new "Skip while holding."

    # game/screens.rpy:1118
    old "Tab"
    new "Tab"

    # game/screens.rpy:1119
    old "スキップモードに切り替える。"
    new "Switch to skip mode."

    # game/screens.rpy:1122
    old "Page Up"
    new "Page Up"

    # game/screens.rpy:1123
    old "前の台詞に戻る。"
    new "Return to previous dialogue."

    # game/screens.rpy:1126
    old "Page Down"
    new "Page Down"

    # game/screens.rpy:1127
    old "ロールバック中、次の台詞に進む。"
    new "During rollback, advance to the next dialogue."

    # game/screens.rpy:1131
    old "インターフェースを隠す。"
    new "Hide the interface."

    # game/screens.rpy:1135
    old "スクリーンショットを撮る。"
    new "Take a screenshot."

    # game/screens.rpy:1139
    old "{a=https://ja.renpy.org/l/voicing}セルフボイシング{/a}を有効化する。"
    new "Enable {a=https://ja.renpy.org/l/voicing}Self Voicing{/a}"

    # game/screens.rpy:1143
    old "アクセシビリティーメニューを開きます。"
    new "Open accessibility menu."

    # game/screens.rpy:1149
    old "左クリック"
    new "Left Click"

    # game/screens.rpy:1153
    old "中クリック"
    new "Middle Click"

    # game/screens.rpy:1157
    old "右クリック"
    new "Right Click"

    # game/screens.rpy:1161
    old "マウスホイール上回転"
    new "Mouse Wheel Up"

    # game/screens.rpy:1165
    old "マウスホイール下回転"
    new "Mouse Wheel Down"

    # game/screens.rpy:1172
    old "Ｒトリガー\nＡ／下ボタン"
    new "R Trigger\nA/Down Button"

    # game/screens.rpy:1176
    old "Ｌトリガー\nＬボタン"
    new "L Trigger\nL Button"

    # game/screens.rpy:1180
    old "Ｒボタン"
    new "R Button"

    # game/screens.rpy:1184
    old "方向パッド\n左右スティック"
    new "Directional Pad\nLeft/Right Stick"

    # game/screens.rpy:1188
    old "スタート、ガイド、 B / Right ボタン"
    new "Start, Guide, B/Right Button"

    # game/screens.rpy:1192
    old "Ｙ／上ボタン"
    new "Y/Up Button"

    # game/screens.rpy:1195
    old "キャリブレート"
    new "Calibrate"

    # game/screens.rpy:1261
    old "はい"
    new "Yes"

    # game/screens.rpy:1262
    old "いいえ"
    new "No"

    # game/screens.rpy:1307
    old "スキップ中"
    new "Skipping"

    # game/screens.rpy:1394
    old "以下の手がかりを取得しました。"
    new "You have obtained the following clues."

    # game/screens.rpy:1656
    old "手がかり [done_int]/[max_int]"
    new "Clue [done_int]/[max_int]"

    # game/screens.rpy:1738
    old "手帳"
    new "Memo"

    # game/screens.rpy:1775
    old "閉じる"
    new "Close"

    # game/screens.rpy:1856
    old "手がかり"
    new "Clue"

    # game/screens.rpy:1857
    old "人物"
    new "Character"
    
    # game/screens.rpy:2063
    old "メニュー"
    new "Menu"

# TODO: Translation updated at 2026-08-15 08:28

translate english strings:

    # game/screens.rpy:838
    old "Language"
    new "Language"

